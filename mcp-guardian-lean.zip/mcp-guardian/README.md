# MCP Guardian 🛡️

**AI-powered security scanner for Model Context Protocol (MCP) servers.**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Quick Start

```bash
# Install
pip install -e .

# Scan your MCP config
mcp-guardian scan config ~/.config/claude/claude_desktop_config.json

# Scan MCP server source code
mcp-guardian scan source ./my-mcp-server
```

## What It Detects

| Attack Type | Description |
|-------------|-------------|
| 🔴 **Command Injection** | Shell injection in tool implementations |
| 🟠 **Tool Poisoning** | Hidden instructions that manipulate LLM behavior |
| 🟡 **Schema Mutations** | Rug-pull attacks that change tool behavior |
| 🔵 **Attack Chains** | Dangerous tool combinations (benign + benign = dangerous) |
| 🟣 **Tool Shadowing** | Rogue servers hijacking trusted tool names |

## Benchmark Results

Validated against **3 academic security benchmarks** with **100% detection rate**:

| Benchmark | Cases | Detected |
|-----------|-------|----------|
| MSB (ICLR 2026) | 25 | 100% |
| mcp-test-harness | 9 | 100% |
| MCPSecBench (arXiv:2508.13220) | 6 | 100% |

## Documentation

📄 **[DESIGN_DOC.md](DESIGN_DOC.md)** — Full technical design, architecture, patent strategy, and benchmark results

## Key Features

1. **Schema Mutation Detection** — LSH fingerprinting to catch rug-pulls
2. **Capability Chain Analysis** — Graph-based detection of dangerous tool combinations
3. **Cross-Tool Taint Tracking** — Dual-lattice model for data flow analysis
4. **OAuth 2.1/PKCE Compliance** — Audit against June 2025 MCP spec

## Architecture

**Shift-Left Design:** Heavy analysis at CI/CD time, O(1) lookups at runtime (<5ms).

```
CI/CD (seconds OK)              Runtime (<5ms)
─────────────────               ──────────────
• Build capability graph        • Hash lookup O(1)
• Compute attack chains         • Risk score check
• Generate fingerprints         • Block if threshold hit
```

## Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run benchmark validation
python scripts/run_benchmark_tests.py
```

## License

MIT
