def main():
    print("Hello from mcp-guardian!")


if __name__ == "__main__":
    main()
