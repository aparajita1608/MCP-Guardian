"""Pytest configuration and fixtures for mcp-guardian tests."""

import json
from pathlib import Path

import pytest


@pytest.fixture
def tmp_config_file(tmp_path: Path) -> Path:
    """Create a temporary MCP config file."""
    config = {
        "mcpServers": {
            "test-server": {
                "command": "python",
                "args": ["server.py"],
            }
        }
    }
    config_file = tmp_path / "mcp_config.json"
    config_file.write_text(json.dumps(config))
    return config_file


@pytest.fixture
def vulnerable_config(tmp_path: Path) -> Path:
    """Create a config file with security issues."""
    config = {
        "mcpServers": {
            "exposed-server": {
                "command": "node",
                "args": ["server.js"],
                "transport": "sse",
                "host": "0.0.0.0",
            },
            "shell-injection": {
                "command": "bash",
                "args": ["-c", "echo ${USER_INPUT}"],
            },
            "secrets-exposed": {
                "command": "python",
                "args": ["server.py"],
                "env": {
                    "API_KEY": "sk-1234567890abcdef1234567890abcdef",
                    "DATABASE_URL": "postgres://user:password@localhost/db",
                },
            },
            "unpinned": {
                "command": "npx",
                "args": ["@modelcontextprotocol/server-filesystem@latest"],
            },
        }
    }
    config_file = tmp_path / "vulnerable_config.json"
    config_file.write_text(json.dumps(config))
    return config_file


@pytest.fixture
def vulnerable_source(tmp_path: Path) -> Path:
    """Create source files with security vulnerabilities."""
    source_dir = tmp_path / "src"
    source_dir.mkdir()

    # Command injection vulnerability
    (source_dir / "git_tool.py").write_text('''
import subprocess

def git_log(repo: str, args: str) -> str:
    """Get git log - VULNERABLE to command injection."""
    result = subprocess.run(f"git -C {repo} log {args}", shell=True, capture_output=True)
    return result.stdout.decode()
''')

    # Hardcoded secrets
    (source_dir / "config.py").write_text("""
API_KEY = "sk-ant-api03-1234567890abcdefghijklmnopqrstuvwxyz"
DATABASE_PASSWORD = "super_secret_password_123"
""")

    # SQL injection
    (source_dir / "database.py").write_text('''
def get_user(cursor, user_id: str):
    """Get user by ID - VULNERABLE to SQL injection."""
    cursor.execute(f"SELECT * FROM users WHERE id = '{user_id}'")
    return cursor.fetchone()
''')

    # Unsafe deserialization
    (source_dir / "loader.py").write_text('''
import pickle
import yaml

def load_data(data: bytes):
    """Load data - VULNERABLE to unsafe deserialization."""
    return pickle.loads(data)

def load_config(config_str: str):
    """Load YAML config - VULNERABLE."""
    return yaml.load(config_str)
''')

    return source_dir


@pytest.fixture
def safe_source(tmp_path: Path) -> Path:
    """Create source files without vulnerabilities."""
    source_dir = tmp_path / "safe_src"
    source_dir.mkdir()

    (source_dir / "git_tool.py").write_text('''
import subprocess

def git_log(repo: str, count: int = 10) -> str:
    """Get git log - SAFE implementation."""
    result = subprocess.run(
        ["git", "-C", repo, "log", f"-{count}", "--oneline"],
        capture_output=True,
        check=True
    )
    return result.stdout.decode()
''')

    (source_dir / "config.py").write_text("""
import os

API_KEY = os.environ.get("API_KEY")
DATABASE_PASSWORD = os.environ.get("DATABASE_PASSWORD")
""")

    return source_dir
