"""Vulnerable MCP server fixture for testing.

This server intentionally contains security vulnerabilities
for testing mcp-guardian's detection capabilities.

DO NOT USE IN PRODUCTION!
"""

import os
import pickle
import subprocess
import yaml


# MCP-SRC-001: Command Injection
def git_log(repo: str, args: str) -> str:
    """Get git log - VULNERABLE to command injection."""
    # BAD: shell=True with user input
    result = subprocess.run(f"git -C {repo} log {args}", shell=True, capture_output=True)
    return result.stdout.decode()


def run_command(cmd: str) -> str:
    """Run arbitrary command - VULNERABLE."""
    # BAD: os.system with user input
    os.system(cmd)
    return "done"


# MCP-SRC-002: Path Traversal
def read_file(base_dir: str, filename: str) -> str:
    """Read file - VULNERABLE to path traversal."""
    # BAD: No path validation
    path = base_dir + "/" + filename
    with open(path) as f:
        return f.read()


# MCP-SRC-003: SQL Injection
def get_user(cursor, user_id: str):
    """Get user - VULNERABLE to SQL injection."""
    # BAD: String formatting in SQL
    cursor.execute(f"SELECT * FROM users WHERE id = '{user_id}'")
    return cursor.fetchone()


def search_users(cursor, name: str):
    """Search users - VULNERABLE to SQL injection."""
    # BAD: String concatenation in SQL
    query = "SELECT * FROM users WHERE name LIKE '%" + name + "%'"
    cursor.execute(query)
    return cursor.fetchall()


# MCP-SRC-004: Hardcoded Secrets
API_KEY = "sk-ant-api03-1234567890abcdefghijklmnopqrstuvwxyz"
OPENAI_KEY = "sk-1234567890abcdefghijklmnopqrstuvwxyz1234567890ab"
GITHUB_TOKEN = "ghp_1234567890abcdefghijklmnopqrstuvwxyz"
AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
DATABASE_PASSWORD = "super_secret_password_123"


# MCP-SRC-005: Unsafe Deserialization
def load_data(data: bytes):
    """Load data - VULNERABLE to pickle deserialization."""
    # BAD: pickle.loads on untrusted data
    return pickle.loads(data)


def load_config(config_str: str):
    """Load YAML - VULNERABLE to unsafe YAML load."""
    # BAD: yaml.load without safe_load
    return yaml.load(config_str)


def execute_code(code: str):
    """Execute code - VULNERABLE to code injection."""
    # BAD: eval on user input
    return eval(code)


# MCP-SRC-006: SSRF
def fetch_url(url: str):
    """Fetch URL - VULNERABLE to SSRF."""
    import requests

    # BAD: No URL validation
    response = requests.get(url)
    return response.text


def proxy_request(target_url: str):
    """Proxy request - VULNERABLE to SSRF."""
    import httpx

    # BAD: User-controlled URL
    return httpx.get(target_url).text


# MCP-SRC-007: Debug Mode
DEBUG = True
import logging

logging.getLogger().setLevel(logging.DEBUG)
