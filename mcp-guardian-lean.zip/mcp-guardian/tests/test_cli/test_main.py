"""Tests for the main CLI module."""

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from mcp_guardian.cli.main import app

runner = CliRunner()


class TestVersionCommand:
    """Tests for the version command."""

    def test_version_shows_version_number(self) -> None:
        """Test that version command displays version."""
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "mcp-guardian" in result.stdout
        assert "version" in result.stdout

    def test_version_returns_success(self) -> None:
        """Test that version command returns exit code 0."""
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0


class TestAuditCommand:
    """Tests for the audit command."""

    def test_audit_nonexistent_path(self, tmp_path: Path) -> None:
        """Test audit with non-existent path."""
        result = runner.invoke(app, ["audit", "/nonexistent/path"])
        assert result.exit_code == 1
        assert "does not exist" in result.stdout

    def test_audit_empty_directory(self, tmp_path: Path) -> None:
        """Test audit on empty directory."""
        result = runner.invoke(app, ["audit", str(tmp_path)])
        assert result.exit_code == 0
        assert "Audit passed" in result.stdout

    def test_audit_with_vulnerable_config(self, tmp_path: Path) -> None:
        """Test audit finds vulnerabilities in config."""
        # Create vulnerable config
        config = {
            "mcpServers": {
                "exposed": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "sse",
                    "host": "0.0.0.0",
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))

        result = runner.invoke(app, ["audit", str(tmp_path)])
        # Should find the network exposure issue
        assert "MCP-CFG-001" in result.stdout or "Network Exposure" in result.stdout

    def test_audit_with_vulnerable_source(self, tmp_path: Path) -> None:
        """Test audit finds vulnerabilities in source code."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()

        # Create vulnerable source file
        (src_dir / "server.py").write_text("""
import subprocess
def run_cmd(cmd: str):
    subprocess.run(cmd, shell=True)
""")

        result = runner.invoke(app, ["audit", str(tmp_path)])
        # Should find command injection
        assert "MCP-SRC-001" in result.stdout or "Command Injection" in result.stdout

    def test_audit_fail_on_critical(self, tmp_path: Path) -> None:
        """Test audit fails on critical findings."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()

        # Create critical vulnerability (command injection)
        (src_dir / "server.py").write_text("""
import subprocess
def run_cmd(cmd: str):
    subprocess.run(cmd, shell=True)
""")

        result = runner.invoke(app, ["audit", str(tmp_path), "--fail-on", "critical"])
        assert result.exit_code == 1
        assert "Audit failed" in result.stdout

    def test_audit_custom_fail_on(self, tmp_path: Path) -> None:
        """Test audit with custom fail-on severity."""
        result = runner.invoke(app, ["audit", str(tmp_path), "--fail-on", "low"])
        # Empty directory should pass
        assert result.exit_code == 0

    def test_audit_no_ai_flag(self, tmp_path: Path) -> None:
        """Test audit with --no-ai flag."""
        result = runner.invoke(app, ["audit", str(tmp_path), "--no-ai"])
        assert result.exit_code == 0
        assert "Disabled" in result.stdout


class TestInteractiveCommand:
    """Tests for the interactive command."""

    def test_interactive_shows_coming_soon(self) -> None:
        """Test interactive command shows coming soon message."""
        result = runner.invoke(app, ["interactive"])
        assert result.exit_code == 0
        assert "coming soon" in result.stdout.lower()


class TestMainHelp:
    """Tests for main app help."""

    def test_no_args_shows_help(self) -> None:
        """Test that no arguments shows help."""
        result = runner.invoke(app, [])
        # Typer with no_args_is_help=True returns exit code 0
        # but may show help or error depending on version
        assert result.exit_code in (0, 2)
        # Should show some help content
        assert "scan" in result.stdout or "Usage" in result.stdout

    def test_help_flag(self) -> None:
        """Test --help flag."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "MCP" in result.stdout or "mcp" in result.stdout
