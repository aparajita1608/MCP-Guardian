"""Tests for the scan CLI commands."""

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from mcp_guardian.cli.main import app

runner = CliRunner()


class TestScanConfigCommand:
    """Tests for the scan config command."""

    def test_scan_config_nonexistent_file(self) -> None:
        """Test scan config with non-existent file."""
        result = runner.invoke(app, ["scan", "config", "/nonexistent/config.json"])
        assert result.exit_code == 1
        assert "not found" in result.stdout.lower() or "error" in result.stdout.lower()

    def test_scan_config_valid_file(self, tmp_path: Path) -> None:
        """Test scan config with valid config file."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "python",
                    "args": ["server.py"],
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))

        result = runner.invoke(app, ["scan", "config", str(config_file)])
        assert result.exit_code == 0
        assert "Security Score" in result.stdout

    def test_scan_config_with_vulnerabilities(self, vulnerable_config: Path) -> None:
        """Test scan config finds vulnerabilities."""
        result = runner.invoke(app, ["scan", "config", str(vulnerable_config)])
        # Should find issues and return non-zero exit code
        assert "MCP-CFG" in result.stdout
        assert result.exit_code == 1  # Critical/high findings

    def test_scan_config_json_output(self, tmp_path: Path) -> None:
        """Test scan config with JSON output format."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "python",
                    "args": ["server.py"],
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))

        result = runner.invoke(app, ["scan", "config", str(config_file), "--format", "json"])
        assert result.exit_code == 0
        # Output should contain JSON-like content
        assert "findings" in result.stdout or "{" in result.stdout

    def test_scan_config_sarif_output(self, tmp_path: Path) -> None:
        """Test scan config with SARIF output format."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "python",
                    "args": ["server.py"],
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))

        result = runner.invoke(app, ["scan", "config", str(config_file), "--format", "sarif"])
        assert result.exit_code == 0
        # Output should contain SARIF-like content
        assert "$schema" in result.stdout or "runs" in result.stdout or "sarif" in result.stdout.lower()

    def test_scan_config_html_output(self, tmp_path: Path) -> None:
        """Test scan config with HTML output format."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "python",
                    "args": ["server.py"],
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))

        result = runner.invoke(app, ["scan", "config", str(config_file), "--format", "html"])
        assert result.exit_code == 0
        # HTML file should be created
        assert "HTML report saved" in result.stdout

    def test_scan_config_output_to_file(self, tmp_path: Path) -> None:
        """Test scan config with output to file."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "python",
                    "args": ["server.py"],
                }
            }
        }
        config_file = tmp_path / "mcp_config.json"
        config_file.write_text(json.dumps(config))
        output_file = tmp_path / "report.json"

        result = runner.invoke(
            app, ["scan", "config", str(config_file), "--format", "json", "--output", str(output_file)]
        )
        assert result.exit_code == 0
        assert output_file.exists()


class TestScanSourceCommand:
    """Tests for the scan source command."""

    def test_scan_source_nonexistent_path(self) -> None:
        """Test scan source with non-existent path."""
        result = runner.invoke(app, ["scan", "source", "/nonexistent/path"])
        assert result.exit_code == 1
        assert "not found" in result.stdout.lower() or "error" in result.stdout.lower()

    def test_scan_source_empty_directory(self, tmp_path: Path) -> None:
        """Test scan source on empty directory."""
        result = runner.invoke(app, ["scan", "source", str(tmp_path)])
        assert result.exit_code == 0
        assert "No security issues" in result.stdout or "Security Score" in result.stdout

    def test_scan_source_with_vulnerabilities(self, vulnerable_source: Path) -> None:
        """Test scan source finds vulnerabilities."""
        result = runner.invoke(app, ["scan", "source", str(vulnerable_source)])
        # Should find command injection, hardcoded secrets, SQL injection
        assert "MCP-SRC" in result.stdout
        assert result.exit_code == 1  # Critical findings

    def test_scan_source_safe_code(self, safe_source: Path) -> None:
        """Test scan source on safe code."""
        result = runner.invoke(app, ["scan", "source", str(safe_source)])
        assert result.exit_code == 0
        assert "No security issues" in result.stdout or "100" in result.stdout

    def test_scan_source_single_file(self, tmp_path: Path) -> None:
        """Test scan source on single file."""
        source_file = tmp_path / "server.py"
        source_file.write_text("""
import os
API_KEY = os.environ.get("API_KEY")
""")

        result = runner.invoke(app, ["scan", "source", str(source_file)])
        assert result.exit_code == 0

    def test_scan_source_json_output(self, tmp_path: Path) -> None:
        """Test scan source with JSON output."""
        source_file = tmp_path / "server.py"
        source_file.write_text('print("hello")')

        result = runner.invoke(app, ["scan", "source", str(source_file), "--format", "json"])
        assert result.exit_code == 0
        # Output should contain JSON-like content
        assert "findings" in result.stdout or "{" in result.stdout

    def test_scan_source_with_ai_flag(self, tmp_path: Path) -> None:
        """Test scan source with --ai flag (should work even without API key)."""
        source_file = tmp_path / "server.py"
        source_file.write_text('print("hello")')

        # Should not crash, even if AI is not configured
        result = runner.invoke(app, ["scan", "source", str(source_file), "--ai"])
        # May succeed or fail gracefully depending on AI availability
        assert result.exit_code in (0, 1)


class TestScanLiveCommand:
    """Tests for the scan live command."""

    def test_scan_live_shows_coming_soon(self) -> None:
        """Test scan live shows coming soon message."""
        result = runner.invoke(app, ["scan", "live", "stdio"])
        assert result.exit_code == 0
        assert "coming soon" in result.stdout.lower()


class TestScanHelp:
    """Tests for scan command help."""

    def test_scan_help(self) -> None:
        """Test scan --help."""
        result = runner.invoke(app, ["scan", "--help"])
        assert result.exit_code == 0
        assert "config" in result.stdout
        assert "source" in result.stdout
        assert "live" in result.stdout

    def test_scan_config_help(self) -> None:
        """Test scan config --help."""
        result = runner.invoke(app, ["scan", "config", "--help"])
        assert result.exit_code == 0
        assert "format" in result.stdout.lower()

    def test_scan_source_help(self) -> None:
        """Test scan source --help."""
        result = runner.invoke(app, ["scan", "source", "--help"])
        assert result.exit_code == 0
        assert "format" in result.stdout.lower()
