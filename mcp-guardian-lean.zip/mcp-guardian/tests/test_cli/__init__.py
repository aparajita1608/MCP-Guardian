"""CLI tests for mcp-guardian."""
