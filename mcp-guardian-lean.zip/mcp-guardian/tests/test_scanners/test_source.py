"""Tests for the source code scanner."""

from pathlib import Path

import pytest

from mcp_guardian.core import Severity
from mcp_guardian.scanners.source import SourceScanner


class TestSourceScanner:
    """Test suite for SourceScanner."""

    def test_scanner_type(self):
        """Test scanner type property."""
        scanner = SourceScanner()
        assert scanner.scanner_type == "source"

    def test_default_rules_loaded(self):
        """Test that default rules are loaded."""
        scanner = SourceScanner()
        assert len(scanner.rules) >= 5
        rule_ids = [r.id for r in scanner.rules]
        assert "MCP-SRC-001" in rule_ids  # Command injection
        assert "MCP-SRC-004" in rule_ids  # Hardcoded secrets

    def test_scan_clean_source(self, safe_source: Path):
        """Test scanning clean source code."""
        scanner = SourceScanner()
        findings = scanner.scan_file(safe_source / "git_tool.py")
        # Safe code should have no critical findings
        critical = [f for f in findings if f.severity == Severity.CRITICAL]
        assert len(critical) == 0

    def test_detect_command_injection(self, vulnerable_source: Path):
        """Test detection of command injection."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "git_tool.py")

        cmd_injection = [f for f in findings if f.rule_id == "MCP-SRC-001"]
        assert len(cmd_injection) >= 1
        assert cmd_injection[0].severity == Severity.CRITICAL
        assert (
            "shell=True" in str(cmd_injection[0].location.snippet) or "subprocess" in cmd_injection[0].message.lower()
        )

    def test_detect_hardcoded_secrets(self, vulnerable_source: Path):
        """Test detection of hardcoded secrets."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "config.py")

        secret_findings = [f for f in findings if f.rule_id == "MCP-SRC-004"]
        assert len(secret_findings) >= 1

    def test_detect_sql_injection(self, vulnerable_source: Path):
        """Test detection of SQL injection."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "database.py")

        sql_findings = [f for f in findings if f.rule_id == "MCP-SRC-003"]
        assert len(sql_findings) >= 1
        assert sql_findings[0].severity == Severity.CRITICAL

    def test_detect_unsafe_deserialization(self, vulnerable_source: Path):
        """Test detection of unsafe deserialization."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "loader.py")

        deser_findings = [f for f in findings if f.rule_id == "MCP-SRC-005"]
        assert len(deser_findings) >= 1
        # Should detect both pickle and yaml.load
        assert len(deser_findings) >= 2

    def test_scan_directory(self, vulnerable_source: Path):
        """Test scanning an entire directory."""
        scanner = SourceScanner()
        from mcp_guardian.core import ScanTarget

        target = ScanTarget(path=vulnerable_source, target_type="source")
        findings = scanner.scan(target)

        # Should find issues in multiple files
        # Note: vulnerable_source is in tmp_path, not in a "test" directory
        assert len(findings) >= 1

        # Check we found different types of issues
        rule_ids = {f.rule_id for f in findings}
        # At minimum we should find command injection or secrets
        assert len(rule_ids) >= 1

    def test_finding_has_line_number(self, vulnerable_source: Path):
        """Test that findings include line numbers."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "git_tool.py")

        for finding in findings:
            assert finding.location.line is not None
            assert finding.location.line > 0

    def test_finding_has_snippet(self, vulnerable_source: Path):
        """Test that findings include code snippets."""
        scanner = SourceScanner()
        findings = scanner.scan_file(vulnerable_source / "git_tool.py")

        for finding in findings:
            assert finding.location.snippet is not None
            assert len(finding.location.snippet) > 0

    def test_skips_git_directories(self, tmp_path: Path):
        """Test that .git directories are skipped."""
        # Create a file in a .git directory
        git_dir = tmp_path / ".git" / "hooks"
        git_dir.mkdir(parents=True)
        (git_dir / "pre-commit.py").write_text("""
import subprocess
subprocess.run("echo test", shell=True)
""")

        scanner = SourceScanner()
        from mcp_guardian.core import ScanTarget

        target = ScanTarget(path=tmp_path, target_type="source")
        findings = scanner.scan(target)

        # Should not scan .git files
        assert len(findings) == 0
