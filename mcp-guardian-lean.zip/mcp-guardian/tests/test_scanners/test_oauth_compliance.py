"""Tests for OAuth 2.1/PKCE compliance checking in ConfigScanner."""

import json
import tempfile
from pathlib import Path

import pytest

from mcp_guardian.scanners.config import ConfigScanner
from mcp_guardian.core.models import ScanTarget, Severity


class TestOAuthCompliance:
    """Test OAuth 2.1/PKCE compliance detection."""

    def setup_method(self):
        """Set up test fixtures."""
        self.scanner = ConfigScanner()

    def _create_config_file(self, config: dict) -> Path:
        """Create a temporary config file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config, f)
            return Path(f.name)

    def test_detects_legacy_oauth2(self):
        """Test detection of legacy OAuth 2.0 (should use 2.1)."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2"  # Legacy OAuth 2.0
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        oauth_findings = [f for f in findings if f.rule_id == "MCP-CFG-008"]
        assert len(oauth_findings) == 1
        assert "OAuth 2.0" in oauth_findings[0].message
        assert "OAuth 2.1" in oauth_findings[0].message

    def test_detects_missing_pkce(self):
        """Test detection of missing PKCE requirement."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "pkce": {
                            "enabled": False
                        }
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        pkce_findings = [f for f in findings if f.rule_id == "MCP-CFG-009"]
        assert len(pkce_findings) == 1
        assert "PKCE" in pkce_findings[0].message

    def test_detects_weak_pkce_method(self):
        """Test detection of weak PKCE method (plain instead of S256)."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "pkce": {
                            "enabled": True,
                            "method": "plain"  # Should be S256
                        }
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        pkce_findings = [f for f in findings if f.rule_id == "MCP-CFG-009"]
        assert len(pkce_findings) == 1
        assert "plain" in pkce_findings[0].message.lower()
        assert pkce_findings[0].severity == Severity.MEDIUM

    def test_detects_wildcard_redirect_uri(self):
        """Test detection of wildcard in redirect URI."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "redirectUris": ["https://app.example.com/*"]  # Wildcard!
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        redirect_findings = [f for f in findings if f.rule_id == "MCP-CFG-010"]
        assert len(redirect_findings) == 1
        assert "wildcard" in redirect_findings[0].message.lower()
        assert redirect_findings[0].severity == Severity.CRITICAL

    def test_detects_http_redirect_uri(self):
        """Test detection of HTTP (non-HTTPS) redirect URI."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "redirectUris": ["http://app.example.com/callback"]  # HTTP!
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        redirect_findings = [f for f in findings if f.rule_id == "MCP-CFG-010"]
        assert len(redirect_findings) == 1
        assert "HTTP" in redirect_findings[0].message

    def test_allows_localhost_http_redirect(self):
        """Test that localhost HTTP redirect is allowed."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "redirectUris": ["http://localhost:3000/callback"]  # OK for localhost
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        # Should not flag localhost HTTP
        redirect_findings = [f for f in findings if f.rule_id == "MCP-CFG-010"]
        assert len(redirect_findings) == 0

    def test_detects_missing_audience(self):
        """Test detection of missing OAuth audience (confused deputy risk)."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1"
                        # Missing audience!
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        audience_findings = [f for f in findings if f.rule_id == "MCP-CFG-011"]
        assert len(audience_findings) == 1
        assert "audience" in audience_findings[0].message.lower()
        assert "confused deputy" in audience_findings[0].message.lower()

    def test_detects_disabled_audience_validation(self):
        """Test detection of explicitly disabled audience validation."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "audience": "https://my-server.com",
                        "validateAudience": False  # Explicitly disabled!
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        audience_findings = [f for f in findings if f.rule_id == "MCP-CFG-011"]
        assert len(audience_findings) == 1
        assert audience_findings[0].severity == Severity.CRITICAL

    def test_compliant_oauth_config(self):
        """Test that a fully compliant OAuth 2.1 config passes."""
        config = {
            "mcpServers": {
                "test-server": {
                    "command": "node",
                    "args": ["server.js"],
                    "transport": "http",
                    "auth": {
                        "type": "oauth2.1",
                        "pkce": {
                            "enabled": True,
                            "method": "S256"
                        },
                        "redirectUris": ["https://app.example.com/oauth/callback"],
                        "audience": "https://my-server.com",
                        "validateAudience": True,
                        "validateScope": True
                    }
                }
            }
        }
        
        config_path = self._create_config_file(config)
        target = ScanTarget(path=config_path, target_type="config")
        
        findings = self.scanner.scan(target)
        
        # Should have no OAuth-related findings
        oauth_findings = [f for f in findings if f.rule_id.startswith("MCP-CFG-00") and int(f.rule_id[-1]) >= 8]
        assert len(oauth_findings) == 0
