"""Tests for the configuration scanner."""

from pathlib import Path

import pytest

from mcp_guardian.core import Severity
from mcp_guardian.scanners.config import ConfigScanner


class TestConfigScanner:
    """Test suite for ConfigScanner."""

    def test_scanner_type(self):
        """Test scanner type property."""
        scanner = ConfigScanner()
        assert scanner.scanner_type == "config"

    def test_default_rules_loaded(self):
        """Test that default rules are loaded."""
        scanner = ConfigScanner()
        assert len(scanner.rules) >= 5
        rule_ids = [r.id for r in scanner.rules]
        assert "MCP-CFG-001" in rule_ids
        assert "MCP-CFG-004" in rule_ids

    def test_scan_clean_config(self, tmp_config_file: Path):
        """Test scanning a clean config file."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(tmp_config_file)
        # Clean config should have no critical/high findings
        critical_high = [f for f in findings if f.severity in (Severity.CRITICAL, Severity.HIGH)]
        assert len(critical_high) == 0

    def test_scan_nonexistent_file(self, tmp_path: Path):
        """Test scanning a file that doesn't exist."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(tmp_path / "nonexistent.json")
        assert len(findings) == 0

    def test_detect_network_exposure(self, vulnerable_config: Path):
        """Test detection of 0.0.0.0 binding."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        network_findings = [f for f in findings if f.rule_id == "MCP-CFG-001"]
        assert len(network_findings) >= 1
        assert "exposed-server" in network_findings[0].message

    def test_detect_shell_injection(self, vulnerable_config: Path):
        """Test detection of shell injection in commands."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        injection_findings = [f for f in findings if f.rule_id == "MCP-CFG-004"]
        assert len(injection_findings) >= 1
        assert injection_findings[0].severity == Severity.CRITICAL

    def test_detect_secrets_in_env(self, vulnerable_config: Path):
        """Test detection of hardcoded secrets."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        secret_findings = [f for f in findings if f.rule_id == "MCP-CFG-006"]
        assert len(secret_findings) >= 1

    def test_detect_unpinned_version(self, vulnerable_config: Path):
        """Test detection of @latest version."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        version_findings = [f for f in findings if f.rule_id == "MCP-CFG-005"]
        assert len(version_findings) >= 1
        assert "@latest" in version_findings[0].message or "unpinned" in version_findings[0].message.lower()

    def test_finding_has_remediation(self, vulnerable_config: Path):
        """Test that all findings have remediation advice."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        for finding in findings:
            assert finding.remediation, f"Finding {finding.rule_id} missing remediation"
            assert len(finding.remediation) > 10

    def test_finding_has_location(self, vulnerable_config: Path):
        """Test that all findings have location information."""
        scanner = ConfigScanner()
        findings = scanner.scan_file(vulnerable_config)

        for finding in findings:
            assert finding.location.file == vulnerable_config
