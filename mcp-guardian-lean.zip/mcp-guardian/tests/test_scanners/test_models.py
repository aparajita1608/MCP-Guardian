"""Tests for core models."""

import pytest
from pydantic import ValidationError

from mcp_guardian.core import (
    Category,
    Finding,
    Location,
    Severity,
    calculate_risk_score,
    get_risk_level,
)


class TestSeverity:
    """Test Severity enum."""

    def test_severity_values(self):
        """Test severity enum values."""
        assert Severity.CRITICAL.value == "critical"
        assert Severity.HIGH.value == "high"
        assert Severity.MEDIUM.value == "medium"
        assert Severity.LOW.value == "low"
        assert Severity.INFO.value == "info"


class TestLocation:
    """Test Location model."""

    def test_location_str_with_line(self, tmp_path):
        """Test location string representation with line number."""
        loc = Location(file=tmp_path / "test.py", line=42)
        assert "test.py:42" in str(loc)

    def test_location_str_without_line(self, tmp_path):
        """Test location string representation without line number."""
        loc = Location(file=tmp_path / "test.py")
        assert "test.py" in str(loc)
        assert ":" not in str(loc)


class TestFinding:
    """Test Finding model."""

    def test_finding_creation(self, tmp_path):
        """Test creating a finding."""
        finding = Finding(
            rule_id="MCP-TEST-001",
            severity=Severity.HIGH,
            category=Category.COMMAND_INJECTION,
            title="Test Finding",
            message="This is a test finding",
            location=Location(file=tmp_path / "test.py", line=10),
            remediation="Fix the issue",
        )
        assert finding.rule_id == "MCP-TEST-001"
        assert finding.severity == Severity.HIGH
        assert not finding.is_ai_detected

    def test_finding_with_ai_confidence(self, tmp_path):
        """Test finding with AI confidence score."""
        finding = Finding(
            rule_id="MCP-TEST-001",
            severity=Severity.HIGH,
            category=Category.TOOL_POISONING,
            title="AI Detected Issue",
            message="Detected by AI",
            location=Location(file=tmp_path / "test.py"),
            remediation="Review the tool description",
            ai_confidence=0.95,
            ai_explanation="Hidden instruction detected",
        )
        assert finding.is_ai_detected
        assert finding.ai_confidence == 0.95

    def test_finding_ai_confidence_validation(self, tmp_path):
        """Test AI confidence must be between 0 and 1."""
        with pytest.raises(ValidationError):
            Finding(
                rule_id="MCP-TEST-001",
                severity=Severity.HIGH,
                category=Category.COMMAND_INJECTION,
                title="Test",
                message="Test",
                location=Location(file=tmp_path / "test.py"),
                remediation="Fix it",
                ai_confidence=1.5,  # Invalid: > 1.0
            )


class TestRiskScoring:
    """Test risk scoring functions."""

    def test_perfect_score_no_findings(self):
        """Test perfect score with no findings."""
        score = calculate_risk_score([])
        assert score == 100

    def test_score_decreases_with_findings(self, tmp_path):
        """Test score decreases with findings."""
        findings = [
            Finding(
                rule_id="MCP-TEST-001",
                severity=Severity.HIGH,
                category=Category.COMMAND_INJECTION,
                title="Test",
                message="Test",
                location=Location(file=tmp_path / "test.py"),
                remediation="Fix it",
            )
        ]
        score = calculate_risk_score(findings)
        assert score < 100

    def test_critical_findings_reduce_score_more(self, tmp_path):
        """Test critical findings reduce score more than low."""
        critical_finding = Finding(
            rule_id="MCP-TEST-001",
            severity=Severity.CRITICAL,
            category=Category.COMMAND_INJECTION,
            title="Critical",
            message="Critical issue",
            location=Location(file=tmp_path / "test.py"),
            remediation="Fix it",
        )
        low_finding = Finding(
            rule_id="MCP-TEST-002",
            severity=Severity.LOW,
            category=Category.CONFIGURATION,
            title="Low",
            message="Low issue",
            location=Location(file=tmp_path / "test.py"),
            remediation="Fix it",
        )

        critical_score = calculate_risk_score([critical_finding])
        low_score = calculate_risk_score([low_finding])

        assert critical_score < low_score

    def test_score_never_negative(self, tmp_path):
        """Test score never goes below 0."""
        # Create many critical findings
        findings = [
            Finding(
                rule_id=f"MCP-TEST-{i:03d}",
                severity=Severity.CRITICAL,
                category=Category.COMMAND_INJECTION,
                title=f"Critical {i}",
                message="Critical issue",
                location=Location(file=tmp_path / "test.py"),
                remediation="Fix it",
            )
            for i in range(20)
        ]
        score = calculate_risk_score(findings)
        assert score >= 0

    def test_get_risk_level(self):
        """Test risk level descriptions."""
        assert get_risk_level(95) == "EXCELLENT"
        assert get_risk_level(75) == "GOOD"
        assert get_risk_level(55) == "MODERATE"
        assert get_risk_level(35) == "HIGH RISK"
        assert get_risk_level(15) == "CRITICAL"
