"""Tests for CVE Benchmark Ingestion from MITRE cvelistV5."""

import json
import tempfile
from pathlib import Path

import pytest

from mcp_guardian.benchmark import (
    CVEBenchmarkIngester,
    CVERecord,
    CVESeverity,
    AttackVector,
    MCPBenchmarkCase,
    get_known_mcp_cve,
    KNOWN_MCP_CVES,
)


class TestCVEBenchmarkIngester:
    """Test CVE benchmark ingestion."""

    def setup_method(self):
        """Set up test fixtures."""
        self.ingester = CVEBenchmarkIngester()

    def test_parse_cve_json(self):
        """Test parsing CVE JSON 5.1 schema."""
        cve_data = {
            "cveMetadata": {
                "cveId": "CVE-2025-12345",
                "datePublished": "2025-06-15T10:00:00Z",
                "dateUpdated": "2025-06-20T15:30:00Z",
            },
            "containers": {
                "cna": {
                    "descriptions": [
                        {
                            "lang": "en",
                            "value": "Command injection vulnerability in MCP server"
                        }
                    ],
                    "affected": [
                        {
                            "vendor": "example",
                            "product": "mcp-server",
                            "versions": [
                                {"version": "1.0.0"},
                                {"version": "1.1.0"}
                            ]
                        }
                    ],
                    "problemTypes": [
                        {
                            "descriptions": [
                                {"cweId": "CWE-78"}
                            ]
                        }
                    ],
                    "metrics": [
                        {
                            "cvssV3_1": {
                                "baseScore": 9.8,
                                "baseSeverity": "CRITICAL"
                            }
                        }
                    ],
                    "references": [
                        {"url": "https://github.com/example/mcp-server/security/advisories/GHSA-xxxx-xxxx-xxxx"}
                    ]
                }
            }
        }
        
        record = self.ingester._parse_cve_json(cve_data)
        
        assert record is not None
        assert record.cve_id == "CVE-2025-12345"
        assert record.severity == CVESeverity.CRITICAL
        assert record.cvss_score == 9.8
        assert "CWE-78" in record.cwe_ids
        assert "example/mcp-server" in record.affected_products
        assert len(record.github_advisories) == 1

    def test_filter_mcp_related(self):
        """Test filtering for MCP-related CVEs."""
        # Add some test records
        mcp_record = CVERecord(
            cve_id="CVE-2025-1111",
            title="MCP Vulnerability",
            description="Vulnerability in MCP server implementation",
            severity=CVESeverity.HIGH,
            cwe_ids=["CWE-78"],
            affected_products=["mcp-remote"],
        )
        
        non_mcp_record = CVERecord(
            cve_id="CVE-2025-2222",
            title="Other Vulnerability",
            description="Vulnerability in unrelated software",
            severity=CVESeverity.MEDIUM,
            cwe_ids=["CWE-79"],
            affected_products=["some-other-package"],
        )
        
        chainlit_record = CVERecord(
            cve_id="CVE-2026-45018",
            title="Chainlit MCP Vulnerability",
            description="Command injection when features.mcp.enabled is active",
            severity=CVESeverity.CRITICAL,
            cvss_score=9.8,
            cwe_ids=["CWE-78"],
            affected_products=["chainlit"],
        )
        
        self.ingester.cve_records = [mcp_record, non_mcp_record, chainlit_record]
        
        mcp_cves = self.ingester.filter_mcp_related()
        
        assert len(mcp_cves) == 2
        assert mcp_record in mcp_cves
        assert chainlit_record in mcp_cves
        assert non_mcp_record not in mcp_cves
        
        # Check that attack vectors are assigned
        for cve in mcp_cves:
            assert cve.is_mcp_related is True
            assert cve.attack_vector == AttackVector.COMMAND_INJECTION

    def test_filter_by_cwe(self):
        """Test filtering by CWE ID."""
        records = [
            CVERecord(cve_id="CVE-1", title="", description="", severity=CVESeverity.HIGH, cwe_ids=["CWE-78"]),
            CVERecord(cve_id="CVE-2", title="", description="", severity=CVESeverity.HIGH, cwe_ids=["CWE-94"]),
            CVERecord(cve_id="CVE-3", title="", description="", severity=CVESeverity.HIGH, cwe_ids=["CWE-78", "CWE-94"]),
        ]
        
        self.ingester.cve_records = records
        
        cwe78_cves = self.ingester.filter_by_cwe("CWE-78")
        
        assert len(cwe78_cves) == 2
        assert records[0] in cwe78_cves
        assert records[2] in cwe78_cves

    def test_filter_by_severity(self):
        """Test filtering by minimum severity."""
        records = [
            CVERecord(cve_id="CVE-1", title="", description="", severity=CVESeverity.LOW),
            CVERecord(cve_id="CVE-2", title="", description="", severity=CVESeverity.MEDIUM),
            CVERecord(cve_id="CVE-3", title="", description="", severity=CVESeverity.HIGH),
            CVERecord(cve_id="CVE-4", title="", description="", severity=CVESeverity.CRITICAL),
        ]
        
        self.ingester.cve_records = records
        
        high_and_above = self.ingester.filter_by_severity(CVESeverity.HIGH)
        
        assert len(high_and_above) == 2
        assert records[2] in high_and_above
        assert records[3] in high_and_above

    def test_generate_benchmark_case(self):
        """Test generating benchmark case from CVE record."""
        record = CVERecord(
            cve_id="CVE-2025-6514",
            title="mcp-remote command injection",
            description="OS command injection in mcp-remote package",
            severity=CVESeverity.CRITICAL,
            cvss_score=9.8,
            cwe_ids=["CWE-78"],
            affected_products=["mcp-remote"],
            attack_vector=AttackVector.COMMAND_INJECTION,
            is_mcp_related=True,
        )
        
        case = self.ingester._generate_case_from_cve(record)
        
        assert case is not None
        assert case.cve_id == "CVE-2025-6514"
        assert case.cwe == "CWE-78"
        assert case.severity == "critical"
        assert "execute_command" in case.vulnerable_tool.get("name", "")
        assert case.expected_detection["mcp_guardian"] is True
        assert "Taint Tracking" in case.detection_mechanism

    def test_export_benchmark_cases(self):
        """Test exporting benchmark cases to JSON files."""
        cases = [
            MCPBenchmarkCase(
                cve_id="CVE-2025-6514",
                name="cve_2025_6514_command_injection",
                description="Test case for CVE-2025-6514",
                severity="critical",
                cwe="CWE-78",
                vulnerable_tool={"name": "test_tool"},
                attack_payload="; rm -rf /",
                attack_flow=["user_input", "shell_exec"],
                expected_detection={"mcp_guardian": True},
                detection_mechanism="Taint Tracking",
            )
        ]
        
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "benchmark_output"
            self.ingester.export_benchmark_cases(cases, output_dir)
            
            # Check file was created
            output_file = output_dir / "cve_2025_6514_command_injection.json"
            assert output_file.exists()
            
            # Check content
            with open(output_file) as f:
                data = json.load(f)
            
            assert data["cve_id"] == "CVE-2025-6514"
            assert data["cwe"] == "CWE-78"
            assert data["expected_detection"]["mcp_guardian"] is True


class TestKnownMCPCVEs:
    """Test known MCP CVE patterns."""

    def test_known_cves_exist(self):
        """Test that known MCP CVEs are defined."""
        assert "CVE-2025-6514" in KNOWN_MCP_CVES
        assert "CVE-2025-49596" in KNOWN_MCP_CVES
        assert "CVE-2026-45018" in KNOWN_MCP_CVES

    def test_get_known_mcp_cve(self):
        """Test retrieving known CVE details."""
        cve = get_known_mcp_cve("CVE-2025-6514")
        
        assert cve is not None
        assert cve["component"] == "mcp-remote"
        assert cve["cwe"] == "CWE-78"
        assert cve["attack_vector"] == AttackVector.COMMAND_INJECTION
        assert "Taint Tracking" in cve["detection"]

    def test_get_unknown_cve_returns_none(self):
        """Test that unknown CVE returns None."""
        cve = get_known_mcp_cve("CVE-9999-99999")
        assert cve is None

    def test_cve_2025_6514_details(self):
        """Test CVE-2025-6514 (mcp-remote command injection) details."""
        cve = KNOWN_MCP_CVES["CVE-2025-6514"]
        
        assert cve["name"] == "mcp_remote_command_injection"
        assert cve["component"] == "mcp-remote"
        assert cve["cwe"] == "CWE-78"
        assert "stdio" in cve["description"].lower() or "command" in cve["description"].lower()

    def test_cve_2025_49596_details(self):
        """Test CVE-2025-49596 (Anthropic MCP Inspector RCE) details."""
        cve = KNOWN_MCP_CVES["CVE-2025-49596"]
        
        assert cve["name"] == "anthropic_mcp_inspector_rce"
        assert "Anthropic" in cve["component"]
        assert cve["cwe"] == "CWE-94"
        assert cve["attack_vector"] == AttackVector.REMOTE_CODE_EXECUTION

    def test_cve_2026_45018_details(self):
        """Test CVE-2026-45018 (Chainlit MCP command injection) details."""
        cve = KNOWN_MCP_CVES["CVE-2026-45018"]
        
        assert cve["component"] == "Chainlit"
        assert cve["cvss"] == 9.8
        assert "mcp.enabled" in cve["description"].lower()
