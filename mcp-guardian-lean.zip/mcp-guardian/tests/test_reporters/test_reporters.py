"""Tests for reporters."""

from pathlib import Path

import pytest

from mcp_guardian.core import Category, Finding, Location, Severity
from mcp_guardian.reporters import generate_html_report, generate_json_report, generate_sarif


@pytest.fixture
def sample_findings(tmp_path: Path) -> list[Finding]:
    """Create sample findings for testing."""
    return [
        Finding(
            rule_id="MCP-SRC-001",
            severity=Severity.CRITICAL,
            category=Category.COMMAND_INJECTION,
            title="Command Injection",
            message="Unsanitized input in subprocess",
            location=Location(file=tmp_path / "server.py", line=42, snippet="subprocess.run(cmd, shell=True)"),
            remediation="Use shell=False",
            cwe_id="CWE-78",
        ),
        Finding(
            rule_id="MCP-SRC-004",
            severity=Severity.HIGH,
            category=Category.SECRETS_EXPOSURE,
            title="Hardcoded Secret",
            message="API key found in source",
            location=Location(file=tmp_path / "config.py", line=10),
            remediation="Use environment variables",
        ),
        Finding(
            rule_id="MCP-CFG-005",
            severity=Severity.MEDIUM,
            category=Category.CONFIGURATION,
            title="Unpinned Version",
            message="Using @latest",
            location=Location(file=tmp_path / "mcp.json"),
            remediation="Pin to specific version",
        ),
    ]


class TestHTMLReporter:
    """Test HTML report generation."""

    def test_generate_html_report(self, sample_findings: list[Finding]):
        """Test HTML report generation."""
        html = generate_html_report(sample_findings, title="Test Report")

        assert "<!DOCTYPE html>" in html
        assert "Test Report" in html
        assert "MCP-SRC-001" in html
        assert "Command Injection" in html
        assert "CRITICAL" in html.upper()

    def test_generate_html_report_empty(self):
        """Test HTML report with no findings."""
        html = generate_html_report([], title="Clean Report")

        assert "No Security Issues Found" in html
        assert "100" in html  # Perfect score

    def test_generate_html_report_has_score(self, sample_findings: list[Finding]):
        """Test HTML report includes risk score."""
        html = generate_html_report(sample_findings)

        # Should have score visualization
        assert "score-circle" in html
        assert "Security Score" in html

    def test_generate_html_report_has_remediation(self, sample_findings: list[Finding]):
        """Test HTML report includes remediation."""
        html = generate_html_report(sample_findings)

        assert "Remediation" in html
        assert "Use shell=False" in html


class TestJSONReporter:
    """Test JSON report generation."""

    def test_generate_json_report(self, sample_findings: list[Finding]):
        """Test JSON report generation."""
        import json

        json_str = generate_json_report(sample_findings, title="Test Report")
        report = json.loads(json_str)

        assert "metadata" in report
        assert "summary" in report
        assert "findings" in report
        assert len(report["findings"]) == 3

    def test_generate_json_report_has_summary(self, sample_findings: list[Finding]):
        """Test JSON report includes summary."""
        import json

        json_str = generate_json_report(sample_findings)
        report = json.loads(json_str)

        assert report["summary"]["total_findings"] == 3
        assert report["summary"]["by_severity"]["critical"] == 1
        assert report["summary"]["by_severity"]["high"] == 1

    def test_generate_json_report_empty(self):
        """Test JSON report with no findings."""
        import json

        json_str = generate_json_report([])
        report = json.loads(json_str)

        assert report["summary"]["total_findings"] == 0
        assert report["summary"]["score"] == 100


class TestSARIFReporter:
    """Test SARIF report generation."""

    def test_generate_sarif(self, sample_findings: list[Finding]):
        """Test SARIF report generation."""
        import json

        sarif_str = generate_sarif(sample_findings)
        sarif = json.loads(sarif_str)

        assert sarif["version"] == "2.1.0"
        assert "runs" in sarif
        assert len(sarif["runs"]) == 1

    def test_generate_sarif_has_rules(self, sample_findings: list[Finding]):
        """Test SARIF report includes rules."""
        import json

        sarif_str = generate_sarif(sample_findings)
        sarif = json.loads(sarif_str)

        rules = sarif["runs"][0]["tool"]["driver"]["rules"]
        rule_ids = [r["id"] for r in rules]

        assert "MCP-SRC-001" in rule_ids
        assert "MCP-SRC-004" in rule_ids

    def test_generate_sarif_has_results(self, sample_findings: list[Finding]):
        """Test SARIF report includes results."""
        import json

        sarif_str = generate_sarif(sample_findings)
        sarif = json.loads(sarif_str)

        results = sarif["runs"][0]["results"]
        assert len(results) == 3

    def test_generate_sarif_severity_mapping(self, sample_findings: list[Finding]):
        """Test SARIF severity mapping."""
        import json

        sarif_str = generate_sarif(sample_findings)
        sarif = json.loads(sarif_str)

        results = sarif["runs"][0]["results"]
        # Critical should map to "error"
        critical_result = next(r for r in results if r["ruleId"] == "MCP-SRC-001")
        assert critical_result["level"] == "error"
