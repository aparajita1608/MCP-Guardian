"""Test AI package."""
