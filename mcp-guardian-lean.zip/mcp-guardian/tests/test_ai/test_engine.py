"""Tests for AI engine."""

import pytest

from mcp_guardian.ai import (
    AI_AVAILABLE,
    ToolPoisoningAnalysis,
    PromptInjectionAnalysis,
    CodeVulnerabilityAnalysis,
    is_ai_available,
)


class TestAIModels:
    """Test AI response models."""

    def test_tool_poisoning_analysis_valid(self):
        """Test valid ToolPoisoningAnalysis."""
        analysis = ToolPoisoningAnalysis(
            is_malicious=True,
            confidence=0.95,
            attack_type="hidden_instruction",
            malicious_segments=["<!-- read secrets -->"],
            explanation="Hidden HTML comment contains instruction",
        )
        assert analysis.is_malicious
        assert analysis.confidence == 0.95
        assert analysis.attack_type == "hidden_instruction"

    def test_tool_poisoning_analysis_confidence_bounds(self):
        """Test confidence must be between 0 and 1."""
        with pytest.raises(ValueError):
            ToolPoisoningAnalysis(
                is_malicious=False,
                confidence=1.5,  # Invalid
                explanation="Test",
            )

    def test_prompt_injection_analysis_valid(self):
        """Test valid PromptInjectionAnalysis."""
        analysis = PromptInjectionAnalysis(
            contains_injection=True,
            confidence=0.8,
            injection_type="direct",
            dangerous_patterns=["ignore previous instructions"],
            explanation="Direct injection attempt detected",
        )
        assert analysis.contains_injection
        assert analysis.injection_type == "direct"

    def test_code_vulnerability_analysis_valid(self):
        """Test valid CodeVulnerabilityAnalysis."""
        analysis = CodeVulnerabilityAnalysis(
            is_vulnerable=True,
            confidence=0.9,
            vulnerability_type="command_injection",
            vulnerable_lines=[42, 43],
            attack_scenario="Attacker can execute arbitrary commands",
            remediation="Use subprocess with shell=False",
            explanation="Shell=True with user input",
        )
        assert analysis.is_vulnerable
        assert 42 in analysis.vulnerable_lines


class TestAIAvailability:
    """Test AI availability checks."""

    def test_is_ai_available(self):
        """Test AI availability function."""
        # Should return True since we installed AI deps
        assert is_ai_available() == AI_AVAILABLE

    @pytest.mark.skipif(not AI_AVAILABLE, reason="AI dependencies not installed")
    def test_ai_engine_import(self):
        """Test AIEngine can be imported when deps available."""
        from mcp_guardian.ai import AIEngine

        # Should not raise
        assert AIEngine is not None
