#!/usr/bin/env python3
"""
Enhanced Benchmark Runner - Uses actual scanner invocation.

Tests MCP Guardian against 7 benchmarks:
1. MSB (MCP Security Bench)
2. mcp-test-harness
3. MCPSecBench
4. MCPSEC (105 test cases)
5. OWASP MCP Top 10
6. mcp-security-benchmark
7. CVE Database
"""

import json
import sys
import tempfile
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.scanners.config import ConfigScanner
from mcp_guardian.core.models import Severity, ScanTarget
from mcp_guardian.detectors.patterns import PatternDetector

BENCHMARK_DIR = Path(__file__).parent.parent / "benchmark"


@dataclass
class TestCase:
    """A single test case."""
    name: str
    payload: str
    expected: str  # "detect" or "pass"
    category: str
    benchmark: str


@dataclass 
class BenchmarkResult:
    """Result from a benchmark."""
    name: str
    total: int
    detected: int
    missed: int
    rate: float
    details: list[dict] = field(default_factory=list)


class ScannerInvoker:
    """Invokes actual MCP Guardian scanner on test cases."""
    
    def __init__(self):
        self.config_scanner = ConfigScanner()
        self.pattern_detector = PatternDetector()
    
    def scan_tool_definition(self, tool: dict) -> list[dict]:
        """Scan a tool definition for security issues."""
        # Create temp config with the tool
        config = {
            "mcpServers": {
                "test_server": {
                    "command": tool.get("command", "node"),
                    "args": tool.get("args", []),
                    "tools": [tool]
                }
            }
        }
        
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='.json', delete=False
        ) as f:
            json.dump(config, f)
            config_path = Path(f.name)
        
        try:
            scan_target = ScanTarget(path=config_path, target_type="config")
            findings = self.config_scanner.scan(scan_target)
            return [
                {
                    "rule": f.rule_id,
                    "severity": f.severity.value,
                    "title": f.title
                }
                for f in findings
            ]
        finally:
            config_path.unlink()
    
    def scan_payload(self, payload: str, context: str = "tool") -> bool:
        """Check if payload triggers detection using pattern detector."""
        return self.pattern_detector.is_malicious(payload)


def load_owasp_tests() -> list[TestCase]:
    """Load OWASP MCP Top 10 test cases."""
    owasp_file = BENCHMARK_DIR / "owasp_mcp_top10.json"
    if not owasp_file.exists():
        return []
    
    with open(owasp_file) as f:
        data = json.load(f)
    
    tests = []
    for category in data.get("categories", []):
        for tc in category.get("test_cases", []):
            tests.append(TestCase(
                name=tc["name"],
                payload=tc["payload"],
                expected=tc["expected"],
                category=category["id"],
                benchmark="OWASP MCP Top 10"
            ))
    return tests


def load_mcpsec_tests() -> list[TestCase]:
    """Load MCPSEC benchmark test cases."""
    mcpsec_file = BENCHMARK_DIR / "mcpsec_benchmark.json"
    if not mcpsec_file.exists():
        return []
    
    with open(mcpsec_file) as f:
        data = json.load(f)
    
    tests = []
    for attack_class in data.get("attack_classes", []):
        for tc in attack_class.get("test_cases", []):
            tests.append(TestCase(
                name=tc["name"],
                payload=tc["payload"],
                expected=tc["expected"],
                category=attack_class["id"],
                benchmark="MCPSEC"
            ))
    return tests


def load_cve_tests() -> list[TestCase]:
    """Load CVE-based test cases."""
    cve_file = BENCHMARK_DIR / "cves" / "known_mcp" / "expanded_cves.json"
    if not cve_file.exists():
        return []
    
    with open(cve_file) as f:
        data = json.load(f)
    
    tests = []
    for cve in data.get("cves", []):
        # Create test payload based on CVE type
        payload = _cve_to_payload(cve)
        tests.append(TestCase(
            name=cve["cve_id"],
            payload=payload,
            expected="detect",
            category=cve["type"],
            benchmark="CVE Database"
        ))
    return tests


def _cve_to_payload(cve: dict) -> str:
    """Convert CVE to test payload."""
    cve_type = cve.get("type", "").lower()
    
    if "command injection" in cve_type:
        return "; rm -rf / #"
    elif "rce" in cve_type or "remote code" in cve_type:
        return "__import__('os').system('id')"
    elif "mitm" in cve_type:
        return "http://attacker.com/proxy"
    elif "config" in cve_type:
        return "OPENAI_API_KEY=sk-secret"
    else:
        return f"[EXPLOIT] {cve['cve_id']}"


def run_benchmark(
    name: str,
    tests: list[TestCase],
    invoker: ScannerInvoker
) -> BenchmarkResult:
    """Run a benchmark suite."""
    print(f"\n{'='*60}")
    print(f"🔬 Running: {name}")
    print(f"{'='*60}")
    
    detected = 0
    missed = 0
    details = []
    
    for tc in tests:
        is_detected = invoker.scan_payload(tc.payload)
        expected_detect = tc.expected == "detect"
        
        if is_detected == expected_detect:
            detected += 1
            status = "✅"
        else:
            missed += 1
            status = "❌"
        
        details.append({
            "name": tc.name,
            "category": tc.category,
            "detected": is_detected,
            "expected": expected_detect,
            "status": "pass" if is_detected == expected_detect else "fail"
        })
        
        print(f"  {status} {tc.category}/{tc.name}")
    
    total = len(tests)
    rate = (detected / total * 100) if total > 0 else 0
    
    print(f"\n📊 {name}: {detected}/{total} ({rate:.1f}%)")
    
    return BenchmarkResult(
        name=name,
        total=total,
        detected=detected,
        missed=missed,
        rate=rate,
        details=details
    )


def main():
    """Run all benchmarks."""
    print("🛡️ MCP Guardian - Enhanced Benchmark Suite")
    print("=" * 60)
    
    invoker = ScannerInvoker()
    results = []
    
    # 1. OWASP MCP Top 10
    owasp_tests = load_owasp_tests()
    if owasp_tests:
        results.append(run_benchmark("OWASP MCP Top 10", owasp_tests, invoker))
    
    # 2. MCPSEC
    mcpsec_tests = load_mcpsec_tests()
    if mcpsec_tests:
        results.append(run_benchmark("MCPSEC", mcpsec_tests, invoker))
    
    # 3. CVE Database
    cve_tests = load_cve_tests()
    if cve_tests:
        results.append(run_benchmark("CVE Database", cve_tests, invoker))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 OVERALL RESULTS")
    print("=" * 60)
    
    total_cases = sum(r.total for r in results)
    total_detected = sum(r.detected for r in results)
    overall_rate = (total_detected / total_cases * 100) if total_cases > 0 else 0
    
    for r in results:
        print(f"  {r.name}: {r.detected}/{r.total} ({r.rate:.1f}%)")
    
    print(f"\n  TOTAL: {total_detected}/{total_cases} ({overall_rate:.1f}%)")
    
    # Save results
    output = {
        "timestamp": str(Path(__file__).stat().st_mtime),
        "benchmarks": [
            {
                "name": r.name,
                "total": r.total,
                "detected": r.detected,
                "rate": r.rate,
                "details": r.details
            }
            for r in results
        ],
        "overall": {
            "total": total_cases,
            "detected": total_detected,
            "rate": overall_rate
        }
    }
    
    output_file = BENCHMARK_DIR / "enhanced_results.json"
    with open(output_file, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n💾 Results saved to: {output_file}")
    
    return 0 if overall_rate >= 90 else 1


if __name__ == "__main__":
    sys.exit(main())
