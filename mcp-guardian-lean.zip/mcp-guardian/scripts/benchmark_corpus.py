#!/usr/bin/env python3
"""
Corpus-based Benchmark Runner.

Tests MCP Guardian against real attack corpus:
1. MSB tool poisoning samples
2. Real CVE payloads
3. Benign samples (false positive testing)
"""

import json
import sys
from pathlib import Path
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.detectors.pattern_loader import ExternalizedPatternDetector

CORPUS_DIR = Path(__file__).parent.parent / "benchmark"
PATTERNS_DIR = Path(__file__).parent.parent / "patterns"


@dataclass
class CorpusResult:
    """Result from corpus testing."""
    corpus_name: str
    total: int
    correct: int
    false_positives: int
    false_negatives: int
    accuracy: float
    details: list[dict] = field(default_factory=list)


def load_corpus_file(filepath: Path) -> list[dict]:
    """Load samples from a corpus file."""
    with open(filepath) as f:
        data = json.load(f)
    return data.get("samples", [])


def test_corpus(
    name: str,
    samples: list[dict],
    detector: ExternalizedPatternDetector,
    is_malicious_corpus: bool
) -> CorpusResult:
    """Test a corpus of samples."""
    print(f"\n{'='*60}")
    print(f"🔬 Testing: {name}")
    print(f"   Expected: {'Malicious' if is_malicious_corpus else 'Benign'}")
    print(f"{'='*60}")
    
    correct = 0
    false_positives = 0
    false_negatives = 0
    details = []
    
    for sample in samples:
        payload = sample.get("payload", "")
        expected = sample.get("expected", "detect" if is_malicious_corpus else "pass")
        expected_detect = expected == "detect"
        
        # Run detection
        is_detected = detector.is_malicious(payload)
        detections = detector.detect(payload) if is_detected else []
        
        # Evaluate result
        if is_detected == expected_detect:
            correct += 1
            status = "✅"
        elif is_detected and not expected_detect:
            false_positives += 1
            status = "⚠️ FP"
        else:
            false_negatives += 1
            status = "❌ FN"
        
        sample_id = sample.get("id", sample.get("cve_id", "unknown"))
        attack_type = sample.get("attack_type", "unknown")
        
        details.append({
            "id": sample_id,
            "attack_type": attack_type,
            "detected": is_detected,
            "expected": expected_detect,
            "correct": is_detected == expected_detect,
            "detections": [
                {
                    "pattern_id": d.pattern_id,
                    "category": d.category,
                    "confidence": d.confidence
                }
                for d in detections[:3]
            ]
        })
        
        # Show result
        if is_detected == expected_detect:
            print(f"  {status} {sample_id}")
        else:
            print(f"  {status} {sample_id} ({attack_type})")
            if detections:
                print(f"      Detected: {[d.pattern_id for d in detections[:2]]}")
    
    total = len(samples)
    accuracy = (correct / total * 100) if total > 0 else 0
    
    print(f"\n📊 {name}:")
    print(f"   Accuracy: {correct}/{total} ({accuracy:.1f}%)")
    print(f"   False Positives: {false_positives}")
    print(f"   False Negatives: {false_negatives}")
    
    return CorpusResult(
        corpus_name=name,
        total=total,
        correct=correct,
        false_positives=false_positives,
        false_negatives=false_negatives,
        accuracy=accuracy,
        details=details
    )


def main():
    """Run corpus-based benchmarks."""
    print("🛡️ MCP Guardian - Corpus-Based Benchmark")
    print("=" * 60)
    
    # Initialize detector
    detector = ExternalizedPatternDetector(PATTERNS_DIR)
    stats = detector.get_stats()
    print(f"\n📋 Loaded {stats['total_patterns']} patterns")
    
    results = []
    
    # Test malicious corpus
    malicious_dir = CORPUS_DIR / "malicious"
    if malicious_dir.exists():
        for corpus_file in malicious_dir.glob("*.json"):
            samples = load_corpus_file(corpus_file)
            if samples:
                result = test_corpus(
                    corpus_file.stem,
                    samples,
                    detector,
                    is_malicious_corpus=True
                )
                results.append(result)
    
    # Test benign corpus
    benign_dir = CORPUS_DIR / "benign"
    if benign_dir.exists():
        for corpus_file in benign_dir.glob("*.json"):
            samples = load_corpus_file(corpus_file)
            if samples:
                result = test_corpus(
                    corpus_file.stem,
                    samples,
                    detector,
                    is_malicious_corpus=False
                )
                results.append(result)
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 CORPUS BENCHMARK SUMMARY")
    print("=" * 60)
    
    total_samples = sum(r.total for r in results)
    total_correct = sum(r.correct for r in results)
    total_fp = sum(r.false_positives for r in results)
    total_fn = sum(r.false_negatives for r in results)
    overall_accuracy = (total_correct / total_samples * 100) if total_samples > 0 else 0
    
    for r in results:
        fp_indicator = f" (FP: {r.false_positives})" if r.false_positives > 0 else ""
        fn_indicator = f" (FN: {r.false_negatives})" if r.false_negatives > 0 else ""
        print(f"  {r.corpus_name}: {r.accuracy:.1f}%{fp_indicator}{fn_indicator}")
    
    print(f"\n  OVERALL: {overall_accuracy:.1f}%")
    print(f"  Total False Positives: {total_fp}")
    print(f"  Total False Negatives: {total_fn}")
    
    # Calculate precision/recall
    # True Positives = malicious detected correctly
    # False Positives = benign detected as malicious
    # False Negatives = malicious not detected
    
    malicious_results = [r for r in results if "benign" not in r.corpus_name.lower()]
    benign_results = [r for r in results if "benign" in r.corpus_name.lower()]
    
    tp = sum(r.correct for r in malicious_results)
    fn = sum(r.false_negatives for r in malicious_results)
    fp = sum(r.false_positives for r in benign_results)
    tn = sum(r.correct for r in benign_results)
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    print(f"\n  Precision: {precision:.2%}")
    print(f"  Recall: {recall:.2%}")
    print(f"  F1 Score: {f1:.2%}")
    
    # Save results
    output = {
        "corpus_results": [
            {
                "name": r.corpus_name,
                "total": r.total,
                "correct": r.correct,
                "false_positives": r.false_positives,
                "false_negatives": r.false_negatives,
                "accuracy": r.accuracy,
                "details": r.details
            }
            for r in results
        ],
        "summary": {
            "total_samples": total_samples,
            "overall_accuracy": overall_accuracy,
            "total_false_positives": total_fp,
            "total_false_negatives": total_fn,
            "precision": precision,
            "recall": recall,
            "f1_score": f1
        }
    }
    
    output_file = CORPUS_DIR / "corpus_results.json"
    with open(output_file, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n💾 Results saved to: {output_file}")
    
    return 0 if overall_accuracy >= 85 else 1


if __name__ == "__main__":
    sys.exit(main())
