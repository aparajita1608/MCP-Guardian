#!/usr/bin/env python3
"""
Telemetry Demo.

Demonstrates the telemetry infrastructure by simulating detections and FP reports.
"""

import sys
from pathlib import Path
import tempfile

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.detectors import ExternalizedPatternDetector
from mcp_guardian.telemetry import TelemetryCollector

PATTERNS_DIR = Path(__file__).parent.parent / "patterns"


def main():
    print("🛡️ MCP Guardian - Telemetry Demo")
    print("=" * 60)
    
    # Create temporary telemetry directory
    with tempfile.TemporaryDirectory() as tmpdir:
        collector = TelemetryCollector(data_dir=tmpdir)
        detector = ExternalizedPatternDetector(PATTERNS_DIR)
        
        print(f"\n📁 Telemetry data: {tmpdir}")
        
        # Simulate some detections
        test_cases = [
            # True positives
            ("rm -rf /", "Destructive command"),
            ("__import__('os').system('id')", "Code execution"),
            ("ignore previous instructions", "Prompt injection"),
            ("sk-abc123xyz789", "API key exposure"),
            
            # False positives (benign text that triggers patterns)
            ("Send a message to the user", "Benign send"),
            ("Execute the test suite", "Benign execute"),
            ("Return the result to the caller", "Benign return"),
        ]
        
        print("\n📝 Simulating detections...")
        
        event_ids = []
        for text, description in test_cases:
            detections = detector.detect(text)
            
            if detections:
                d = detections[0]
                event_id = collector.record_detection(
                    pattern_id=d.pattern_id,
                    category=d.category,
                    severity=d.severity.value,
                    confidence=d.confidence,
                    text=text,
                    metadata={"description": description},
                )
                event_ids.append((event_id, d.pattern_id, description))
                print(f"   ✅ Detected: {d.pattern_id} - {description}")
            else:
                print(f"   ⚪ No detection: {description}")
        
        # Simulate user feedback
        print("\n📣 Simulating user feedback...")
        
        # Mark some as true positives
        for event_id, pattern_id, desc in event_ids[:4]:
            collector.confirm_true_positive(event_id)
            print(f"   ✅ Confirmed TP: {pattern_id}")
        
        # Report some as false positives
        for event_id, pattern_id, desc in event_ids[4:]:
            collector.report_false_positive(
                detection_event_id=event_id,
                pattern_id=pattern_id,
                category="data_exfiltration",
                reason=f"Benign usage: {desc}",
            )
            print(f"   ⚠️ Reported FP: {pattern_id}")
        
        # Show metrics
        print("\n📊 Pattern Metrics:")
        print("-" * 60)
        
        metrics = collector.get_pattern_metrics()
        for pattern_id, m in sorted(metrics.items()):
            print(f"   {pattern_id}:")
            print(f"      Total: {m.total_detections}, TP: {m.confirmed_true_positives}, FP: {m.confirmed_false_positives}")
            print(f"      Precision: {m.precision:.1%}")
        
        # Show FP rate by category
        print("\n📉 FP Rate by Category:")
        print("-" * 60)
        
        fp_rates = collector.get_fp_rate_by_category()
        for cat, rate in sorted(fp_rates.items(), key=lambda x: -x[1]):
            print(f"   {cat}: {rate:.1%}")
        
        # Export data
        export_file = Path(tmpdir) / "export.json"
        count = collector.export_for_analysis(export_file)
        print(f"\n💾 Exported {count} events to {export_file}")
        
        print("\n✅ Demo complete!")
        print("\nIn production, telemetry data would be stored at:")
        print("   ~/.mcp-guardian/telemetry/")


if __name__ == "__main__":
    main()
