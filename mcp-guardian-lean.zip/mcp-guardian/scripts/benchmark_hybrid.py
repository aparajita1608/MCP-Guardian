#!/usr/bin/env python3
"""
Hybrid Detector Benchmark.

Tests the hybrid pattern + AI detector against the corpus.
Compares pattern-only vs hybrid detection.
"""

import json
import sys
import os
from pathlib import Path
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.detectors.pattern_loader import ExternalizedPatternDetector
from mcp_guardian.detectors.hybrid import HybridDetector

CORPUS_DIR = Path(__file__).parent.parent / "benchmark"
PATTERNS_DIR = Path(__file__).parent.parent / "patterns"


@dataclass
class ComparisonResult:
    """Comparison between pattern-only and hybrid detection."""
    sample_id: str
    expected: str
    pattern_detected: bool
    hybrid_detected: bool
    pattern_correct: bool
    hybrid_correct: bool
    ai_marked_fp: bool
    ai_reasoning: str | None


def load_all_samples() -> list[dict]:
    """Load all corpus samples."""
    samples = []
    
    # Malicious samples
    malicious_dir = CORPUS_DIR / "malicious"
    if malicious_dir.exists():
        for f in malicious_dir.glob("*.json"):
            with open(f) as fp:
                data = json.load(fp)
                for s in data.get("samples", []):
                    s["_corpus"] = "malicious"
                    s["_file"] = f.stem
                    samples.append(s)
    
    # Benign samples
    benign_dir = CORPUS_DIR / "benign"
    if benign_dir.exists():
        for f in benign_dir.glob("*.json"):
            with open(f) as fp:
                data = json.load(fp)
                for s in data.get("samples", []):
                    s["_corpus"] = "benign"
                    s["_file"] = f.stem
                    samples.append(s)
    
    return samples


def run_comparison(samples: list[dict], use_ai: bool = False) -> list[ComparisonResult]:
    """Run comparison between pattern-only and hybrid detection."""
    
    # Initialize detectors
    pattern_detector = ExternalizedPatternDetector(PATTERNS_DIR)
    
    if use_ai:
        hybrid_detector = HybridDetector(
            patterns_dir=PATTERNS_DIR,
            ai_enabled=True,
        )
    else:
        hybrid_detector = None
    
    results = []
    
    for sample in samples:
        payload = sample.get("payload", "")
        expected = sample.get("expected", "detect" if sample["_corpus"] == "malicious" else "pass")
        expected_detect = expected == "detect"
        sample_id = sample.get("id", sample.get("cve_id", "unknown"))
        
        # Pattern-only detection
        pattern_detected = pattern_detector.is_malicious(payload)
        pattern_correct = pattern_detected == expected_detect
        
        # Hybrid detection (if AI available)
        if hybrid_detector and use_ai:
            hybrid_detections = hybrid_detector.detect(payload, validate_with_ai=True)
            real_threats = [d for d in hybrid_detections if not d.is_false_positive]
            hybrid_detected = len(real_threats) > 0
            ai_marked_fp = any(d.is_false_positive for d in hybrid_detections)
            ai_reasoning = hybrid_detections[0].ai_reasoning if hybrid_detections else None
        else:
            hybrid_detected = pattern_detected
            ai_marked_fp = False
            ai_reasoning = None
        
        hybrid_correct = hybrid_detected == expected_detect
        
        results.append(ComparisonResult(
            sample_id=sample_id,
            expected=expected,
            pattern_detected=pattern_detected,
            hybrid_detected=hybrid_detected,
            pattern_correct=pattern_correct,
            hybrid_correct=hybrid_correct,
            ai_marked_fp=ai_marked_fp,
            ai_reasoning=ai_reasoning,
        ))
    
    return results


def main():
    """Run hybrid detector benchmark."""
    print("🛡️ MCP Guardian - Hybrid Detector Benchmark")
    print("=" * 60)
    
    # Check if AI is available
    ai_available = bool(os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY"))
    
    if ai_available:
        print("✅ AI API key found - running hybrid comparison")
    else:
        print("⚠️ No AI API key - running pattern-only benchmark")
        print("   Set OPENAI_API_KEY or ANTHROPIC_API_KEY to enable AI validation")
    
    # Load samples
    samples = load_all_samples()
    print(f"\n📋 Loaded {len(samples)} samples")
    
    # Run comparison
    results = run_comparison(samples, use_ai=ai_available)
    
    # Calculate metrics
    pattern_correct = sum(1 for r in results if r.pattern_correct)
    hybrid_correct = sum(1 for r in results if r.hybrid_correct)
    ai_fps_caught = sum(1 for r in results if r.ai_marked_fp and not r.pattern_correct)
    
    total = len(results)
    
    print("\n" + "=" * 60)
    print("📊 RESULTS")
    print("=" * 60)
    
    print(f"\n  Pattern-Only Accuracy: {pattern_correct}/{total} ({pattern_correct/total*100:.1f}%)")
    
    if ai_available:
        print(f"  Hybrid Accuracy:       {hybrid_correct}/{total} ({hybrid_correct/total*100:.1f}%)")
        print(f"  AI False Positives Caught: {ai_fps_caught}")
        
        improvement = hybrid_correct - pattern_correct
        if improvement > 0:
            print(f"\n  ✅ AI improved accuracy by {improvement} samples")
        elif improvement < 0:
            print(f"\n  ⚠️ AI reduced accuracy by {-improvement} samples")
        else:
            print(f"\n  ➡️ AI had no impact on accuracy")
    
    # Show specific improvements/regressions
    print("\n📋 Sample-by-Sample Analysis:")
    
    for r in results:
        if r.pattern_correct != r.hybrid_correct:
            if r.hybrid_correct:
                print(f"  ✅ IMPROVED: {r.sample_id}")
                if r.ai_reasoning:
                    print(f"     AI: {r.ai_reasoning[:80]}...")
            else:
                print(f"  ❌ REGRESSED: {r.sample_id}")
                if r.ai_reasoning:
                    print(f"     AI: {r.ai_reasoning[:80]}...")
        elif not r.pattern_correct:
            status = "FP" if r.pattern_detected else "FN"
            print(f"  ⚠️ BOTH WRONG ({status}): {r.sample_id}")
    
    # Save results
    output = {
        "ai_enabled": ai_available,
        "total_samples": total,
        "pattern_accuracy": pattern_correct / total,
        "hybrid_accuracy": hybrid_correct / total if ai_available else None,
        "results": [
            {
                "sample_id": r.sample_id,
                "expected": r.expected,
                "pattern_detected": r.pattern_detected,
                "hybrid_detected": r.hybrid_detected,
                "pattern_correct": r.pattern_correct,
                "hybrid_correct": r.hybrid_correct,
                "ai_marked_fp": r.ai_marked_fp,
            }
            for r in results
        ]
    }
    
    output_file = CORPUS_DIR / "hybrid_results.json"
    with open(output_file, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n💾 Results saved to: {output_file}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
