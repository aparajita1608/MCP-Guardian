#!/usr/bin/env python3
"""
Telemetry Dashboard CLI.

View and analyze MCP Guardian telemetry data.
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.telemetry import TelemetryCollector


def show_summary(collector: TelemetryCollector):
    """Show telemetry summary."""
    print("📊 MCP Guardian Telemetry Summary")
    print("=" * 50)
    
    # Get pattern metrics
    metrics = collector.get_pattern_metrics()
    
    if not metrics:
        print("\n⚠️ No telemetry data found")
        print(f"   Data directory: {collector.data_dir}")
        return
    
    # Overall stats
    total_detections = sum(m.total_detections for m in metrics.values())
    total_tp = sum(m.confirmed_true_positives for m in metrics.values())
    total_fp = sum(m.confirmed_false_positives for m in metrics.values())
    total_unknown = sum(m.unknown for m in metrics.values())
    
    print(f"\n📈 Overall Statistics:")
    print(f"   Total Detections: {total_detections}")
    print(f"   Confirmed True Positives: {total_tp}")
    print(f"   Confirmed False Positives: {total_fp}")
    print(f"   Unknown: {total_unknown}")
    
    if total_tp + total_fp > 0:
        overall_precision = total_tp / (total_tp + total_fp)
        print(f"   Overall Precision: {overall_precision:.1%}")
    
    # FP rate by category
    fp_by_category = collector.get_fp_rate_by_category()
    if fp_by_category:
        print(f"\n📉 False Positive Rate by Category:")
        for cat, rate in sorted(fp_by_category.items(), key=lambda x: -x[1]):
            if rate > 0:
                print(f"   {cat}: {rate:.1%}")
    
    # Top FP patterns
    fp_patterns = sorted(
        [(m.pattern_id, m.confirmed_false_positives, m.precision) 
         for m in metrics.values() if m.confirmed_false_positives > 0],
        key=lambda x: -x[1]
    )
    
    if fp_patterns:
        print(f"\n⚠️ Patterns with Most False Positives:")
        for pattern_id, fp_count, precision in fp_patterns[:10]:
            print(f"   {pattern_id}: {fp_count} FPs (precision: {precision:.1%})")


def show_pattern_details(collector: TelemetryCollector, pattern_id: str):
    """Show details for a specific pattern."""
    metrics = collector.get_pattern_metrics()
    
    if pattern_id not in metrics:
        print(f"❌ Pattern not found: {pattern_id}")
        return
    
    m = metrics[pattern_id]
    
    print(f"📋 Pattern Details: {pattern_id}")
    print("=" * 50)
    print(f"   Total Detections: {m.total_detections}")
    print(f"   True Positives: {m.confirmed_true_positives}")
    print(f"   False Positives: {m.confirmed_false_positives}")
    print(f"   Unknown: {m.unknown}")
    print(f"   Precision: {m.precision:.1%}")
    print(f"   Last Updated: {m.last_updated}")


def export_data(collector: TelemetryCollector, output_file: str):
    """Export telemetry data."""
    count = collector.export_for_analysis(output_file)
    print(f"✅ Exported {count} events to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="MCP Guardian Telemetry Dashboard")
    parser.add_argument(
        "--data-dir",
        type=str,
        default=None,
        help="Telemetry data directory",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Summary command
    subparsers.add_parser("summary", help="Show telemetry summary")
    
    # Pattern details command
    pattern_parser = subparsers.add_parser("pattern", help="Show pattern details")
    pattern_parser.add_argument("pattern_id", help="Pattern ID")
    
    # Export command
    export_parser = subparsers.add_parser("export", help="Export telemetry data")
    export_parser.add_argument("output", help="Output file path")
    
    args = parser.parse_args()
    
    collector = TelemetryCollector(data_dir=args.data_dir)
    
    if args.command == "summary" or args.command is None:
        show_summary(collector)
    elif args.command == "pattern":
        show_pattern_details(collector, args.pattern_id)
    elif args.command == "export":
        export_data(collector, args.output)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
