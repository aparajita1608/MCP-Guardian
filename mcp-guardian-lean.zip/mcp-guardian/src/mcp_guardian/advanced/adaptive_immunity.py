"""Adaptive Pattern Learning - Supporting Mechanism for MCP Guardian.

⚠️  PATENT STATUS: This module is a SUPPORTING MECHANISM, not a standalone claim.
    Per patent counsel feedback, pattern learning with temporal decay is considered
    standard practice. This functionality is folded into the primary claims:
    - Schema Mutation Detection (uses pattern matching for intent classification)
    - Capability Chain Analysis (uses learned patterns for risk scoring)
    - Cross-Tool Taint Tracking (uses patterns for violation detection)

This module provides:
- Weighted signature matching for MCP JSON-RPC schemas
- Temporal decay for pattern relevance
- Admin-controlled feedback loop with guardrails

The core innovation is NOT the pattern learning itself, but its application
to MCP-specific schema analysis without source code access.
"""

import hashlib
import json
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from ..core.logging import get_logger
from ..core.models import Category, Finding, Severity

logger = get_logger(__name__)


class UserAction(str, Enum):
    """User actions for feedback on findings."""

    CONFIRMED_THREAT = "confirmed_threat"
    FALSE_POSITIVE = "false_positive"
    NEEDS_REVIEW = "needs_review"
    SUPPRESSED = "suppressed"


class Epitope(BaseModel):
    """Transferable attack structure - the "signature" of an attack pattern.

    Unlike literal string matching, epitopes capture the semantic structure
    of an attack, allowing detection of variants.
    """

    pattern_hash: str = Field(description="Hash of the normalized pattern")
    category: Category = Field(description="Attack category")
    structural_features: list[str] = Field(
        default_factory=list,
        description="Structural features of the attack (e.g., 'shell_metachar', 'user_input_concat')",
    )
    semantic_tags: list[str] = Field(default_factory=list, description="Semantic tags describing the attack intent")

    @classmethod
    def from_finding(cls, finding: Finding) -> "Epitope":
        """Extract epitope from a finding."""
        # Normalize the pattern to create a transferable signature
        snippet = finding.location.snippet or ""

        # Extract structural features
        features = []
        if any(c in snippet for c in ["|", ";", "&&", "||"]):
            features.append("shell_metachar")
        if "+" in snippet or "format" in snippet or "f'" in snippet or 'f"' in snippet:
            features.append("string_concat")
        if "input" in snippet.lower() or "request" in snippet.lower():
            features.append("user_input")
        if "exec" in snippet or "eval" in snippet:
            features.append("code_execution")
        if "sql" in snippet.lower() or "query" in snippet.lower():
            features.append("database_access")

        # Create pattern hash from normalized features
        pattern_str = f"{finding.category.value}:{':'.join(sorted(features))}"
        pattern_hash = hashlib.sha256(pattern_str.encode()).hexdigest()[:16]

        return cls(
            pattern_hash=pattern_hash,
            category=finding.category,
            structural_features=features,
            semantic_tags=[finding.category.value],
        )


class Antibody(BaseModel):
    """Security antibody representing a learned attack pattern.

    Antibodies mature over time based on user feedback, increasing
    confidence in detection accuracy.
    """

    id: str = Field(description="Unique antibody identifier")
    epitope: Epitope = Field(description="Attack pattern signature")
    maturity_score: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Confidence score based on feedback (0.0-1.0)"
    )
    immune_response: str = Field(description="Recommended remediation action")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_matched: datetime | None = Field(default=None)
    match_count: int = Field(default=0)
    confirmed_count: int = Field(default=0)
    false_positive_count: int = Field(default=0)
    suppressed: bool = Field(default=False)
    user_notes: str | None = Field(default=None)

    def mature(self, confirmed: bool = True) -> None:
        """Mature the antibody based on user feedback."""
        self.match_count += 1
        self.last_matched = datetime.now(timezone.utc)

        if confirmed:
            self.confirmed_count += 1
            # Increase maturity (asymptotic approach to 1.0)
            self.maturity_score = min(1.0, self.maturity_score + 0.1 * (1 - self.maturity_score))
        else:
            self.false_positive_count += 1
            # Decrease maturity
            self.maturity_score = max(0.0, self.maturity_score - 0.15)

    def suppress(self) -> None:
        """Suppress this antibody (user marked as false positive)."""
        self.suppressed = True
        self.maturity_score = 0.0

    @property
    def accuracy_rate(self) -> float:
        """Calculate accuracy rate based on feedback."""
        total = self.confirmed_count + self.false_positive_count
        if total == 0:
            return 0.5  # Unknown
        return self.confirmed_count / total


class AntibodyLibrary(BaseModel):
    """Persistent library of security antibodies.

    Stores learned attack patterns and their maturity scores,
    enabling cross-session learning.
    """

    antibodies: dict[str, Antibody] = Field(default_factory=dict)
    version: str = Field(default="1.0.0")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_updated: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def add(self, finding: Finding, immune_response: str | None = None) -> Antibody:
        """Add a new antibody from a finding."""
        epitope = Epitope.from_finding(finding)

        # Check if similar antibody exists
        existing = self.match(finding)
        if existing:
            return existing

        antibody = Antibody(
            id=f"AB-{epitope.pattern_hash}",
            epitope=epitope,
            immune_response=immune_response or finding.remediation,
        )

        self.antibodies[antibody.id] = antibody
        self.last_updated = datetime.now(timezone.utc)

        logger.info(
            "antibody_created",
            antibody_id=antibody.id,
            category=epitope.category.value,
        )

        return antibody

    def match(self, finding: Finding) -> Antibody | None:
        """Find matching antibody for a finding."""
        epitope = Epitope.from_finding(finding)

        # Direct hash match
        antibody_id = f"AB-{epitope.pattern_hash}"
        if antibody_id in self.antibodies:
            antibody = self.antibodies[antibody_id]
            if not antibody.suppressed:
                return antibody

        # Fuzzy match based on structural features
        for antibody in self.antibodies.values():
            if antibody.suppressed:
                continue

            # Check category match
            if antibody.epitope.category != epitope.category:
                continue

            # Check feature overlap
            common_features = set(antibody.epitope.structural_features) & set(epitope.structural_features)
            if len(common_features) >= 2:  # At least 2 common features
                return antibody

        return None

    def mature(self, finding: Finding) -> None:
        """Mature antibody based on confirmed threat."""
        antibody = self.match(finding)
        if antibody:
            antibody.mature(confirmed=True)
            self.last_updated = datetime.now(timezone.utc)
            logger.info(
                "antibody_matured",
                antibody_id=antibody.id,
                maturity=antibody.maturity_score,
            )

    def suppress(self, finding: Finding) -> None:
        """Suppress antibody based on false positive feedback."""
        antibody = self.match(finding)
        if antibody:
            antibody.mature(confirmed=False)
            if antibody.maturity_score < 0.2:
                antibody.suppress()
            self.last_updated = datetime.now(timezone.utc)
            logger.info(
                "antibody_suppressed",
                antibody_id=antibody.id,
                maturity=antibody.maturity_score,
            )

    def get_active_antibodies(self) -> list[Antibody]:
        """Get all active (non-suppressed) antibodies."""
        return [ab for ab in self.antibodies.values() if not ab.suppressed]

    def save(self, path: Path) -> None:
        """Save library to disk."""
        path.write_text(self.model_dump_json(indent=2))
        logger.info("antibody_library_saved", path=str(path))

    @classmethod
    def load(cls, path: Path) -> "AntibodyLibrary":
        """Load library from disk."""
        if not path.exists():
            return cls()

        try:
            data = json.loads(path.read_text())
            return cls.model_validate(data)
        except Exception as e:
            logger.warning("antibody_library_load_failed", error=str(e))
            return cls()


class UserBoundaryModel(BaseModel):
    """User-specific security boundary definitions.

    Learns what the user considers acceptable vs. unacceptable
    based on their feedback patterns.
    """

    allowed_patterns: list[str] = Field(default_factory=list)
    blocked_patterns: list[str] = Field(default_factory=list)
    severity_threshold: Severity = Field(default=Severity.MEDIUM)
    trusted_sources: list[str] = Field(default_factory=list)

    def is_within_boundary(self, finding: Finding) -> bool:
        """Check if finding is within user's acceptable boundary."""
        # Check if source is trusted
        file_path = str(finding.location.file)
        for trusted in self.trusted_sources:
            if trusted in file_path:
                return True

        # Check severity threshold
        severity_order = [Severity.INFO, Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
        if severity_order.index(finding.severity) < severity_order.index(self.severity_threshold):
            return True

        return False

    def learn_from_feedback(self, finding: Finding, action: UserAction) -> None:
        """Update boundary model based on user feedback."""
        snippet = finding.location.snippet or ""

        if action == UserAction.FALSE_POSITIVE:
            # User says this is acceptable
            if snippet and snippet not in self.allowed_patterns:
                self.allowed_patterns.append(snippet[:100])
        elif action == UserAction.CONFIRMED_THREAT:
            # User confirms this is a threat
            if snippet and snippet not in self.blocked_patterns:
                self.blocked_patterns.append(snippet[:100])


class AdaptiveImmunityEngine:
    """Main engine for adaptive immunity-based security scanning.

    Combines rule-based scanning with learned patterns from user feedback
    to provide personalized, evolving security analysis.
    """

    DEFAULT_LIBRARY_PATH = Path.home() / ".mcp-guardian" / "antibody_library.json"

    def __init__(
        self,
        library_path: Path | None = None,
        auto_save: bool = True,
    ):
        """Initialize the adaptive immunity engine.

        Args:
            library_path: Path to antibody library file
            auto_save: Whether to auto-save library after updates
        """
        self.library_path = library_path or self.DEFAULT_LIBRARY_PATH
        self.library_path.parent.mkdir(parents=True, exist_ok=True)

        self.antibody_library = AntibodyLibrary.load(self.library_path)
        self.user_boundary_model = UserBoundaryModel()
        self.auto_save = auto_save

        logger.info(
            "adaptive_immunity_initialized",
            antibody_count=len(self.antibody_library.antibodies),
        )

    def enhance_findings(self, findings: list[Finding]) -> list[Finding]:
        """Enhance findings with antibody-based confidence scores.

        Args:
            findings: List of findings from rule-based scan

        Returns:
            Enhanced findings with adjusted confidence and remediation
        """
        enhanced = []

        for finding in findings:
            # Check against antibody library
            antibody = self.antibody_library.match(finding)

            if antibody:
                # Enhance with antibody data
                finding.ai_confidence = antibody.maturity_score
                finding.ai_explanation = (
                    f"Matched antibody {antibody.id} with {antibody.accuracy_rate:.0%} accuracy "
                    f"({antibody.confirmed_count} confirmed, {antibody.false_positive_count} false positives)"
                )

                # Use antibody's immune response if more specific
                if antibody.immune_response and len(antibody.immune_response) > len(finding.remediation):
                    finding.remediation = antibody.immune_response
            else:
                # New pattern - add to library for future learning
                self.antibody_library.add(finding)

            # Check user boundary
            if self.user_boundary_model.is_within_boundary(finding):
                finding.metadata["within_user_boundary"] = True

            enhanced.append(finding)

        if self.auto_save:
            self.antibody_library.save(self.library_path)

        return enhanced

    def learn_from_feedback(self, finding: Finding, action: UserAction) -> None:
        """Process user feedback to improve future detection.

        Args:
            finding: The finding user provided feedback on
            action: User's action (confirmed, false positive, etc.)
        """
        if action == UserAction.CONFIRMED_THREAT:
            self.antibody_library.mature(finding)
        elif action == UserAction.FALSE_POSITIVE:
            self.antibody_library.suppress(finding)
        elif action == UserAction.SUPPRESSED:
            # Find and suppress the antibody
            antibody = self.antibody_library.match(finding)
            if antibody:
                antibody.suppress()

        # Update user boundary model
        self.user_boundary_model.learn_from_feedback(finding, action)

        if self.auto_save:
            self.antibody_library.save(self.library_path)

        logger.info(
            "feedback_processed",
            action=action.value,
            rule_id=finding.rule_id,
        )

    def get_statistics(self) -> dict[str, Any]:
        """Get statistics about the immunity system."""
        active = self.antibody_library.get_active_antibodies()

        return {
            "total_antibodies": len(self.antibody_library.antibodies),
            "active_antibodies": len(active),
            "suppressed_antibodies": len(self.antibody_library.antibodies) - len(active),
            "average_maturity": sum(ab.maturity_score for ab in active) / len(active) if active else 0,
            "total_matches": sum(ab.match_count for ab in self.antibody_library.antibodies.values()),
            "library_version": self.antibody_library.version,
            "last_updated": self.antibody_library.last_updated.isoformat(),
        }
