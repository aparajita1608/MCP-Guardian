"""Advanced security analysis features for MCP Guardian.

This module contains novel security analysis capabilities:

PRIMARY CLAIMS (Patent-Protected):
1. Schema Mutation Detection - LSH fingerprinting of MCP JSON-RPC schemas
2. Capability Chain Analysis - Pre-computed directed graphs with blast radius scoring
3. Cross-Tool Taint Tracking - Dual-lattice model mapped to schema parameters

SUPPORTING MECHANISMS (Standard Practice):
4. Adaptive Pattern Learning - Weighted signature matching with temporal decay
   (Folded into primary claims, not standalone)
"""

from .adaptive_immunity import (
    AdaptiveImmunityEngine,
    Antibody,
    AntibodyLibrary,
    UserAction,
)
from .attack_chain import (
    AttackChain,
    AttackChainAnalyzer,
    CapabilityGraph,
)
from .information_flow import (
    FlowAnalysis,
    FlowViolation,
    InformationFlowAnalyzer,
    TaintLabel,
)
from .semantic_drift import (
    DriftAnalysis,
    SemanticDriftDetector,
    SemanticFingerprint,
    SemanticLockfile,
)

__all__ = [
    # Supporting Mechanism: Adaptive Pattern Learning
    # (Folded into primary claims, not standalone)
    "AdaptiveImmunityEngine",
    "Antibody",
    "AntibodyLibrary",
    "UserAction",
    # Primary Claim: Schema Mutation Detection
    "SemanticDriftDetector",
    "SemanticFingerprint",
    "SemanticLockfile",
    "DriftAnalysis",
    # Primary Claim: Capability Chain Analysis
    "AttackChainAnalyzer",
    "AttackChain",
    "CapabilityGraph",
    # Primary Claim: Cross-Tool Taint Tracking
    "InformationFlowAnalyzer",
    "TaintLabel",
    "FlowViolation",
    "FlowAnalysis",
]
