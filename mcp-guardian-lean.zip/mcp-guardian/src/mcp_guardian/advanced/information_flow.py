"""Information Flow Control for MCP Tool Chains.

Applies information flow control to track how untrusted data flows
through MCP tool chains during scanning.

Patent Claim: A method for tracking information flow through MCP
tool chains using dual-lattice taint analysis:
1. Confidentiality lattice: Tracks sensitive data propagation
2. Integrity lattice: Tracks untrusted input influence
3. Cross-tool flow analysis: Detects when untrusted data reaches
   sensitive operations across tool boundaries
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from ..core.logging import get_logger
from ..core.models import Category, Finding, Location, Severity, ToolDefinition

logger = get_logger(__name__)


class ConfidentialityLevel(str, Enum):
    """Confidentiality levels for data classification."""

    PUBLIC = "public"  # Can be shared freely
    INTERNAL = "internal"  # Internal use only
    CONFIDENTIAL = "confidential"  # Restricted access
    SECRET = "secret"  # Highly sensitive


class IntegrityLevel(str, Enum):
    """Integrity levels for data trustworthiness."""

    TRUSTED = "trusted"  # From verified source
    VALIDATED = "validated"  # User input that was validated
    UNTRUSTED = "untrusted"  # Unvalidated user input
    MALICIOUS = "malicious"  # Known malicious input


class FlowViolationType(str, Enum):
    """Types of information flow violations."""

    UNTRUSTED_TO_SECRET = "untrusted_to_secret"
    UNTRUSTED_TO_EXEC = "untrusted_to_exec"
    SECRET_TO_PUBLIC = "secret_to_public"
    CROSS_TOOL_TAINT = "cross_tool_taint"
    IMPLICIT_FLOW = "implicit_flow"


@dataclass
class TaintLabel:
    """Taint label combining confidentiality and integrity.

    Uses a dual-lattice approach where:
    - Confidentiality flows upward (public → secret)
    - Integrity flows downward (trusted → untrusted)
    """

    confidentiality: set[ConfidentialityLevel] = field(default_factory=lambda: {ConfidentialityLevel.PUBLIC})
    integrity: set[IntegrityLevel] = field(default_factory=lambda: {IntegrityLevel.TRUSTED})
    source_tool: str | None = None
    source_param: str | None = None

    def is_tainted(self) -> bool:
        """Check if this label represents tainted data."""
        return IntegrityLevel.UNTRUSTED in self.integrity or IntegrityLevel.MALICIOUS in self.integrity

    def is_sensitive(self) -> bool:
        """Check if this label represents sensitive data."""
        return (
            ConfidentialityLevel.SECRET in self.confidentiality
            or ConfidentialityLevel.CONFIDENTIAL in self.confidentiality
        )

    def merge_with(self, other: "TaintLabel") -> "TaintLabel":
        """Merge two taint labels (for data combination)."""
        return TaintLabel(
            confidentiality=self.confidentiality | other.confidentiality,
            integrity=self.integrity | other.integrity,
            source_tool=self.source_tool or other.source_tool,
            source_param=self.source_param or other.source_param,
        )

    def propagate(self) -> "TaintLabel":
        """Propagate taint through an operation."""
        # Taint propagates conservatively
        return TaintLabel(
            confidentiality=self.confidentiality.copy(),
            integrity=self.integrity.copy(),
            source_tool=self.source_tool,
            source_param=self.source_param,
        )


class FlowViolation(BaseModel):
    """Represents an information flow violation."""

    tool: str = Field(description="Tool where violation occurred")
    input_param: str | None = Field(default=None)
    output_param: str | None = Field(default=None)
    violation_type: FlowViolationType
    severity: Severity

    # Flow details
    source_label: dict[str, Any] = Field(default_factory=dict)
    sink_label: dict[str, Any] = Field(default_factory=dict)

    # Context
    description: str = Field(default="")
    cross_tool: bool = Field(default=False)
    source_tool: str | None = Field(default=None)


class FlowAnalysis(BaseModel):
    """Result of information flow analysis."""

    violations: list[FlowViolation] = Field(default_factory=list)
    tool_count: int = Field(default=0)
    tainted_flows: int = Field(default=0)
    sensitive_flows: int = Field(default=0)

    @property
    def has_violations(self) -> bool:
        """Check if any violations were found."""
        return len(self.violations) > 0

    @property
    def critical_violations(self) -> list[FlowViolation]:
        """Get critical severity violations."""
        return [v for v in self.violations if v.severity == Severity.CRITICAL]


@dataclass
class ToolFlowModel:
    """Model of information flow through a single tool."""

    tool: ToolDefinition
    input_labels: dict[str, TaintLabel] = field(default_factory=dict)
    output_labels: dict[str, TaintLabel] = field(default_factory=dict)
    internal_flows: list[tuple[str, str]] = field(default_factory=list)

    def add_input(self, param: str, label: TaintLabel) -> None:
        """Add an input parameter with its taint label."""
        self.input_labels[param] = label

    def add_output(self, param: str, label: TaintLabel) -> None:
        """Add an output parameter with its taint label."""
        self.output_labels[param] = label

    def add_flow(self, from_param: str, to_param: str) -> None:
        """Add an internal flow from input to output."""
        self.internal_flows.append((from_param, to_param))


class InformationFlowAnalyzer:
    """Analyzer for information flow through MCP tool chains.

    Tracks how data flows through tools and detects violations
    where untrusted data reaches sensitive operations.
    """

    # Sensitive operations that should not receive untrusted input
    SENSITIVE_OPERATIONS: set[str] = {
        "execute",
        "exec",
        "run",
        "eval",
        "query",
        "sql",
        "command",
        "shell",
        "system",
        "write",
        "delete",
        "credential",
        "password",
        "token",
        "secret",
        "key",
    }

    # Parameters that typically contain sensitive data
    SENSITIVE_PARAMS: set[str] = {
        "password",
        "token",
        "secret",
        "key",
        "credential",
        "api_key",
        "auth",
        "private",
        "certificate",
    }

    # Parameters that typically receive user input
    USER_INPUT_PARAMS: set[str] = {
        "input",
        "query",
        "search",
        "text",
        "content",
        "data",
        "message",
        "body",
        "payload",
        "request",
    }

    def __init__(self) -> None:
        """Initialize the information flow analyzer."""
        self.tool_models: dict[str, ToolFlowModel] = {}

    def analyze_tool_chain(self, tools: list[ToolDefinition]) -> FlowAnalysis:
        """Analyze information flow across a tool chain.

        Args:
            tools: List of tool definitions in execution order

        Returns:
            Flow analysis with any violations
        """
        violations: list[FlowViolation] = []
        tainted_flows = 0
        sensitive_flows = 0

        # Build flow models for each tool
        for tool in tools:
            model = self._build_tool_model(tool)
            self.tool_models[tool.name] = model

        # Analyze each tool
        for i, tool in enumerate(tools):
            model = self.tool_models[tool.name]

            # Label inputs
            input_labels = self._label_inputs(tool)
            model.input_labels = input_labels

            # Propagate through tool
            output_labels = self._propagate_labels(tool, input_labels)
            model.output_labels = output_labels

            # Check for violations within tool
            tool_violations = self._check_violations(tool, input_labels, output_labels)
            violations.extend(tool_violations)

            # Track flow statistics
            for label in input_labels.values():
                if label.is_tainted():
                    tainted_flows += 1
                if label.is_sensitive():
                    sensitive_flows += 1

            # Check cross-tool flows
            if i < len(tools) - 1:
                next_tool = tools[i + 1]
                cross_violations = self._check_cross_tool_flow(tool, output_labels, next_tool)
                violations.extend(cross_violations)

        logger.info(
            "flow_analysis_complete",
            tools=len(tools),
            violations=len(violations),
            tainted_flows=tainted_flows,
        )

        return FlowAnalysis(
            violations=violations,
            tool_count=len(tools),
            tainted_flows=tainted_flows,
            sensitive_flows=sensitive_flows,
        )

    def analyze_single_tool(self, tool: ToolDefinition) -> FlowAnalysis:
        """Analyze information flow within a single tool.

        Args:
            tool: Tool definition to analyze

        Returns:
            Flow analysis with any violations
        """
        return self.analyze_tool_chain([tool])

    def get_findings(self, analysis: FlowAnalysis) -> list[Finding]:
        """Convert flow analysis to findings.

        Args:
            analysis: Flow analysis result

        Returns:
            List of security findings
        """
        findings: list[Finding] = []

        for i, violation in enumerate(analysis.violations):
            finding = Finding(
                rule_id=f"MCP-FLOW-{i + 1:03d}",
                severity=violation.severity,
                category=Category.PROMPT_INJECTION if violation.cross_tool else Category.COMMAND_INJECTION,
                title=f"Information Flow Violation: {violation.violation_type.value}",
                message=violation.description,
                location=Location(
                    file=f"tools/{violation.tool}",
                    snippet=f"Input: {violation.input_param} → Output: {violation.output_param}",
                ),
                remediation=self._get_remediation(violation),
                cwe_id=self._get_cwe(violation),
                metadata={
                    "violation_type": violation.violation_type.value,
                    "cross_tool": violation.cross_tool,
                    "source_tool": violation.source_tool,
                },
            )
            findings.append(finding)

        return findings

    def _build_tool_model(self, tool: ToolDefinition) -> ToolFlowModel:
        """Build a flow model for a tool."""
        model = ToolFlowModel(tool=tool)

        # Analyze schema to determine flows
        if tool.input_schema:
            props = tool.input_schema.get("properties", {})
            for param in props:
                # Assume all inputs flow to all outputs (conservative)
                model.add_flow(param, "result")

        return model

    def _label_inputs(self, tool: ToolDefinition) -> dict[str, TaintLabel]:
        """Assign taint labels to tool inputs."""
        labels: dict[str, TaintLabel] = {}

        if not tool.input_schema:
            return labels

        props = tool.input_schema.get("properties", {})

        for param, prop_def in props.items():
            param_lower = param.lower()

            # Determine confidentiality
            confidentiality: set[ConfidentialityLevel] = set()
            if any(s in param_lower for s in self.SENSITIVE_PARAMS):
                confidentiality.add(ConfidentialityLevel.SECRET)
            else:
                confidentiality.add(ConfidentialityLevel.PUBLIC)

            # Determine integrity
            integrity: set[IntegrityLevel] = set()
            if any(s in param_lower for s in self.USER_INPUT_PARAMS):
                integrity.add(IntegrityLevel.UNTRUSTED)
            else:
                integrity.add(IntegrityLevel.TRUSTED)

            labels[param] = TaintLabel(
                confidentiality=confidentiality,
                integrity=integrity,
                source_tool=tool.name,
                source_param=param,
            )

        return labels

    def _propagate_labels(
        self,
        tool: ToolDefinition,
        input_labels: dict[str, TaintLabel],
    ) -> dict[str, TaintLabel]:
        """Propagate taint labels through tool operations."""
        output_labels: dict[str, TaintLabel] = {}

        # Check tool description for sensitive operations
        description = (tool.description or "").lower()
        has_sensitive_op = any(op in description for op in self.SENSITIVE_OPERATIONS)

        # Merge all input labels for output (conservative)
        merged_label = TaintLabel()
        for label in input_labels.values():
            merged_label = merged_label.merge_with(label)

        # If tool performs sensitive operations, mark output accordingly
        if has_sensitive_op:
            merged_label.confidentiality.add(ConfidentialityLevel.INTERNAL)

        output_labels["result"] = merged_label.propagate()

        return output_labels

    def _check_violations(
        self,
        tool: ToolDefinition,
        input_labels: dict[str, TaintLabel],
        output_labels: dict[str, TaintLabel],
    ) -> list[FlowViolation]:
        """Check for information flow violations within a tool."""
        violations: list[FlowViolation] = []

        description = (tool.description or "").lower()

        for param, label in input_labels.items():
            # Check: Untrusted input to sensitive operation
            if label.is_tainted():
                if any(op in description for op in self.SENSITIVE_OPERATIONS):
                    violations.append(
                        FlowViolation(
                            tool=tool.name,
                            input_param=param,
                            violation_type=FlowViolationType.UNTRUSTED_TO_EXEC,
                            severity=Severity.CRITICAL,
                            source_label={"integrity": [l.value for l in label.integrity]},
                            description=(
                                f"Untrusted input '{param}' flows to sensitive operation in '{tool.name}'. "
                                f"This could allow injection attacks."
                            ),
                        )
                    )

            # Check: Secret data to public output
            if label.is_sensitive():
                for out_param, out_label in output_labels.items():
                    if ConfidentialityLevel.PUBLIC in out_label.confidentiality:
                        violations.append(
                            FlowViolation(
                                tool=tool.name,
                                input_param=param,
                                output_param=out_param,
                                violation_type=FlowViolationType.SECRET_TO_PUBLIC,
                                severity=Severity.HIGH,
                                source_label={"confidentiality": [l.value for l in label.confidentiality]},
                                description=(
                                    f"Sensitive data from '{param}' may flow to public output in '{tool.name}'. "
                                    f"This could leak confidential information."
                                ),
                            )
                        )

        return violations

    def _check_cross_tool_flow(
        self,
        source_tool: ToolDefinition,
        source_outputs: dict[str, TaintLabel],
        target_tool: ToolDefinition,
    ) -> list[FlowViolation]:
        """Check for violations in cross-tool data flow."""
        violations: list[FlowViolation] = []

        target_description = (target_tool.description or "").lower()
        has_sensitive_op = any(op in target_description for op in self.SENSITIVE_OPERATIONS)

        for out_param, label in source_outputs.items():
            # Check: Tainted data flowing to sensitive tool
            if label.is_tainted() and has_sensitive_op:
                violations.append(
                    FlowViolation(
                        tool=target_tool.name,
                        input_param="(from previous tool)",
                        violation_type=FlowViolationType.CROSS_TOOL_TAINT,
                        severity=Severity.HIGH,
                        source_label={"integrity": [l.value for l in label.integrity]},
                        description=(
                            f"Tainted data from '{source_tool.name}' flows to sensitive tool '{target_tool.name}'. "
                            f"Validate data at tool boundaries."
                        ),
                        cross_tool=True,
                        source_tool=source_tool.name,
                    )
                )

            # Check: Untrusted data reaching secret operations
            if label.is_tainted() and label.is_sensitive():
                violations.append(
                    FlowViolation(
                        tool=target_tool.name,
                        input_param="(from previous tool)",
                        violation_type=FlowViolationType.UNTRUSTED_TO_SECRET,
                        severity=Severity.CRITICAL,
                        source_label={
                            "integrity": [l.value for l in label.integrity],
                            "confidentiality": [l.value for l in label.confidentiality],
                        },
                        description=(
                            f"Untrusted data mixed with sensitive data flows from '{source_tool.name}' "
                            f"to '{target_tool.name}'. This is a critical security violation."
                        ),
                        cross_tool=True,
                        source_tool=source_tool.name,
                    )
                )

        return violations

    def _get_remediation(self, violation: FlowViolation) -> str:
        """Get remediation advice for a violation."""
        remediations = {
            FlowViolationType.UNTRUSTED_TO_EXEC: (
                "Validate and sanitize all user input before passing to execution functions. "
                "Use allowlists for permitted values where possible."
            ),
            FlowViolationType.UNTRUSTED_TO_SECRET: (
                "Never mix untrusted input with sensitive data. "
                "Implement strict input validation and use separate data paths."
            ),
            FlowViolationType.SECRET_TO_PUBLIC: (
                "Ensure sensitive data is not exposed in outputs. "
                "Implement data masking or filtering before returning results."
            ),
            FlowViolationType.CROSS_TOOL_TAINT: (
                "Add validation at tool boundaries. Consider implementing a sanitization layer between tools."
            ),
            FlowViolationType.IMPLICIT_FLOW: (
                "Review control flow to ensure sensitive decisions don't leak information. "
                "Consider constant-time operations for security-critical code."
            ),
        }
        return remediations.get(violation.violation_type, "Review and fix the information flow issue.")

    def _get_cwe(self, violation: FlowViolation) -> str:
        """Get CWE ID for a violation type."""
        cwe_mapping = {
            FlowViolationType.UNTRUSTED_TO_EXEC: "CWE-78",  # OS Command Injection
            FlowViolationType.UNTRUSTED_TO_SECRET: "CWE-20",  # Improper Input Validation
            FlowViolationType.SECRET_TO_PUBLIC: "CWE-200",  # Information Exposure
            FlowViolationType.CROSS_TOOL_TAINT: "CWE-74",  # Injection
            FlowViolationType.IMPLICIT_FLOW: "CWE-203",  # Observable Discrepancy
        }
        return cwe_mapping.get(violation.violation_type, "CWE-20")
