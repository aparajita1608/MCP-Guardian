"""Semantic Fingerprint Drift Detection for MCP Tools.

Detects when MCP tool descriptions change semantically while maintaining
the same name (rug-pull detection). Uses locality-sensitive hashing and
semantic embeddings to detect intent changes.

Patent Claim: A method for detecting malicious tool definition mutations by:
1. Computing semantic fingerprints using locality-sensitive hashing
2. Storing fingerprints in a lockfile at approval time
3. Detecting semantic drift even when literal text differs
4. Alerting on intent changes vs. benign updates
"""

import hashlib
import json
import re
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from ..core.logging import get_logger
from ..core.models import ToolDefinition

logger = get_logger(__name__)


class DriftStatus(str, Enum):
    """Status of drift analysis."""

    UNCHANGED = "unchanged"
    MINOR_UPDATE = "minor_update"
    DRIFT_DETECTED = "drift_detected"
    INTENT_CHANGED = "intent_changed"
    NEW_TOOL = "new_tool"
    REMOVED = "removed"
    TOOL_SHADOWING = "tool_shadowing"  # Rogue server with identical tool name


class DriftRisk(str, Enum):
    """Risk level of detected drift."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    REVIEW_REQUIRED = "review_required"


class IntentCategory(str, Enum):
    """Categories of tool intent."""

    FILE_ACCESS = "file_access"
    NETWORK = "network"
    DATABASE = "database"
    SYSTEM = "system"
    CODE_EXECUTION = "code_execution"
    DATA_PROCESSING = "data_processing"
    COMMUNICATION = "communication"
    AUTHENTICATION = "authentication"
    UNKNOWN = "unknown"


class SemanticFingerprint(BaseModel):
    """Semantic fingerprint of a tool definition.

    Captures the semantic essence of a tool for comparison,
    allowing detection of meaningful changes vs. cosmetic updates.
    """

    tool_name: str = Field(description="Name of the tool")
    server_name: str = Field(default="", description="Name of the MCP server providing this tool")
    version: str = Field(default="1.0.0", description="Fingerprint version")

    # Hash components
    lsh_hash: str = Field(description="Locality-sensitive hash for quick comparison")
    content_hash: str = Field(description="SHA-256 of normalized content")

    # Semantic components
    intent_category: IntentCategory = Field(description="Primary intent category")
    capability_vector: set[str] = Field(default_factory=set, description="Set of detected capabilities")

    # Metadata
    word_count: int = Field(default=0)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Raw data for detailed comparison
    normalized_description: str = Field(default="")
    schema_signature: str = Field(default="")
    
    # Hidden parameter detection (Postmark-MCP style attacks)
    parameter_names: set[str] = Field(default_factory=set, description="Set of input parameter names")
    has_default_values: bool = Field(default=False, description="Whether any params have default values")
    external_urls_in_defaults: list[str] = Field(default_factory=list, description="External URLs in default values")

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True


class DriftAnalysis(BaseModel):
    """Result of drift analysis between two tool versions."""

    tool_name: str
    status: DriftStatus
    risk: DriftRisk

    # Comparison metrics
    similarity_score: float = Field(default=1.0, ge=0.0, le=1.0)
    intent_changed: bool = Field(default=False)
    new_capabilities: list[str] = Field(default_factory=list)
    removed_capabilities: list[str] = Field(default_factory=list)
    
    # Hidden parameter detection (Postmark-MCP style)
    new_parameters: list[str] = Field(default_factory=list)
    hidden_parameters_with_defaults: list[str] = Field(default_factory=list)
    suspicious_external_urls: list[str] = Field(default_factory=list)
    
    # Tool shadowing detection
    shadowing_server: str | None = Field(default=None, description="Server attempting to shadow this tool")
    original_server: str | None = Field(default=None, description="Original trusted server for this tool")

    # Details
    current_intent: IntentCategory | None = Field(default=None)
    previous_intent: IntentCategory | None = Field(default=None)
    explanation: str = Field(default="")

    # Timestamps
    analyzed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class SemanticLockfile(BaseModel):
    """Lockfile storing approved tool fingerprints.

    Similar to package-lock.json, this stores the semantic fingerprints
    of tools at the time they were approved, enabling drift detection.
    """

    version: str = Field(default="1.0.0")
    fingerprints: dict[str, SemanticFingerprint] = Field(default_factory=dict)
    # Track tool name to server mapping for shadowing detection
    tool_server_registry: dict[str, str] = Field(default_factory=dict, description="Maps tool names to their trusted server")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_updated: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def get(self, tool_name: str) -> SemanticFingerprint | None:
        """Get fingerprint for a tool."""
        return self.fingerprints.get(tool_name)
    
    def get_trusted_server(self, tool_name: str) -> str | None:
        """Get the trusted server for a tool name."""
        return self.tool_server_registry.get(tool_name)

    def set(self, fingerprint: SemanticFingerprint) -> None:
        """Store fingerprint for a tool."""
        self.fingerprints[fingerprint.tool_name] = fingerprint
        # Register the server as trusted for this tool name
        if fingerprint.server_name:
            self.tool_server_registry[fingerprint.tool_name] = fingerprint.server_name
        self.last_updated = datetime.now(timezone.utc)

    def remove(self, tool_name: str) -> bool:
        """Remove fingerprint for a tool."""
        if tool_name in self.fingerprints:
            del self.fingerprints[tool_name]
            if tool_name in self.tool_server_registry:
                del self.tool_server_registry[tool_name]
            self.last_updated = datetime.now(timezone.utc)
            return True
        return False
    
    def check_shadowing(self, tool_name: str, server_name: str) -> tuple[bool, str | None]:
        """Check if a tool name is being shadowed by a different server.
        
        Returns:
            Tuple of (is_shadowing, original_server_name)
        """
        trusted_server = self.tool_server_registry.get(tool_name)
        if trusted_server and server_name and trusted_server != server_name:
            return True, trusted_server
        return False, None

    def save(self, path: Path) -> None:
        """Save lockfile to disk."""
        # Convert sets to lists for JSON serialization
        data = self.model_dump()
        for fp in data["fingerprints"].values():
            fp["capability_vector"] = list(fp["capability_vector"])

        path.write_text(json.dumps(data, indent=2, default=str))
        logger.info("lockfile_saved", path=str(path))

    @classmethod
    def load(cls, path: Path) -> "SemanticLockfile":
        """Load lockfile from disk."""
        if not path.exists():
            return cls()

        try:
            data = json.loads(path.read_text())
            # Convert lists back to sets
            for fp in data.get("fingerprints", {}).values():
                fp["capability_vector"] = set(fp.get("capability_vector", []))
            return cls.model_validate(data)
        except Exception as e:
            logger.warning("lockfile_load_failed", error=str(e))
            return cls()


class SemanticDriftDetector:
    """Detector for semantic drift in MCP tool definitions.

    Uses a combination of techniques to detect when tools change
    in meaningful ways that could indicate malicious updates.
    """

    DEFAULT_LOCKFILE_PATH = Path.home() / ".mcp-guardian" / "semantic_lockfile.json"

    # Keywords for intent classification
    INTENT_KEYWORDS: dict[IntentCategory, list[str]] = {
        IntentCategory.FILE_ACCESS: [
            "file",
            "read",
            "write",
            "path",
            "directory",
            "folder",
            "save",
            "load",
            "open",
            "create",
            "delete",
            "copy",
            "move",
            "rename",
        ],
        IntentCategory.NETWORK: [
            "http",
            "https",
            "url",
            "request",
            "fetch",
            "api",
            "endpoint",
            "server",
            "download",
            "upload",
            "socket",
            "connection",
            "remote",
        ],
        IntentCategory.DATABASE: [
            "database",
            "sql",
            "query",
            "table",
            "record",
            "insert",
            "update",
            "delete",
            "select",
            "mongodb",
            "postgres",
            "mysql",
            "sqlite",
        ],
        IntentCategory.SYSTEM: [
            "system",
            "process",
            "command",
            "shell",
            "terminal",
            "execute",
            "run",
            "subprocess",
            "os",
            "environment",
            "variable",
        ],
        IntentCategory.CODE_EXECUTION: [
            "eval",
            "exec",
            "compile",
            "interpret",
            "script",
            "code",
            "python",
            "javascript",
            "execute",
        ],
        IntentCategory.DATA_PROCESSING: [
            "parse",
            "transform",
            "convert",
            "format",
            "encode",
            "decode",
            "compress",
            "extract",
            "analyze",
            "process",
        ],
        IntentCategory.COMMUNICATION: [
            "email",
            "message",
            "notification",
            "alert",
            "send",
            "receive",
            "chat",
            "slack",
            "discord",
            "webhook",
        ],
        IntentCategory.AUTHENTICATION: [
            "auth",
            "login",
            "password",
            "token",
            "credential",
            "secret",
            "key",
            "certificate",
            "oauth",
            "jwt",
        ],
    }

    # Capability keywords
    CAPABILITY_KEYWORDS: dict[str, list[str]] = {
        "file_read": ["read", "load", "get", "fetch", "open"],
        "file_write": ["write", "save", "create", "store", "put"],
        "file_delete": ["delete", "remove", "unlink", "rm"],
        "network_request": ["http", "request", "fetch", "api", "url"],
        "command_exec": ["exec", "run", "command", "shell", "subprocess"],
        "database_query": ["query", "sql", "select", "database"],
        "database_modify": ["insert", "update", "delete", "modify"],
        "credential_access": ["password", "token", "secret", "key", "credential"],
        "data_exfiltration": ["send", "upload", "post", "transmit"],
        "user_input": ["input", "parameter", "argument", "user"],
    }

    def __init__(self, lockfile_path: Path | None = None):
        """Initialize the drift detector.

        Args:
            lockfile_path: Path to semantic lockfile
        """
        self.lockfile_path = lockfile_path or self.DEFAULT_LOCKFILE_PATH
        self.lockfile_path.parent.mkdir(parents=True, exist_ok=True)
        self.lockfile = SemanticLockfile.load(self.lockfile_path)

        logger.info(
            "drift_detector_initialized",
            fingerprint_count=len(self.lockfile.fingerprints),
        )

    def fingerprint(self, tool: ToolDefinition, server_name: str = "") -> SemanticFingerprint:
        """Generate semantic fingerprint from tool metadata.

        Args:
            tool: Tool definition to fingerprint
            server_name: Name of the MCP server providing this tool

        Returns:
            Semantic fingerprint of the tool
        """
        # Normalize description
        description = tool.description or ""
        normalized = self._normalize_text(description)

        # Generate schema signature
        schema_sig = self._schema_signature(tool.input_schema)

        # Combine for content hash
        content = f"{tool.name}:{normalized}:{schema_sig}"
        content_hash = hashlib.sha256(content.encode()).hexdigest()

        # Generate LSH hash for quick comparison
        lsh_hash = self._locality_sensitive_hash(normalized)

        # Classify intent
        intent = self._classify_intent(description)

        # Extract capabilities
        capabilities = self._extract_capabilities(tool)
        
        # Extract parameter information for hidden parameter detection (Postmark-MCP style)
        parameter_names, has_defaults, external_urls = self._extract_parameter_info(tool)

        return SemanticFingerprint(
            tool_name=tool.name,
            server_name=server_name,
            lsh_hash=lsh_hash,
            content_hash=content_hash,
            intent_category=intent,
            capability_vector=capabilities,
            word_count=len(normalized.split()),
            normalized_description=normalized[:500],  # Truncate for storage
            schema_signature=schema_sig,
            parameter_names=parameter_names,
            has_default_values=has_defaults,
            external_urls_in_defaults=external_urls,
        )

    def detect_drift(self, current: ToolDefinition, server_name: str = "") -> DriftAnalysis:
        """Compare current tool against locked version.

        Args:
            current: Current tool definition
            server_name: Name of the MCP server providing this tool

        Returns:
            Analysis of any detected drift
        """
        current_fp = self.fingerprint(current, server_name)
        locked_fp = self.lockfile.get(current.name)
        
        # Check for tool shadowing first
        is_shadowing, original_server = self.lockfile.check_shadowing(current.name, server_name)
        if is_shadowing:
            return DriftAnalysis(
                tool_name=current.name,
                status=DriftStatus.TOOL_SHADOWING,
                risk=DriftRisk.CRITICAL,
                current_intent=current_fp.intent_category,
                shadowing_server=server_name,
                original_server=original_server,
                explanation=f"⚠️ TOOL SHADOWING DETECTED: Tool '{current.name}' is registered by server "
                f"'{server_name}' but was originally approved from server '{original_server}'. "
                f"This could be an attempt to hijack user intents.",
            )

        if not locked_fp:
            return DriftAnalysis(
                tool_name=current.name,
                status=DriftStatus.NEW_TOOL,
                risk=DriftRisk.REVIEW_REQUIRED,
                current_intent=current_fp.intent_category,
                explanation=f"New tool '{current.name}' requires review before approval",
            )

        # Compute similarity
        similarity = self._compute_similarity(current_fp, locked_fp)

        # Detect intent change
        intent_changed = current_fp.intent_category != locked_fp.intent_category

        # Detect capability changes
        new_caps = list(current_fp.capability_vector - locked_fp.capability_vector)
        removed_caps = list(locked_fp.capability_vector - current_fp.capability_vector)
        
        # Detect new parameters (Postmark-MCP style hidden parameter attack)
        new_params = list(current_fp.parameter_names - locked_fp.parameter_names)
        
        # Check for suspicious hidden parameters with external URLs
        hidden_params_with_defaults: list[str] = []
        suspicious_urls: list[str] = []
        
        if new_params and current_fp.has_default_values:
            # New parameters with default values are suspicious
            hidden_params_with_defaults = new_params
            suspicious_urls = current_fp.external_urls_in_defaults

        # Determine status and risk
        status, risk = self._assess_drift(
            similarity, intent_changed, new_caps, removed_caps, 
            new_params, hidden_params_with_defaults, suspicious_urls
        )

        # Generate explanation
        explanation = self._generate_explanation(
            current_fp, locked_fp, similarity, intent_changed, new_caps, removed_caps,
            new_params, hidden_params_with_defaults, suspicious_urls
        )

        return DriftAnalysis(
            tool_name=current.name,
            status=status,
            risk=risk,
            similarity_score=similarity,
            intent_changed=intent_changed,
            new_capabilities=new_caps,
            removed_capabilities=removed_caps,
            new_parameters=new_params,
            hidden_parameters_with_defaults=hidden_params_with_defaults,
            suspicious_external_urls=suspicious_urls,
            current_intent=current_fp.intent_category,
            previous_intent=locked_fp.intent_category,
            explanation=explanation,
        )

    def approve_tool(self, tool: ToolDefinition) -> SemanticFingerprint:
        """Approve a tool and store its fingerprint.

        Args:
            tool: Tool to approve

        Returns:
            Generated fingerprint
        """
        fingerprint = self.fingerprint(tool)
        self.lockfile.set(fingerprint)
        self.lockfile.save(self.lockfile_path)

        logger.info(
            "tool_approved",
            tool_name=tool.name,
            intent=fingerprint.intent_category.value,
        )

        return fingerprint

    def analyze_all(self, tools: list[ToolDefinition]) -> list[DriftAnalysis]:
        """Analyze all tools for drift.

        Args:
            tools: List of current tool definitions

        Returns:
            List of drift analyses
        """
        analyses = []
        current_names = {t.name for t in tools}

        # Check each current tool
        for tool in tools:
            analysis = self.detect_drift(tool)
            analyses.append(analysis)

        # Check for removed tools
        for name in self.lockfile.fingerprints:
            if name not in current_names:
                analyses.append(
                    DriftAnalysis(
                        tool_name=name,
                        status=DriftStatus.REMOVED,
                        risk=DriftRisk.MEDIUM,
                        explanation=f"Tool '{name}' was previously approved but is no longer present",
                    )
                )

        return analyses

    def _normalize_text(self, text: str) -> str:
        """Normalize text for comparison."""
        # Lowercase
        text = text.lower()
        # Remove extra whitespace
        text = re.sub(r"\s+", " ", text)
        # Remove punctuation except for meaningful chars
        text = re.sub(r"[^\w\s\-_/]", "", text)
        return text.strip()

    def _schema_signature(self, schema: dict[str, Any] | None) -> str:
        """Generate signature from input schema."""
        if not schema:
            return "empty"

        # Extract property names and types
        props = schema.get("properties", {})
        sig_parts = []

        for name, prop in sorted(props.items()):
            prop_type = prop.get("type", "any")
            sig_parts.append(f"{name}:{prop_type}")

        return "|".join(sig_parts) if sig_parts else "empty"
    
    def _extract_parameter_info(self, tool: ToolDefinition) -> tuple[set[str], bool, list[str]]:
        """Extract parameter information for hidden parameter detection.
        
        This detects Postmark-MCP style attacks where malicious parameters
        are added with default values pointing to attacker-controlled URLs.
        
        Args:
            tool: Tool definition to analyze
            
        Returns:
            Tuple of (parameter_names, has_defaults, external_urls_in_defaults)
        """
        parameter_names: set[str] = set()
        has_defaults = False
        external_urls: list[str] = []
        
        if not tool.input_schema:
            return parameter_names, has_defaults, external_urls
        
        props = tool.input_schema.get("properties", {})
        
        # URL pattern for detecting external URLs in defaults
        url_pattern = re.compile(r'https?://[^\s"\']+')
        
        for name, prop in props.items():
            parameter_names.add(name)
            
            # Check for default values
            if "default" in prop:
                has_defaults = True
                default_val = str(prop["default"])
                
                # Check if default contains external URL
                urls = url_pattern.findall(default_val)
                for url in urls:
                    # Exclude common safe domains
                    if not any(safe in url.lower() for safe in ["localhost", "127.0.0.1", "example.com"]):
                        external_urls.append(url)
        
        return parameter_names, has_defaults, external_urls

    def _locality_sensitive_hash(self, text: str) -> str:
        """Generate LSH for quick similarity comparison.

        Uses a simple shingle-based approach for text similarity.
        """
        # Generate 3-grams (shingles)
        words = text.split()
        if len(words) < 3:
            shingles = {text}
        else:
            shingles = {" ".join(words[i : i + 3]) for i in range(len(words) - 2)}

        # Hash each shingle and combine
        hashes = [int(hashlib.md5(s.encode()).hexdigest()[:8], 16) for s in shingles]

        if not hashes:
            return "0" * 16

        # MinHash signature (simplified)
        min_hash = min(hashes)
        return f"{min_hash:016x}"

    def _classify_intent(self, description: str) -> IntentCategory:
        """Classify the primary intent of a tool."""
        description_lower = description.lower()

        scores: dict[IntentCategory, int] = {}

        for intent, keywords in self.INTENT_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in description_lower)
            if score > 0:
                scores[intent] = score

        if not scores:
            return IntentCategory.UNKNOWN

        return max(scores, key=lambda k: scores[k])

    def _extract_capabilities(self, tool: ToolDefinition) -> set[str]:
        """Extract capability indicators from tool."""
        capabilities: set[str] = set()

        # Check description
        description = (tool.description or "").lower()

        for cap, keywords in self.CAPABILITY_KEYWORDS.items():
            if any(kw in description for kw in keywords):
                capabilities.add(cap)

        # Check schema for input types that suggest capabilities
        if tool.input_schema:
            props = tool.input_schema.get("properties", {})
            for name in props:
                name_lower = name.lower()
                if "path" in name_lower or "file" in name_lower:
                    capabilities.add("file_read")
                if "url" in name_lower:
                    capabilities.add("network_request")
                if "command" in name_lower or "cmd" in name_lower:
                    capabilities.add("command_exec")
                if "query" in name_lower or "sql" in name_lower:
                    capabilities.add("database_query")

        return capabilities

    def _compute_similarity(
        self,
        current: SemanticFingerprint,
        locked: SemanticFingerprint,
    ) -> float:
        """Compute similarity between two fingerprints."""
        # Content hash match = identical
        if current.content_hash == locked.content_hash:
            return 1.0

        # LSH match = very similar
        if current.lsh_hash == locked.lsh_hash:
            return 0.95

        # Capability overlap
        if current.capability_vector and locked.capability_vector:
            intersection = len(current.capability_vector & locked.capability_vector)
            union = len(current.capability_vector | locked.capability_vector)
            jaccard = intersection / union if union > 0 else 0
        else:
            jaccard = 0.5  # Unknown

        # Word count similarity
        if locked.word_count > 0:
            word_ratio = min(current.word_count, locked.word_count) / max(current.word_count, locked.word_count)
        else:
            word_ratio = 0.5

        # Weighted combination
        return 0.6 * jaccard + 0.4 * word_ratio

    def _assess_drift(
        self,
        similarity: float,
        intent_changed: bool,
        new_caps: list[str],
        removed_caps: list[str],
        new_params: list[str] | None = None,
        hidden_params: list[str] | None = None,
        suspicious_urls: list[str] | None = None,
    ) -> tuple[DriftStatus, DriftRisk]:
        """Assess drift status and risk level."""
        new_params = new_params or []
        hidden_params = hidden_params or []
        suspicious_urls = suspicious_urls or []
        
        # Critical: Hidden parameters with external URLs (Postmark-MCP style attack)
        if hidden_params and suspicious_urls:
            return DriftStatus.DRIFT_DETECTED, DriftRisk.CRITICAL
        
        # Critical: Intent changed
        if intent_changed:
            return DriftStatus.INTENT_CHANGED, DriftRisk.CRITICAL

        # High risk: Dangerous new capabilities
        dangerous_caps = {"command_exec", "credential_access", "data_exfiltration"}
        if any(cap in dangerous_caps for cap in new_caps):
            return DriftStatus.DRIFT_DETECTED, DriftRisk.HIGH
        
        # High risk: New parameters added (potential hidden functionality)
        if new_params and len(new_params) > 0:
            # More suspicious if description didn't change much but params did
            if similarity > 0.9:
                return DriftStatus.DRIFT_DETECTED, DriftRisk.HIGH

        # Medium risk: Significant drift
        if similarity < 0.7:
            return DriftStatus.DRIFT_DETECTED, DriftRisk.MEDIUM

        # Low risk: Minor changes
        if similarity < 0.95:
            return DriftStatus.MINOR_UPDATE, DriftRisk.LOW

        # No change
        return DriftStatus.UNCHANGED, DriftRisk.LOW

    def _generate_explanation(
        self,
        current: SemanticFingerprint,
        locked: SemanticFingerprint,
        similarity: float,
        intent_changed: bool,
        new_caps: list[str],
        removed_caps: list[str],
        new_params: list[str] | None = None,
        hidden_params: list[str] | None = None,
        suspicious_urls: list[str] | None = None,
    ) -> str:
        """Generate human-readable explanation of drift."""
        parts = []
        new_params = new_params or []
        hidden_params = hidden_params or []
        suspicious_urls = suspicious_urls or []
        
        # Postmark-MCP style attack detection
        if hidden_params and suspicious_urls:
            parts.append(f"🚨 SUPPLY CHAIN ATTACK PATTERN: New parameters {hidden_params} with external URLs: {suspicious_urls}")

        if intent_changed:
            parts.append(f"⚠️ Intent changed from '{locked.intent_category.value}' to '{current.intent_category.value}'")

        if new_caps:
            parts.append(f"🆕 New capabilities: {', '.join(new_caps)}")

        if removed_caps:
            parts.append(f"➖ Removed capabilities: {', '.join(removed_caps)}")
        
        if new_params:
            parts.append(f"📝 New parameters added: {', '.join(new_params)}")

        parts.append(f"📊 Similarity score: {similarity:.0%}")

        return " | ".join(parts) if parts else "No significant changes detected"
