"""Cross-Tool Attack Chain Graph Analysis for MCP.

Builds a directed graph of tool capabilities and detects emergent attack
chains that arise from combining benign tools.

Patent Claim: A system for detecting emergent security vulnerabilities
arising from combinations of individually benign MCP tools by:
1. Constructing a capability graph from tool definitions
2. Applying graph traversal to find attack chains
3. Computing blast radius for each potential attack path
4. Ranking vulnerabilities by exploitability score
"""

from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from ..core.logging import get_logger
from ..core.models import Category, Finding, Location, Severity, ToolDefinition

logger = get_logger(__name__)


class Capability(str, Enum):
    """Tool capabilities that can form attack chains."""

    # Input capabilities (entry points)
    USER_INPUT = "user_input"
    FILE_INPUT = "file_input"
    NETWORK_INPUT = "network_input"

    # Processing capabilities
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_DELETE = "file_delete"
    NETWORK_REQUEST = "network_request"
    COMMAND_EXEC = "command_exec"
    CODE_EVAL = "code_eval"
    DATABASE_READ = "database_read"
    DATABASE_WRITE = "database_write"

    # Sensitive capabilities (targets)
    CREDENTIAL_ACCESS = "credential_access"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    PERSISTENCE = "persistence"
    CONFIG_MODIFICATION = "config_modification"
    RCE = "rce"  # Remote Code Execution
    SSRF = "ssrf"
    C2_COMMUNICATION = "c2_communication"


# Capability transition edges - what capabilities can lead to what attacks
CAPABILITY_EDGES: dict[Capability, list[Capability]] = {
    Capability.USER_INPUT: [
        Capability.FILE_READ,
        Capability.NETWORK_REQUEST,
        Capability.COMMAND_EXEC,
        Capability.DATABASE_READ,
    ],
    Capability.FILE_READ: [Capability.DATA_EXFILTRATION, Capability.CREDENTIAL_ACCESS, Capability.CODE_EVAL],
    Capability.FILE_WRITE: [Capability.PERSISTENCE, Capability.CONFIG_MODIFICATION, Capability.RCE],
    Capability.NETWORK_REQUEST: [Capability.DATA_EXFILTRATION, Capability.SSRF, Capability.C2_COMMUNICATION],
    Capability.COMMAND_EXEC: [Capability.RCE, Capability.PRIVILEGE_ESCALATION, Capability.PERSISTENCE],
    Capability.CODE_EVAL: [Capability.RCE, Capability.CREDENTIAL_ACCESS],
    Capability.DATABASE_READ: [Capability.DATA_EXFILTRATION, Capability.CREDENTIAL_ACCESS],
    Capability.DATABASE_WRITE: [Capability.PERSISTENCE, Capability.PRIVILEGE_ESCALATION],
    Capability.CREDENTIAL_ACCESS: [Capability.PRIVILEGE_ESCALATION, Capability.DATA_EXFILTRATION],
}

# Capability keywords for extraction
CAPABILITY_KEYWORDS: dict[Capability, list[str]] = {
    Capability.USER_INPUT: ["input", "parameter", "argument", "user", "request"],
    Capability.FILE_INPUT: ["upload", "import", "load file"],
    Capability.NETWORK_INPUT: ["webhook", "callback", "receive"],
    Capability.FILE_READ: ["read", "load", "open", "get file", "fetch file"],
    Capability.FILE_WRITE: ["write", "save", "create file", "store"],
    Capability.FILE_DELETE: ["delete", "remove", "unlink"],
    Capability.NETWORK_REQUEST: ["http", "request", "fetch", "api", "url", "download"],
    Capability.COMMAND_EXEC: ["exec", "run", "command", "shell", "subprocess", "terminal"],
    Capability.CODE_EVAL: ["eval", "execute code", "interpret", "compile"],
    Capability.DATABASE_READ: ["query", "select", "find", "search database"],
    Capability.DATABASE_WRITE: ["insert", "update", "modify database"],
    Capability.CREDENTIAL_ACCESS: ["password", "token", "secret", "key", "credential", "auth"],
}


@dataclass
class CapabilityNode:
    """Node in the capability graph representing a tool."""

    tool_name: str
    tool: ToolDefinition
    capabilities: set[Capability] = field(default_factory=set)

    @property
    def is_entry_point(self) -> bool:
        """Check if this tool can be an entry point."""
        entry_caps = {Capability.USER_INPUT, Capability.FILE_INPUT, Capability.NETWORK_INPUT}
        return bool(self.capabilities & entry_caps)

    @property
    def is_critical_target(self) -> bool:
        """Check if this tool has critical capabilities."""
        critical_caps = {
            Capability.CREDENTIAL_ACCESS,
            Capability.DATA_EXFILTRATION,
            Capability.RCE,
            Capability.PRIVILEGE_ESCALATION,
        }
        return bool(self.capabilities & critical_caps)


@dataclass
class CapabilityEdge:
    """Edge in the capability graph representing a potential attack transition."""

    source: str  # Tool name
    target: str  # Tool name
    attack_type: str
    source_capability: Capability
    target_capability: Capability
    risk_score: float = 0.5


class AttackChain(BaseModel):
    """Represents a potential attack chain through multiple tools."""

    path: list[str] = Field(description="Ordered list of tool names in the chain")
    entry_point: str = Field(description="First tool in the chain")
    target: str = Field(description="Final target tool")
    attack_types: list[str] = Field(default_factory=list)

    # Risk metrics
    blast_radius: int = Field(default=0, description="Number of affected tools/resources")
    exploitability: float = Field(default=0.0, ge=0.0, le=1.0)
    impact: float = Field(default=0.0, ge=0.0, le=1.0)

    # Details
    description: str = Field(default="")
    capabilities_exploited: list[str] = Field(default_factory=list)

    @property
    def risk_score(self) -> float:
        """Calculate overall risk score."""
        return (self.exploitability * 0.6 + self.impact * 0.4) * (1 + len(self.path) * 0.1)


class CapabilityGraph:
    """Directed graph of tool capabilities for attack chain analysis."""

    def __init__(self) -> None:
        """Initialize empty capability graph."""
        self.nodes: dict[str, CapabilityNode] = {}
        self.edges: list[CapabilityEdge] = []
        self._adjacency: dict[str, list[str]] = defaultdict(list)

    def add_tool(self, tool: ToolDefinition, capabilities: set[Capability]) -> None:
        """Add a tool node to the graph."""
        node = CapabilityNode(
            tool_name=tool.name,
            tool=tool,
            capabilities=capabilities,
        )
        self.nodes[tool.name] = node

    def add_edge(
        self,
        source: str,
        target: str,
        attack_type: str,
        source_cap: Capability,
        target_cap: Capability,
    ) -> None:
        """Add an edge between tools."""
        edge = CapabilityEdge(
            source=source,
            target=target,
            attack_type=attack_type,
            source_capability=source_cap,
            target_capability=target_cap,
        )
        self.edges.append(edge)
        self._adjacency[source].append(target)

    def get_entry_points(self) -> list[str]:
        """Get all tools that can be entry points."""
        return [name for name, node in self.nodes.items() if node.is_entry_point]

    def get_critical_targets(self) -> list[str]:
        """Get all tools with critical capabilities."""
        return [name for name, node in self.nodes.items() if node.is_critical_target]

    def get_neighbors(self, tool_name: str) -> list[str]:
        """Get adjacent tools."""
        return self._adjacency.get(tool_name, [])

    def get_descendants(self, tool_name: str) -> set[str]:
        """Get all tools reachable from this tool."""
        visited: set[str] = set()
        stack = [tool_name]

        while stack:
            current = stack.pop()
            if current in visited:
                continue
            visited.add(current)
            stack.extend(self.get_neighbors(current))

        visited.discard(tool_name)  # Don't include the starting node
        return visited


class AttackChainAnalyzer:
    """Analyzer for detecting attack chains across MCP tools.

    Builds a capability graph and uses graph traversal to find
    potential attack paths that emerge from tool combinations.
    """

    # Risk weights for different attack outcomes
    ATTACK_RISK_WEIGHTS: dict[str, float] = {
        "rce": 1.0,
        "credential_access": 0.9,
        "data_exfiltration": 0.85,
        "privilege_escalation": 0.8,
        "ssrf": 0.7,
        "persistence": 0.65,
        "config_modification": 0.6,
        "c2_communication": 0.75,
    }

    def __init__(self) -> None:
        """Initialize the attack chain analyzer."""
        self.graph: CapabilityGraph | None = None

    def build_capability_graph(self, tools: list[ToolDefinition]) -> CapabilityGraph:
        """Build directed graph of tool capabilities.

        Args:
            tools: List of MCP tool definitions

        Returns:
            Capability graph with nodes and edges
        """
        graph = CapabilityGraph()

        # Add nodes for each tool
        for tool in tools:
            capabilities = self._extract_capabilities(tool)
            graph.add_tool(tool, capabilities)

        # Add edges based on capability chains
        for tool in tools:
            source_caps = graph.nodes[tool.name].capabilities

            for source_cap in source_caps:
                # Get potential target capabilities
                target_caps = CAPABILITY_EDGES.get(source_cap, [])

                for target_cap in target_caps:
                    # Find tools that have the target capability
                    for other_tool in tools:
                        if other_tool.name == tool.name:
                            continue

                        other_caps = graph.nodes[other_tool.name].capabilities
                        if target_cap in other_caps:
                            attack_type = f"{source_cap.value}→{target_cap.value}"
                            graph.add_edge(
                                tool.name,
                                other_tool.name,
                                attack_type,
                                source_cap,
                                target_cap,
                            )

        self.graph = graph

        logger.info(
            "capability_graph_built",
            nodes=len(graph.nodes),
            edges=len(graph.edges),
        )

        return graph

    def find_attack_chains(
        self,
        graph: CapabilityGraph | None = None,
        max_depth: int = 5,
    ) -> list[AttackChain]:
        """Find all attack chains using BFS from entry points.

        Args:
            graph: Capability graph (uses self.graph if None)
            max_depth: Maximum chain length to consider

        Returns:
            List of attack chains sorted by risk
        """
        graph = graph or self.graph
        if not graph:
            raise ValueError("No capability graph available. Call build_capability_graph first.")

        chains: list[AttackChain] = []

        entry_points = graph.get_entry_points()
        critical_targets = graph.get_critical_targets()

        logger.info(
            "finding_attack_chains",
            entry_points=len(entry_points),
            critical_targets=len(critical_targets),
        )

        for entry in entry_points:
            for target in critical_targets:
                if entry == target:
                    continue

                # Find all paths from entry to target
                paths = self._find_all_paths(graph, entry, target, max_depth)

                for path in paths:
                    chain = self._create_attack_chain(graph, path)
                    chains.append(chain)

        # Sort by risk score (highest first)
        chains.sort(key=lambda c: c.risk_score, reverse=True)

        logger.info("attack_chains_found", count=len(chains))

        return chains

    def analyze(self, tools: list[ToolDefinition]) -> list[Finding]:
        """Analyze tools and return findings for attack chains.

        Args:
            tools: List of MCP tool definitions

        Returns:
            List of findings for detected attack chains
        """
        graph = self.build_capability_graph(tools)
        chains = self.find_attack_chains(graph)

        findings: list[Finding] = []

        for i, chain in enumerate(chains[:10]):  # Top 10 chains
            severity = self._chain_to_severity(chain)

            finding = Finding(
                rule_id=f"MCP-CHAIN-{i + 1:03d}",
                severity=severity,
                category=Category.TOOL_POISONING,
                title=f"Attack Chain: {chain.entry_point} → {chain.target}",
                message=(
                    f"Potential attack chain detected through {len(chain.path)} tools. "
                    f"Path: {' → '.join(chain.path)}. "
                    f"Attack types: {', '.join(chain.attack_types)}."
                ),
                location=Location(
                    file=f"tools/{chain.entry_point}",
                    snippet=chain.description,
                ),
                remediation=(
                    f"Review the capability chain between these tools. "
                    f"Consider adding input validation between {chain.entry_point} and "
                    f"subsequent tools, or restricting capabilities of {chain.target}."
                ),
                cwe_id="CWE-269",  # Improper Privilege Management
                metadata={
                    "chain_path": chain.path,
                    "blast_radius": chain.blast_radius,
                    "exploitability": chain.exploitability,
                    "impact": chain.impact,
                    "capabilities_exploited": chain.capabilities_exploited,
                },
            )
            findings.append(finding)

        return findings

    def compute_blast_radius(self, graph: CapabilityGraph, path: list[str]) -> int:
        """Compute how many other tools/resources could be affected.

        Args:
            graph: Capability graph
            path: Attack path

        Returns:
            Number of affected tools
        """
        affected: set[str] = set()

        for node in path:
            affected.update(graph.get_descendants(node))

        return len(affected)

    def _extract_capabilities(self, tool: ToolDefinition) -> set[Capability]:
        """Extract capabilities from a tool definition."""
        capabilities: set[Capability] = set()

        # Check description
        description = (tool.description or "").lower()
        name = tool.name.lower()
        combined = f"{name} {description}"

        for cap, keywords in CAPABILITY_KEYWORDS.items():
            if any(kw in combined for kw in keywords):
                capabilities.add(cap)

        # Check schema for input types
        if tool.input_schema:
            props = tool.input_schema.get("properties", {})
            for prop_name in props:
                prop_lower = prop_name.lower()

                if any(kw in prop_lower for kw in ["path", "file", "filename"]):
                    capabilities.add(Capability.FILE_READ)
                if any(kw in prop_lower for kw in ["url", "endpoint", "uri"]):
                    capabilities.add(Capability.NETWORK_REQUEST)
                if any(kw in prop_lower for kw in ["command", "cmd", "script"]):
                    capabilities.add(Capability.COMMAND_EXEC)
                if any(kw in prop_lower for kw in ["query", "sql"]):
                    capabilities.add(Capability.DATABASE_READ)
                if any(kw in prop_lower for kw in ["input", "data", "content"]):
                    capabilities.add(Capability.USER_INPUT)

        # Default: assume user input if tool has any parameters
        if tool.input_schema and tool.input_schema.get("properties"):
            capabilities.add(Capability.USER_INPUT)

        return capabilities

    def _find_all_paths(
        self,
        graph: CapabilityGraph,
        start: str,
        end: str,
        max_depth: int,
    ) -> list[list[str]]:
        """Find all paths between two nodes using DFS."""
        paths: list[list[str]] = []

        def dfs(current: str, target: str, path: list[str], visited: set[str]) -> None:
            if len(path) > max_depth:
                return

            if current == target:
                paths.append(path.copy())
                return

            for neighbor in graph.get_neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(neighbor)
                    dfs(neighbor, target, path, visited)
                    path.pop()
                    visited.remove(neighbor)

        dfs(start, end, [start], {start})
        return paths

    def _create_attack_chain(
        self,
        graph: CapabilityGraph,
        path: list[str],
    ) -> AttackChain:
        """Create an AttackChain from a path."""
        attack_types: list[str] = []
        capabilities_exploited: list[str] = []

        # Collect attack types along the path
        for i in range(len(path) - 1):
            source = path[i]
            target = path[i + 1]

            for edge in graph.edges:
                if edge.source == source and edge.target == target:
                    attack_types.append(edge.attack_type)
                    capabilities_exploited.append(edge.source_capability.value)
                    capabilities_exploited.append(edge.target_capability.value)

        # Compute metrics
        blast_radius = self.compute_blast_radius(graph, path)
        exploitability = self._score_exploitability(graph, path)
        impact = self._score_impact(graph, path)

        # Generate description
        description = self._generate_chain_description(graph, path, attack_types)

        return AttackChain(
            path=path,
            entry_point=path[0],
            target=path[-1],
            attack_types=attack_types,
            blast_radius=blast_radius,
            exploitability=exploitability,
            impact=impact,
            description=description,
            capabilities_exploited=list(set(capabilities_exploited)),
        )

    def _score_exploitability(self, graph: CapabilityGraph, path: list[str]) -> float:
        """Score how easy the attack chain is to exploit."""
        # Shorter paths are easier to exploit
        length_factor = 1.0 / len(path)

        # Entry point with user input is easier
        entry_node = graph.nodes.get(path[0])
        entry_factor = 0.8 if entry_node and Capability.USER_INPUT in entry_node.capabilities else 0.5

        return min(1.0, length_factor * 2 + entry_factor * 0.5)

    def _score_impact(self, graph: CapabilityGraph, path: list[str]) -> float:
        """Score the potential impact of the attack chain."""
        target_node = graph.nodes.get(path[-1])
        if not target_node:
            return 0.5

        # Check for high-impact capabilities
        high_impact_caps = {
            Capability.RCE,
            Capability.CREDENTIAL_ACCESS,
            Capability.DATA_EXFILTRATION,
            Capability.PRIVILEGE_ESCALATION,
        }

        impact_caps = target_node.capabilities & high_impact_caps

        if Capability.RCE in impact_caps:
            return 1.0
        elif Capability.CREDENTIAL_ACCESS in impact_caps:
            return 0.9
        elif Capability.DATA_EXFILTRATION in impact_caps:
            return 0.85
        elif Capability.PRIVILEGE_ESCALATION in impact_caps:
            return 0.8

        return 0.5

    def _chain_to_severity(self, chain: AttackChain) -> Severity:
        """Convert attack chain risk to severity."""
        risk = chain.risk_score

        if risk >= 0.8:
            return Severity.CRITICAL
        elif risk >= 0.6:
            return Severity.HIGH
        elif risk >= 0.4:
            return Severity.MEDIUM
        elif risk >= 0.2:
            return Severity.LOW
        else:
            return Severity.INFO

    def _generate_chain_description(
        self,
        graph: CapabilityGraph,
        path: list[str],
        attack_types: list[str],
    ) -> str:
        """Generate human-readable description of attack chain."""
        parts = [f"Attack chain starting from '{path[0]}'"]

        for i, tool in enumerate(path[1:], 1):
            if i - 1 < len(attack_types):
                parts.append(f"→ {tool} ({attack_types[i - 1]})")
            else:
                parts.append(f"→ {tool}")

        return " ".join(parts)
