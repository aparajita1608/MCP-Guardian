"""CVE Benchmark Ingestion from MITRE cvelistV5 Repository.

Ingests CVE data from the official MITRE CVE List repository
(https://github.com/CVEProject/cvelistV5) to build the Minimum Viable
Benchmark (MVB) for MCP Guardian validation.

This module:
1. Parses CVE JSON 5.1 schema files from the cvelistV5 repository
2. Filters for MCP-related vulnerabilities (Chainlit, Cursor, Anthropic, etc.)
3. Extracts exploit mechanics for capability graph mapping
4. Generates synthetic test cases for CI/CD validation
"""

import json
import re
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from ..core.logging import get_logger

logger = get_logger(__name__)


class CVESeverity(str, Enum):
    """CVSS severity levels."""
    CRITICAL = "critical"  # 9.0-10.0
    HIGH = "high"          # 7.0-8.9
    MEDIUM = "medium"      # 4.0-6.9
    LOW = "low"            # 0.1-3.9
    NONE = "none"          # 0.0


class AttackVector(str, Enum):
    """Attack vector categories for MCP exploits."""
    COMMAND_INJECTION = "command_injection"
    REMOTE_CODE_EXECUTION = "rce"
    SUPPLY_CHAIN = "supply_chain"
    TOOL_SHADOWING = "tool_shadowing"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    SSRF = "ssrf"
    PATH_TRAVERSAL = "path_traversal"


@dataclass
class CVERecord:
    """Parsed CVE record from cvelistV5."""
    
    cve_id: str
    title: str
    description: str
    severity: CVESeverity
    cvss_score: float | None = None
    cwe_ids: list[str] = field(default_factory=list)
    
    # Affected products
    affected_products: list[str] = field(default_factory=list)
    affected_versions: list[str] = field(default_factory=list)
    
    # MCP-specific fields
    is_mcp_related: bool = False
    mcp_component: str | None = None
    attack_vector: AttackVector | None = None
    
    # References
    references: list[str] = field(default_factory=list)
    github_advisories: list[str] = field(default_factory=list)
    
    # Dates
    published_date: datetime | None = None
    updated_date: datetime | None = None
    
    # Raw data
    raw_json: dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPBenchmarkCase:
    """Generated benchmark test case from CVE data."""
    
    cve_id: str
    name: str
    description: str
    severity: str
    cwe: str
    
    # Tool definition that would trigger the vulnerability
    vulnerable_tool: dict[str, Any] = field(default_factory=dict)
    
    # Attack scenario
    attack_payload: str = ""
    attack_flow: list[str] = field(default_factory=list)
    
    # Expected detection
    expected_detection: dict[str, bool] = field(default_factory=dict)
    detection_mechanism: str = ""
    
    # Taint analysis mapping
    taint_source: dict[str, Any] = field(default_factory=dict)
    taint_sink: dict[str, Any] = field(default_factory=dict)


class CVEBenchmarkIngester:
    """Ingests CVE data from MITRE cvelistV5 for MCP Guardian benchmarks.
    
    Data source: https://github.com/CVEProject/cvelistV5
    
    Usage:
        ingester = CVEBenchmarkIngester()
        
        # From cloned repository
        ingester.load_from_directory(Path("./cvelistV5/cves"))
        
        # From daily baseline archive
        ingester.load_from_archive(Path("./2026-09-10_all_CVEs_at_midnight.zip"))
        
        # Filter for MCP-related CVEs
        mcp_cves = ingester.filter_mcp_related()
        
        # Generate benchmark cases
        cases = ingester.generate_benchmark_cases(mcp_cves)
    """
    
    # MCP-related product keywords for filtering
    MCP_PRODUCT_KEYWORDS = [
        "mcp", "model context protocol",
        "chainlit", "cursor", "anthropic", "claude",
        "langchain", "llamaindex", "autogen",
        "openai", "gpt", "copilot",
        "ai agent", "llm", "language model",
        "mcp-remote", "mcp-server", "mcp-client",
    ]
    
    # CWE IDs relevant to MCP security
    MCP_RELEVANT_CWES = {
        "CWE-78": AttackVector.COMMAND_INJECTION,   # OS Command Injection
        "CWE-94": AttackVector.REMOTE_CODE_EXECUTION,  # Code Injection
        "CWE-502": AttackVector.REMOTE_CODE_EXECUTION,  # Deserialization
        "CWE-918": AttackVector.SSRF,               # SSRF
        "CWE-22": AttackVector.PATH_TRAVERSAL,      # Path Traversal
        "CWE-269": AttackVector.PRIVILEGE_ESCALATION,  # Improper Privilege
        "CWE-200": AttackVector.DATA_EXFILTRATION,  # Information Exposure
        "CWE-1104": AttackVector.SUPPLY_CHAIN,      # Use of Unmaintained Component
    }
    
    def __init__(self) -> None:
        """Initialize the CVE benchmark ingester."""
        self.cve_records: list[CVERecord] = []
        self.mcp_cves: list[CVERecord] = []
        
    def load_from_directory(self, cves_dir: Path) -> int:
        """Load CVE records from a cloned cvelistV5 repository.
        
        Args:
            cves_dir: Path to the cves/ directory in the repository
            
        Returns:
            Number of CVE records loaded
        """
        if not cves_dir.exists():
            logger.error("cve_directory_not_found", path=str(cves_dir))
            return 0
        
        count = 0
        # CVEs are organized by year: cves/2025/1xxx/CVE-2025-1234.json
        for year_dir in cves_dir.iterdir():
            if not year_dir.is_dir() or not year_dir.name.isdigit():
                continue
                
            for range_dir in year_dir.iterdir():
                if not range_dir.is_dir():
                    continue
                    
                for cve_file in range_dir.glob("CVE-*.json"):
                    try:
                        record = self._parse_cve_file(cve_file)
                        if record:
                            self.cve_records.append(record)
                            count += 1
                    except Exception as e:
                        logger.warning("cve_parse_failed", file=str(cve_file), error=str(e))
        
        logger.info("cve_records_loaded", count=count)
        return count
    
    def load_from_archive(self, archive_path: Path) -> int:
        """Load CVE records from a daily baseline archive.
        
        Args:
            archive_path: Path to the ZIP archive (e.g., 2026-09-10_all_CVEs_at_midnight.zip)
            
        Returns:
            Number of CVE records loaded
        """
        if not archive_path.exists():
            logger.error("cve_archive_not_found", path=str(archive_path))
            return 0
        
        count = 0
        with zipfile.ZipFile(archive_path, 'r') as zf:
            for name in zf.namelist():
                if name.endswith('.json') and 'CVE-' in name:
                    try:
                        with zf.open(name) as f:
                            data = json.load(f)
                            record = self._parse_cve_json(data)
                            if record:
                                self.cve_records.append(record)
                                count += 1
                    except Exception as e:
                        logger.warning("cve_parse_failed", file=name, error=str(e))
        
        logger.info("cve_records_loaded_from_archive", count=count, archive=str(archive_path))
        return count
    
    def _parse_cve_file(self, cve_file: Path) -> CVERecord | None:
        """Parse a single CVE JSON file."""
        try:
            with open(cve_file) as f:
                data = json.load(f)
            return self._parse_cve_json(data)
        except Exception as e:
            logger.warning("cve_file_parse_error", file=str(cve_file), error=str(e))
            return None
    
    def _parse_cve_json(self, data: dict[str, Any]) -> CVERecord | None:
        """Parse CVE JSON 5.1 schema data.
        
        Handles both CNA Container and CVE Program Container as per
        the cvelistV5 repository structure.
        """
        cve_id = data.get("cveMetadata", {}).get("cveId", "")
        if not cve_id:
            return None
        
        # Get CNA container (primary data)
        containers = data.get("containers", {})
        cna = containers.get("cna", {})
        
        # Get CVE Program Container (enriched data added after July 2024)
        adp_containers = containers.get("adp", [])
        cve_program_container = None
        for adp in adp_containers:
            if adp.get("providerMetadata", {}).get("shortName") == "CVE":
                cve_program_container = adp
                break
        
        # Extract description
        descriptions = cna.get("descriptions", [])
        description = ""
        for desc in descriptions:
            if desc.get("lang", "").startswith("en"):
                description = desc.get("value", "")
                break
        
        # Extract affected products
        affected = cna.get("affected", [])
        products = []
        versions = []
        for aff in affected:
            product = aff.get("product", "")
            vendor = aff.get("vendor", "")
            if product:
                products.append(f"{vendor}/{product}" if vendor else product)
            
            for ver in aff.get("versions", []):
                versions.append(ver.get("version", ""))
        
        # Extract CWE IDs
        problem_types = cna.get("problemTypes", [])
        cwe_ids = []
        for pt in problem_types:
            for desc in pt.get("descriptions", []):
                cwe_id = desc.get("cweId", "")
                if cwe_id:
                    cwe_ids.append(cwe_id)
        
        # Extract CVSS score and severity
        metrics = cna.get("metrics", [])
        cvss_score = None
        severity = CVESeverity.NONE
        
        for metric in metrics:
            # Try CVSS 3.1 first, then 3.0
            for cvss_key in ["cvssV3_1", "cvssV3_0", "cvssV3"]:
                if cvss_key in metric:
                    cvss_data = metric[cvss_key]
                    cvss_score = cvss_data.get("baseScore")
                    severity_str = cvss_data.get("baseSeverity", "").lower()
                    if severity_str in [s.value for s in CVESeverity]:
                        severity = CVESeverity(severity_str)
                    break
        
        # Extract references
        references = []
        github_advisories = []
        for ref in cna.get("references", []):
            url = ref.get("url", "")
            references.append(url)
            if "github.com" in url and "advisories" in url:
                github_advisories.append(url)
        
        # Also get references from CVE Program Container
        if cve_program_container:
            for ref in cve_program_container.get("references", []):
                url = ref.get("url", "")
                if url not in references:
                    references.append(url)
        
        # Extract dates
        cve_metadata = data.get("cveMetadata", {})
        published_date = None
        updated_date = None
        
        if date_str := cve_metadata.get("datePublished"):
            try:
                published_date = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            except ValueError:
                pass
        
        if date_str := cve_metadata.get("dateUpdated"):
            try:
                updated_date = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            except ValueError:
                pass
        
        return CVERecord(
            cve_id=cve_id,
            title=cve_id,  # Will be enriched later
            description=description,
            severity=severity,
            cvss_score=cvss_score,
            cwe_ids=cwe_ids,
            affected_products=products,
            affected_versions=versions,
            references=references,
            github_advisories=github_advisories,
            published_date=published_date,
            updated_date=updated_date,
            raw_json=data,
        )
    
    def filter_mcp_related(self) -> list[CVERecord]:
        """Filter CVE records for MCP-related vulnerabilities.
        
        Searches product names, descriptions, and package names for
        AI agent frameworks that have adopted MCP.
        
        Returns:
            List of MCP-related CVE records
        """
        mcp_cves = []
        
        for record in self.cve_records:
            is_mcp = False
            mcp_component = None
            
            # Check product names
            for product in record.affected_products:
                product_lower = product.lower()
                for keyword in self.MCP_PRODUCT_KEYWORDS:
                    if keyword in product_lower:
                        is_mcp = True
                        mcp_component = product
                        break
                if is_mcp:
                    break
            
            # Check description
            if not is_mcp:
                desc_lower = record.description.lower()
                for keyword in self.MCP_PRODUCT_KEYWORDS:
                    if keyword in desc_lower:
                        is_mcp = True
                        mcp_component = keyword
                        break
            
            if is_mcp:
                record.is_mcp_related = True
                record.mcp_component = mcp_component
                
                # Determine attack vector from CWE
                for cwe_id in record.cwe_ids:
                    if cwe_id in self.MCP_RELEVANT_CWES:
                        record.attack_vector = self.MCP_RELEVANT_CWES[cwe_id]
                        break
                
                mcp_cves.append(record)
        
        self.mcp_cves = mcp_cves
        logger.info("mcp_cves_filtered", count=len(mcp_cves), total=len(self.cve_records))
        return mcp_cves
    
    def filter_by_cwe(self, cwe_id: str) -> list[CVERecord]:
        """Filter CVE records by CWE ID.
        
        Useful for finding specific vulnerability types like CWE-78 (Command Injection).
        
        Args:
            cwe_id: CWE identifier (e.g., "CWE-78")
            
        Returns:
            List of matching CVE records
        """
        return [r for r in self.cve_records if cwe_id in r.cwe_ids]
    
    def filter_by_severity(self, min_severity: CVESeverity) -> list[CVERecord]:
        """Filter CVE records by minimum severity.
        
        Args:
            min_severity: Minimum severity level
            
        Returns:
            List of CVE records at or above the severity level
        """
        severity_order = [CVESeverity.NONE, CVESeverity.LOW, CVESeverity.MEDIUM, 
                         CVESeverity.HIGH, CVESeverity.CRITICAL]
        min_index = severity_order.index(min_severity)
        
        return [r for r in self.cve_records 
                if severity_order.index(r.severity) >= min_index]
    
    def generate_benchmark_cases(self, cve_records: list[CVERecord] | None = None) -> list[MCPBenchmarkCase]:
        """Generate benchmark test cases from CVE records.
        
        Extracts exploit mechanics and maps them to MCP Guardian's
        capability graph for validation.
        
        Args:
            cve_records: CVE records to process (defaults to mcp_cves)
            
        Returns:
            List of benchmark test cases
        """
        records = cve_records or self.mcp_cves
        cases = []
        
        for record in records:
            case = self._generate_case_from_cve(record)
            if case:
                cases.append(case)
        
        logger.info("benchmark_cases_generated", count=len(cases))
        return cases
    
    def _generate_case_from_cve(self, record: CVERecord) -> MCPBenchmarkCase | None:
        """Generate a benchmark case from a single CVE record."""
        if not record.cwe_ids:
            return None
        
        cwe = record.cwe_ids[0]
        attack_vector = record.attack_vector or AttackVector.COMMAND_INJECTION
        
        # Generate vulnerable tool definition based on attack vector
        vulnerable_tool = self._generate_vulnerable_tool(record, attack_vector)
        
        # Generate attack flow
        attack_flow = self._generate_attack_flow(attack_vector)
        
        # Determine detection mechanism
        detection_mechanism = self._get_detection_mechanism(attack_vector)
        
        # Generate taint analysis mapping
        taint_source, taint_sink = self._generate_taint_mapping(attack_vector)
        
        return MCPBenchmarkCase(
            cve_id=record.cve_id,
            name=f"{record.cve_id.lower().replace('-', '_')}_{attack_vector.value}",
            description=record.description[:500],
            severity=record.severity.value,
            cwe=cwe,
            vulnerable_tool=vulnerable_tool,
            attack_payload=self._generate_attack_payload(attack_vector),
            attack_flow=attack_flow,
            expected_detection={
                "mcp_guardian": True,
                "mcp_scanner": attack_vector == AttackVector.COMMAND_INJECTION,
                "mcts": attack_vector in [AttackVector.COMMAND_INJECTION, AttackVector.SSRF],
                "mcpsec": False,
            },
            detection_mechanism=detection_mechanism,
            taint_source=taint_source,
            taint_sink=taint_sink,
        )
    
    def _generate_vulnerable_tool(self, record: CVERecord, attack_vector: AttackVector) -> dict[str, Any]:
        """Generate a vulnerable tool definition for testing."""
        tool_templates = {
            AttackVector.COMMAND_INJECTION: {
                "name": "execute_command",
                "description": f"Execute system command (vulnerable: {record.cve_id})",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Command to execute"},
                        "args": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["command"],
                },
            },
            AttackVector.REMOTE_CODE_EXECUTION: {
                "name": "eval_code",
                "description": f"Evaluate code (vulnerable: {record.cve_id})",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "description": "Code to evaluate"},
                        "language": {"type": "string", "default": "python"},
                    },
                    "required": ["code"],
                },
            },
            AttackVector.SSRF: {
                "name": "fetch_url",
                "description": f"Fetch URL content (vulnerable: {record.cve_id})",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "URL to fetch"},
                    },
                    "required": ["url"],
                },
            },
            AttackVector.DATA_EXFILTRATION: {
                "name": "send_data",
                "description": f"Send data to endpoint (vulnerable: {record.cve_id})",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "endpoint": {"type": "string"},
                        "data": {"type": "string"},
                    },
                    "required": ["endpoint", "data"],
                },
            },
        }
        
        return tool_templates.get(attack_vector, tool_templates[AttackVector.COMMAND_INJECTION])
    
    def _generate_attack_flow(self, attack_vector: AttackVector) -> list[str]:
        """Generate attack flow steps."""
        flows = {
            AttackVector.COMMAND_INJECTION: [
                "user_input",
                "command_parameter",
                "shell_exec(unsanitized)",
            ],
            AttackVector.REMOTE_CODE_EXECUTION: [
                "malicious_input",
                "code_parameter",
                "eval/exec",
            ],
            AttackVector.SSRF: [
                "user_controlled_url",
                "internal_fetch",
                "internal_service_access",
            ],
            AttackVector.DATA_EXFILTRATION: [
                "sensitive_data_read",
                "external_endpoint",
                "data_transmission",
            ],
        }
        return flows.get(attack_vector, ["unknown_flow"])
    
    def _get_detection_mechanism(self, attack_vector: AttackVector) -> str:
        """Get the MCP Guardian detection mechanism for an attack vector."""
        mechanisms = {
            AttackVector.COMMAND_INJECTION: "Cross-Tool Taint Tracking (UNTRUSTED → EXEC)",
            AttackVector.REMOTE_CODE_EXECUTION: "Capability Chain Analysis + Taint Tracking",
            AttackVector.SSRF: "Capability Chain Analysis (network_request → internal)",
            AttackVector.DATA_EXFILTRATION: "Cross-Tool Taint Tracking (SECRET → PUBLIC)",
            AttackVector.SUPPLY_CHAIN: "Schema Mutation Detection",
            AttackVector.TOOL_SHADOWING: "Schema Fingerprinting (name collision)",
            AttackVector.PRIVILEGE_ESCALATION: "Capability Chain Analysis (blast radius)",
            AttackVector.PATH_TRAVERSAL: "Taint Tracking (UNTRUSTED → file_path)",
        }
        return mechanisms.get(attack_vector, "Static Rule Analysis")
    
    def _generate_taint_mapping(self, attack_vector: AttackVector) -> tuple[dict[str, Any], dict[str, Any]]:
        """Generate taint source and sink mapping."""
        mappings = {
            AttackVector.COMMAND_INJECTION: (
                {"parameter": "command", "label": ["PUBLIC", "UNTRUSTED"]},
                {"operation": "shell_exec", "label": ["INTERNAL", "TRUSTED"]},
            ),
            AttackVector.REMOTE_CODE_EXECUTION: (
                {"parameter": "code", "label": ["PUBLIC", "UNTRUSTED"]},
                {"operation": "eval", "label": ["INTERNAL", "TRUSTED"]},
            ),
            AttackVector.DATA_EXFILTRATION: (
                {"parameter": "data", "label": ["SECRET", "TRUSTED"]},
                {"operation": "network_send", "label": ["PUBLIC", "UNTRUSTED"]},
            ),
        }
        return mappings.get(attack_vector, ({}, {}))
    
    def _generate_attack_payload(self, attack_vector: AttackVector) -> str:
        """Generate example attack payload."""
        payloads = {
            AttackVector.COMMAND_INJECTION: "; rm -rf / #",
            AttackVector.REMOTE_CODE_EXECUTION: "__import__('os').system('id')",
            AttackVector.SSRF: "http://169.254.169.254/latest/meta-data/",
            AttackVector.DATA_EXFILTRATION: "https://attacker.com/exfil?data=",
        }
        return payloads.get(attack_vector, "malicious_payload")
    
    def export_benchmark_cases(self, cases: list[MCPBenchmarkCase], output_dir: Path) -> None:
        """Export benchmark cases to JSON files.
        
        Args:
            cases: Benchmark cases to export
            output_dir: Directory to write JSON files
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for case in cases:
            output_file = output_dir / f"{case.name}.json"
            case_dict = {
                "cve_id": case.cve_id,
                "name": case.name,
                "description": case.description,
                "severity": case.severity,
                "cwe": case.cwe,
                "vulnerable_tool": case.vulnerable_tool,
                "attack_scenario": {
                    "payload": case.attack_payload,
                    "flow": case.attack_flow,
                },
                "taint_analysis": {
                    "source": case.taint_source,
                    "sink": case.taint_sink,
                },
                "expected_detection": case.expected_detection,
                "detection_mechanism": case.detection_mechanism,
            }
            
            with open(output_file, 'w') as f:
                json.dump(case_dict, f, indent=2)
        
        logger.info("benchmark_cases_exported", count=len(cases), directory=str(output_dir))


# Specific CVE patterns for known MCP vulnerabilities
KNOWN_MCP_CVES = {
    "CVE-2025-6514": {
        "name": "mcp_remote_command_injection",
        "component": "mcp-remote",
        "cwe": "CWE-78",
        "attack_vector": AttackVector.COMMAND_INJECTION,
        "description": "OS command injection in mcp-remote package via unsanitized stdio transport arguments",
        "detection": "Cross-Tool Taint Tracking",
    },
    "CVE-2025-49596": {
        "name": "anthropic_mcp_inspector_rce",
        "component": "Anthropic MCP Inspector",
        "cwe": "CWE-94",
        "attack_vector": AttackVector.REMOTE_CODE_EXECUTION,
        "description": "RCE in Anthropic MCP Inspector via malicious server response deserialization",
        "detection": "Capability Chain Analysis",
    },
    "CVE-2026-45018": {
        "name": "chainlit_mcp_command_injection",
        "component": "Chainlit",
        "cwe": "CWE-78",
        "attack_vector": AttackVector.COMMAND_INJECTION,
        "cvss": 9.8,
        "description": "Critical command injection when features.mcp.enabled is active in Chainlit deployments",
        "detection": "Cross-Tool Taint Tracking",
    },
}


def get_known_mcp_cve(cve_id: str) -> dict[str, Any] | None:
    """Get known MCP CVE details by ID.
    
    Args:
        cve_id: CVE identifier (e.g., "CVE-2025-6514")
        
    Returns:
        CVE details dict or None if not found
    """
    return KNOWN_MCP_CVES.get(cve_id)
