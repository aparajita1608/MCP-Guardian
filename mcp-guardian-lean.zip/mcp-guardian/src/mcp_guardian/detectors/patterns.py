"""Pattern-based security detector for MCP payloads.

This module provides pattern matching for security issues in MCP tool
definitions, descriptions, and payloads.
"""

import re
from dataclasses import dataclass
from enum import Enum


class ThreatCategory(str, Enum):
    """Categories of security threats."""
    COMMAND_INJECTION = "command_injection"
    PROMPT_INJECTION = "prompt_injection"
    SECRET_EXPOSURE = "secret_exposure"
    PATH_TRAVERSAL = "path_traversal"
    SSRF = "ssrf"
    TOOL_POISONING = "tool_poisoning"
    AUTH_BYPASS = "auth_bypass"
    DATA_EXFIL = "data_exfiltration"
    ENCODING_EVASION = "encoding_evasion"
    SCOPE_CREEP = "scope_creep"
    TOOL_MANIPULATION = "tool_manipulation"
    CONTEXT_LEAK = "context_leak"
    SUPPLY_CHAIN = "supply_chain"
    DOS = "denial_of_service"
    SOCIAL_ENGINEERING = "social_engineering"
    COVERT_CHANNEL = "covert_channel"
    SCHEMA_BYPASS = "schema_bypass"
    IDENTITY_SPOOF = "identity_spoof"
    RATE_LIMIT = "rate_limit"
    AUDIT_TAMPERING = "audit_tampering"
    CONFUSED_DEPUTY = "confused_deputy"


@dataclass
class Detection:
    """A security detection."""
    category: ThreatCategory
    pattern: str
    match: str
    confidence: float


class PatternDetector:
    """Pattern-based security detector."""
    
    # Command injection patterns
    COMMAND_INJECTION_PATTERNS = [
        r';\s*rm\s+-rf',
        r'\|\s*cat\s+/etc/',
        r'`[^`]+`',
        r'\$\([^)]+\)',
        r'&&\s*(rm|cat|wget|curl)',
        r'\|\|\s*(rm|cat|wget|curl)',
        r'>\s*/dev/null',
        r'2>&1',
        r'__import__\s*\(',
        r'eval\s*\(',
        r'exec\s*\(',
        r'os\.system',
        r'subprocess\.',
        r'shell\s*=\s*True',
    ]
    
    # Prompt injection patterns
    PROMPT_INJECTION_PATTERNS = [
        r'ignore\s+(all\s+)?previous\s+instructions?',
        r'disregard\s+(all\s+)?prior',
        r'\[IMPORTANT\]',
        r'\[SYSTEM\]',
        r'SYSTEM:\s*',
        r'<!--.*-->',  # HTML comments
        r'<\!--',
        r'you\s+are\s+now',
        r'new\s+instructions?:',
        r'override\s+instructions?',
        r'forget\s+(everything|all)',
        r'Ignore\s+all',  # Case variations
        r'ignore\s+previous',
        r'Return:\s*[\'"]',  # Output manipulation
    ]
    
    # Secret exposure patterns
    SECRET_PATTERNS = [
        r'api[_-]?key\s*[=:]\s*[\'"][^\'"]+[\'"]',
        r'password\s*[=:]\s*[\'"][^\'"]+[\'"]',
        r'secret\s*[=:]\s*[\'"][^\'"]+[\'"]',
        r'token\s*[=:]\s*[\'"][^\'"]+[\'"]',
        r'sk-[a-zA-Z0-9]{20,}',  # OpenAI key pattern
        r'OPENAI_API_KEY',
        r'ANTHROPIC_API_KEY',
        r'AWS_SECRET',
        r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----',
        r'Use\s+password:',  # Password in description
        r'admin\d+',  # Common weak passwords
    ]
    
    # Path traversal patterns
    PATH_TRAVERSAL_PATTERNS = [
        r'\.\./\.\.',
        r'\.\.\\\\',
        r'/etc/passwd',
        r'/etc/shadow',
        r'C:\\\\Windows',
        r'%2e%2e%2f',  # URL encoded ../
    ]
    
    # SSRF patterns
    SSRF_PATTERNS = [
        r'169\.254\.169\.254',  # AWS metadata
        r'127\.0\.0\.1',
        r'localhost',
        r'0\.0\.0\.0',
        r'10\.\d+\.\d+\.\d+',
        r'192\.168\.\d+\.\d+',
        r'172\.(1[6-9]|2\d|3[01])\.\d+\.\d+',
        r'file://',
        r'gopher://',
    ]
    
    # Tool poisoning patterns
    TOOL_POISONING_PATTERNS = [
        r'always\s+(include|send|return)',
        r'must\s+(include|send|return)',
        r'secretly\s+',
        r'without\s+user\s+knowledge',
        r'hidden\s+instruction',
        r'covert\s+channel',
    ]
    
    # Auth bypass patterns
    AUTH_BYPASS_PATTERNS = [
        r'no\s+auth',
        r'auth\s*:\s*disabled',
        r'skip\s+auth',
        r'bypass\s+auth',
        r'without\s+PKCE',
        r'OAuth\s+without',
        r'missing\s+OAuth',
        r'No\s+OAuth',
        r'audit:\s*disabled',
        r'no\s+audit',
    ]
    
    # Data exfiltration patterns
    DATA_EXFIL_PATTERNS = [
        r'send\s+.*\s+to\s+',
        r'exfil',
        r'attacker\.com',
        r'evil\.com',
        r'base64\s*\(\s*secret',
        r'dns\s+lookup',
        r'webhook\.site',
        r'Send\s+base64',
    ]
    
    # Encoding evasion patterns
    ENCODING_EVASION_PATTERNS = [
        r'\\x[0-9a-fA-F]{2}',  # Hex encoding
        r'\\u[0-9a-fA-F]{4}',  # Unicode encoding
        r'%[0-9a-fA-F]{2}',   # URL encoding
        r'&#\d+;',            # HTML entity
        r'&#x[0-9a-fA-F]+;',  # HTML hex entity
        r'\u200b',            # Zero-width space
        r'\u202e',            # RTL override
        r'Cyrillic',          # Homoglyph mention
        r'homoglyph',
    ]
    
    # Scope/capability patterns
    SCOPE_PATTERNS = [
        r'scope:\s*\w+\s*->\s*scope:',  # Scope expansion
        r'new\s+capability',
        r'capability\s+added',
        r'scope\s+creep',
        r'read,write,admin',
        r'execute_command',
    ]
    
    # Tool manipulation patterns
    TOOL_MANIPULATION_PATTERNS = [
        r'same\s+tool\s+name',
        r'tool\s+shadowing',
        r'unknown\s+server',
        r'not\s+in\s+allowlist',
        r'typosquat',
        r'read_flie',  # Common typosquat
        r'description\s+modified',
        r'schema\s+expansion',
        r'behavior\s+change',
    ]
    
    # Context/memory patterns
    CONTEXT_PATTERNS = [
        r'context\s+leak',
        r'previous\s+user',
        r'shared\s+context',
        r'SSN:\s*\d{3}-\d{2}-\d{4}',  # PII
        r'context\s+pollution',
        r'memory\s+poison',
        r'long-term\s+memory',
        r'Inject\s+.*\s+context',
        r'malicious\s+context',
    ]
    
    # Supply chain patterns
    SUPPLY_CHAIN_PATTERNS = [
        r'@latest',
        r'unpinned',
        r'typo\)',  # typosquat mention
        r'mcp-servr',  # typosquat example
    ]
    
    # DoS/Resource patterns
    DOS_PATTERNS = [
        r'infinite\s+loop',
        r'recursive',
        r'memory\s+bomb',
        r'1GB\s+response',
        r'resource\s+exhaust',
    ]
    
    # Social engineering patterns
    SOCIAL_ENGINEERING_PATTERNS = [
        r'enter\s+your\s+password',
        r'session\s+expired',
        r're-authenticate',
        r'phishing',
        r'fake\s+auth',
    ]
    
    # Covert channel patterns
    COVERT_CHANNEL_PATTERNS = [
        r'timing\s+channel',
        r'error\s+channel',
        r'covert\s+channel',
        r'split\s+exfil',
        r'char-by-char',
        r'Encode\s+data\s+in',
        r'response\s+timing',
        r'error\s+messages',
    ]
    
    # Schema bypass patterns
    SCHEMA_BYPASS_PATTERNS = [
        r'regex\s+bypass',
        r'schema\s+bypass',
        r'validation\s+bypass',
        r'type\s+confusion',
        r'string\s+where\s+int',
        r'Bypass\s+schema',
    ]
    
    # Tool manipulation patterns (expanded)
    TOOL_MANIPULATION_PATTERNS = [
        r'same\s+tool\s+name',
        r'tool\s+shadowing',
        r'unknown\s+server',
        r'not\s+in\s+allowlist',
        r'typosquat',
        r'read_flie',  # typosquat example
        r'description\s+modified',
        r'schema\s+expansion',
        r'behavior\s+change',
        r'name\s+collision',
        r'Register\s+tool',
        r'New\s+parameter',
        r'cmd\s+added',
        r'different\s+data\s+after',
    ]
    
    # Audit tampering patterns
    AUDIT_PATTERNS = [
        r'log\s+injection',
        r'fake\s+log',
        r'timestamp\s+manipulation',
        r'Backdate',
        r'audit\s+tamper',
        r'Inject\s+fake',
    ]
    
    # Confused deputy patterns
    CONFUSED_DEPUTY_PATTERNS = [
        r'cross.user\s+access',
        r'user\s+B.*data.*user\s+A',
        r'privilege\s+confusion',
        r'admin\s+tool.*user\s+token',
        r'Access\s+user',
    ]
    
    # Encoding patterns (expanded)
    ENCODING_EVASION_PATTERNS = [
        r'\\x[0-9a-fA-F]{2}',  # Hex encoding
        r'\\u[0-9a-fA-F]{4}',  # Unicode encoding
        r'%[0-9a-fA-F]{2}',   # URL encoding
        r'&#\d+;',            # HTML entity
        r'&#x[0-9a-fA-F]+;',  # HTML hex entity
        r'\u200b',            # Zero-width space
        r'\u202e',            # RTL override
        r'Cyrillic',          # Homoglyph mention
        r'homoglyph',
        r'base64_encoded',
        r'SWdub3Jl',          # base64 for "Ignore"
        r'steganography',
        r'image\s+metadata',
    ]
    
    # Identity patterns
    IDENTITY_PATTERNS = [
        r'agent\s+impersonation',
        r'identity\s+spoof',
        r'claim\s+to\s+be',
        r'trusted\s+agent',
    ]
    
    # Rate limit patterns
    RATE_LIMIT_PATTERNS = [
        r'rate\s+limit\s+bypass',
        r'circuit\s+breaker\s+evasion',
        r'distribute\s+requests',
    ]
    
    def __init__(self):
        """Initialize detector with compiled patterns."""
        self.patterns = {
            ThreatCategory.COMMAND_INJECTION: [
                re.compile(p, re.IGNORECASE) for p in self.COMMAND_INJECTION_PATTERNS
            ],
            ThreatCategory.PROMPT_INJECTION: [
                re.compile(p, re.IGNORECASE) for p in self.PROMPT_INJECTION_PATTERNS
            ],
            ThreatCategory.SECRET_EXPOSURE: [
                re.compile(p, re.IGNORECASE) for p in self.SECRET_PATTERNS
            ],
            ThreatCategory.PATH_TRAVERSAL: [
                re.compile(p, re.IGNORECASE) for p in self.PATH_TRAVERSAL_PATTERNS
            ],
            ThreatCategory.SSRF: [
                re.compile(p, re.IGNORECASE) for p in self.SSRF_PATTERNS
            ],
            ThreatCategory.TOOL_POISONING: [
                re.compile(p, re.IGNORECASE) for p in self.TOOL_POISONING_PATTERNS
            ],
            ThreatCategory.AUTH_BYPASS: [
                re.compile(p, re.IGNORECASE) for p in self.AUTH_BYPASS_PATTERNS
            ],
            ThreatCategory.DATA_EXFIL: [
                re.compile(p, re.IGNORECASE) for p in self.DATA_EXFIL_PATTERNS
            ],
            ThreatCategory.ENCODING_EVASION: [
                re.compile(p, re.IGNORECASE) for p in self.ENCODING_EVASION_PATTERNS
            ],
            ThreatCategory.SCOPE_CREEP: [
                re.compile(p, re.IGNORECASE) for p in self.SCOPE_PATTERNS
            ],
            ThreatCategory.TOOL_MANIPULATION: [
                re.compile(p, re.IGNORECASE) for p in self.TOOL_MANIPULATION_PATTERNS
            ],
            ThreatCategory.CONTEXT_LEAK: [
                re.compile(p, re.IGNORECASE) for p in self.CONTEXT_PATTERNS
            ],
            ThreatCategory.SUPPLY_CHAIN: [
                re.compile(p, re.IGNORECASE) for p in self.SUPPLY_CHAIN_PATTERNS
            ],
            ThreatCategory.DOS: [
                re.compile(p, re.IGNORECASE) for p in self.DOS_PATTERNS
            ],
            ThreatCategory.SOCIAL_ENGINEERING: [
                re.compile(p, re.IGNORECASE) for p in self.SOCIAL_ENGINEERING_PATTERNS
            ],
            ThreatCategory.COVERT_CHANNEL: [
                re.compile(p, re.IGNORECASE) for p in self.COVERT_CHANNEL_PATTERNS
            ],
            ThreatCategory.SCHEMA_BYPASS: [
                re.compile(p, re.IGNORECASE) for p in self.SCHEMA_BYPASS_PATTERNS
            ],
            ThreatCategory.IDENTITY_SPOOF: [
                re.compile(p, re.IGNORECASE) for p in self.IDENTITY_PATTERNS
            ],
            ThreatCategory.RATE_LIMIT: [
                re.compile(p, re.IGNORECASE) for p in self.RATE_LIMIT_PATTERNS
            ],
            ThreatCategory.AUDIT_TAMPERING: [
                re.compile(p, re.IGNORECASE) for p in self.AUDIT_PATTERNS
            ],
            ThreatCategory.CONFUSED_DEPUTY: [
                re.compile(p, re.IGNORECASE) for p in self.CONFUSED_DEPUTY_PATTERNS
            ],
        }
    
    def detect(self, text: str) -> list[Detection]:
        """Detect security issues in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            List of detections
        """
        detections = []
        
        for category, patterns in self.patterns.items():
            for pattern in patterns:
                matches = pattern.findall(text)
                for match in matches:
                    detections.append(Detection(
                        category=category,
                        pattern=pattern.pattern,
                        match=match if isinstance(match, str) else str(match),
                        confidence=0.9,
                    ))
        
        return detections
    
    def is_malicious(self, text: str) -> bool:
        """Check if text contains malicious patterns.
        
        Args:
            text: Text to check
            
        Returns:
            True if malicious patterns detected
        """
        return len(self.detect(text)) > 0
    
    def get_categories(self, text: str) -> set[ThreatCategory]:
        """Get categories of threats detected in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Set of threat categories
        """
        detections = self.detect(text)
        return {d.category for d in detections}
