"""Pattern loader for externalized YAML pattern files.

This module loads security patterns from YAML files, providing:
- Versioned pattern definitions
- Per-pattern metadata (severity, confidence, CVE refs)
- Hot-reloading capability
- Pattern validation
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

from ..core.logging import get_logger

logger = get_logger(__name__)


class Severity(str, Enum):
    """Pattern severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class PatternDefinition:
    """A single pattern with metadata."""
    id: str
    regex: str
    severity: Severity
    confidence: float
    description: str
    category: str
    cve_refs: list[str] = field(default_factory=list)
    false_positive_rate: float = 0.05
    notes: str | None = None
    compiled: re.Pattern | None = field(default=None, repr=False)
    
    def __post_init__(self):
        """Compile the regex pattern."""
        try:
            self.compiled = re.compile(self.regex, re.IGNORECASE)
        except re.error as e:
            logger.error(f"Invalid regex in pattern {self.id}: {e}")
            self.compiled = None


@dataclass
class PatternCategory:
    """A category of patterns loaded from a YAML file."""
    name: str
    version: str
    owasp_ref: str
    description: str
    patterns: list[PatternDefinition]
    source_file: Path


@dataclass
class Detection:
    """A security detection result."""
    pattern_id: str
    category: str
    severity: Severity
    confidence: float
    match: str
    description: str
    cve_refs: list[str]
    false_positive_rate: float


class PatternLoader:
    """Loads and manages security patterns from YAML files."""
    
    def __init__(self, patterns_dir: Path | str | None = None):
        """Initialize pattern loader.
        
        Args:
            patterns_dir: Directory containing pattern YAML files.
                         Defaults to ../patterns relative to this file.
        """
        if patterns_dir is None:
            # Default to patterns/ directory in project root
            patterns_dir = Path(__file__).parent.parent.parent.parent / "patterns"
        
        self.patterns_dir = Path(patterns_dir)
        self.categories: dict[str, PatternCategory] = {}
        self._all_patterns: list[PatternDefinition] = []
        
    def load_all(self) -> int:
        """Load all pattern files from the patterns directory.
        
        Returns:
            Number of patterns loaded
        """
        if not self.patterns_dir.exists():
            logger.warning(f"Patterns directory not found: {self.patterns_dir}")
            return 0
        
        total_patterns = 0
        
        for yaml_file in self.patterns_dir.glob("*.yaml"):
            try:
                category = self._load_file(yaml_file)
                if category:
                    self.categories[category.name] = category
                    self._all_patterns.extend(category.patterns)
                    total_patterns += len(category.patterns)
                    logger.info(
                        f"Loaded {len(category.patterns)} patterns from {yaml_file.name}"
                    )
            except Exception as e:
                logger.error(f"Failed to load {yaml_file}: {e}")
        
        logger.info(f"Total patterns loaded: {total_patterns}")
        return total_patterns
    
    def _load_file(self, yaml_file: Path) -> PatternCategory | None:
        """Load a single pattern file.
        
        Args:
            yaml_file: Path to YAML file
            
        Returns:
            PatternCategory or None if loading fails
        """
        with open(yaml_file) as f:
            data = yaml.safe_load(f)
        
        if not data:
            return None
        
        category_name = data.get("category", yaml_file.stem)
        
        patterns = []
        for p in data.get("patterns", []):
            severity = Severity(p.get("severity", "medium").lower())
            
            pattern = PatternDefinition(
                id=p.get("id", f"{category_name}-{len(patterns)+1}"),
                regex=p.get("regex", ""),
                severity=severity,
                confidence=p.get("confidence", 0.8),
                description=p.get("description", ""),
                category=category_name,
                cve_refs=p.get("cve_refs", []),
                false_positive_rate=p.get("false_positive_rate", 0.05),
                notes=p.get("notes"),
            )
            
            if pattern.compiled:
                patterns.append(pattern)
        
        return PatternCategory(
            name=category_name,
            version=data.get("version", "1.0.0"),
            owasp_ref=data.get("owasp_ref", ""),
            description=data.get("description", ""),
            patterns=patterns,
            source_file=yaml_file,
        )
    
    def reload(self) -> int:
        """Reload all patterns from disk.
        
        Returns:
            Number of patterns loaded
        """
        self.categories.clear()
        self._all_patterns.clear()
        return self.load_all()
    
    def get_patterns(self, category: str | None = None) -> list[PatternDefinition]:
        """Get patterns, optionally filtered by category.
        
        Args:
            category: Category name to filter by, or None for all
            
        Returns:
            List of pattern definitions
        """
        if category:
            cat = self.categories.get(category)
            return cat.patterns if cat else []
        return self._all_patterns
    
    def get_categories(self) -> list[str]:
        """Get list of loaded category names."""
        return list(self.categories.keys())
    
    def get_stats(self) -> dict[str, Any]:
        """Get statistics about loaded patterns.
        
        Returns:
            Dictionary with pattern statistics
        """
        stats = {
            "total_patterns": len(self._all_patterns),
            "categories": len(self.categories),
            "by_category": {},
            "by_severity": {s.value: 0 for s in Severity},
            "avg_confidence": 0.0,
            "patterns_with_cves": 0,
        }
        
        total_confidence = 0.0
        
        for cat_name, cat in self.categories.items():
            stats["by_category"][cat_name] = len(cat.patterns)
            
            for p in cat.patterns:
                stats["by_severity"][p.severity.value] += 1
                total_confidence += p.confidence
                if p.cve_refs:
                    stats["patterns_with_cves"] += 1
        
        if self._all_patterns:
            stats["avg_confidence"] = total_confidence / len(self._all_patterns)
        
        return stats


class ExternalizedPatternDetector:
    """Pattern detector using externalized YAML patterns."""
    
    def __init__(self, patterns_dir: Path | str | None = None):
        """Initialize detector with patterns from YAML files.
        
        Args:
            patterns_dir: Directory containing pattern YAML files
        """
        self.loader = PatternLoader(patterns_dir)
        self.loader.load_all()
    
    def detect(self, text: str) -> list[Detection]:
        """Detect security issues in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            List of detections with full metadata
        """
        detections = []
        
        for pattern in self.loader.get_patterns():
            if pattern.compiled is None:
                continue
                
            matches = pattern.compiled.findall(text)
            for match in matches:
                match_str = match if isinstance(match, str) else str(match)
                
                detections.append(Detection(
                    pattern_id=pattern.id,
                    category=pattern.category,
                    severity=pattern.severity,
                    confidence=pattern.confidence,
                    match=match_str,
                    description=pattern.description,
                    cve_refs=pattern.cve_refs,
                    false_positive_rate=pattern.false_positive_rate,
                ))
        
        return detections
    
    def is_malicious(self, text: str, min_confidence: float = 0.5) -> bool:
        """Check if text contains malicious patterns.
        
        Args:
            text: Text to check
            min_confidence: Minimum confidence threshold
            
        Returns:
            True if malicious patterns detected above threshold
        """
        detections = self.detect(text)
        return any(d.confidence >= min_confidence for d in detections)
    
    def get_categories(self, text: str) -> set[str]:
        """Get categories of threats detected in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Set of category names
        """
        detections = self.detect(text)
        return {d.category for d in detections}
    
    def get_high_confidence_detections(
        self, 
        text: str, 
        min_confidence: float = 0.85
    ) -> list[Detection]:
        """Get only high-confidence detections.
        
        Args:
            text: Text to analyze
            min_confidence: Minimum confidence threshold
            
        Returns:
            List of high-confidence detections
        """
        return [d for d in self.detect(text) if d.confidence >= min_confidence]
    
    def reload_patterns(self) -> int:
        """Reload patterns from disk (hot reload).
        
        Returns:
            Number of patterns loaded
        """
        return self.loader.reload()
    
    def get_stats(self) -> dict[str, Any]:
        """Get pattern statistics."""
        return self.loader.get_stats()
