"""Hybrid detector combining pattern matching with AI validation.

This module provides:
1. Fast pattern-based detection (first pass)
2. AI validation to reduce false positives (second pass)
3. AI-only detection for novel attacks (optional)
"""

import os
from dataclasses import dataclass
from typing import Any

from .pattern_loader import (
    ExternalizedPatternDetector,
    Detection,
    Severity,
)
from ..ai import AISecurityAnalyzer, AIProvider, AIAnalysisResult
from ..core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class HybridDetection:
    """Detection result from hybrid analysis."""
    pattern_id: str | None
    category: str
    severity: Severity
    confidence: float
    match: str
    description: str
    ai_validated: bool
    ai_confidence: float | None
    ai_reasoning: str | None
    is_false_positive: bool


class HybridDetector:
    """Hybrid detector using patterns + AI validation."""
    
    def __init__(
        self,
        patterns_dir: str | None = None,
        ai_provider: AIProvider = AIProvider.OPENAI,
        ai_model: str | None = None,
        ai_enabled: bool = True,
        fp_reduction_threshold: float = 0.7,
    ):
        """Initialize hybrid detector.
        
        Args:
            patterns_dir: Directory containing pattern YAML files
            ai_provider: AI provider for validation
            ai_model: AI model to use
            ai_enabled: Whether to use AI validation
            fp_reduction_threshold: AI confidence below which to mark as FP
        """
        self.pattern_detector = ExternalizedPatternDetector(patterns_dir)
        self.ai_enabled = ai_enabled and self._check_ai_available(ai_provider)
        self.fp_threshold = fp_reduction_threshold
        
        if self.ai_enabled:
            self.ai_analyzer = AISecurityAnalyzer(
                provider=ai_provider,
                model=ai_model,
            )
        else:
            self.ai_analyzer = None
    
    def _check_ai_available(self, provider: AIProvider) -> bool:
        """Check if AI provider is available."""
        if provider == AIProvider.OPENAI:
            return bool(os.environ.get("OPENAI_API_KEY"))
        elif provider == AIProvider.ANTHROPIC:
            return bool(os.environ.get("ANTHROPIC_API_KEY"))
        elif provider == AIProvider.LOCAL:
            return True  # Assume local is available
        return False
    
    def detect(
        self,
        text: str,
        validate_with_ai: bool = True,
        context: str = "",
    ) -> list[HybridDetection]:
        """Detect security issues with optional AI validation.
        
        Args:
            text: Text to analyze
            validate_with_ai: Whether to validate pattern matches with AI
            context: Additional context for AI analysis
            
        Returns:
            List of hybrid detections
        """
        # Step 1: Fast pattern matching
        pattern_detections = self.pattern_detector.detect(text)
        
        if not pattern_detections:
            return []
        
        # Step 2: AI validation (if enabled)
        if validate_with_ai and self.ai_enabled and self.ai_analyzer:
            return self._validate_with_ai(pattern_detections, text, context)
        
        # Return pattern detections without AI validation
        return [
            HybridDetection(
                pattern_id=d.pattern_id,
                category=d.category,
                severity=d.severity,
                confidence=d.confidence,
                match=d.match,
                description=d.description,
                ai_validated=False,
                ai_confidence=None,
                ai_reasoning=None,
                is_false_positive=False,
            )
            for d in pattern_detections
        ]
    
    def _validate_with_ai(
        self,
        detections: list[Detection],
        text: str,
        context: str,
    ) -> list[HybridDetection]:
        """Validate pattern detections with AI.
        
        Args:
            detections: Pattern detections to validate
            text: Original text
            context: Additional context
            
        Returns:
            Validated hybrid detections
        """
        validated = []
        
        # Group detections by category to reduce API calls
        categories = {d.category for d in detections}
        
        # Build validation prompt
        prompt = self._build_validation_prompt(text, detections, context)
        
        try:
            # Call AI for validation
            result = self.ai_analyzer._call_llm(prompt)
            ai_result = self.ai_analyzer._parse_json_response(result)
            
            # Process AI response
            is_malicious = ai_result.get("is_malicious", True)
            ai_confidence = ai_result.get("confidence", 0.5)
            reasoning = ai_result.get("reasoning", "")
            false_positive_patterns = ai_result.get("false_positive_patterns", [])
            
            for d in detections:
                is_fp = (
                    d.pattern_id in false_positive_patterns or
                    (not is_malicious and ai_confidence > self.fp_threshold)
                )
                
                # Adjust confidence based on AI
                adjusted_confidence = d.confidence
                if is_fp:
                    adjusted_confidence *= 0.3  # Reduce confidence for FPs
                elif is_malicious:
                    adjusted_confidence = min(1.0, d.confidence * 1.1)  # Boost for confirmed
                
                validated.append(HybridDetection(
                    pattern_id=d.pattern_id,
                    category=d.category,
                    severity=d.severity,
                    confidence=adjusted_confidence,
                    match=d.match,
                    description=d.description,
                    ai_validated=True,
                    ai_confidence=ai_confidence,
                    ai_reasoning=reasoning,
                    is_false_positive=is_fp,
                ))
            
        except Exception as e:
            logger.error(f"AI validation failed: {e}")
            # Fall back to pattern-only results
            for d in detections:
                validated.append(HybridDetection(
                    pattern_id=d.pattern_id,
                    category=d.category,
                    severity=d.severity,
                    confidence=d.confidence,
                    match=d.match,
                    description=d.description,
                    ai_validated=False,
                    ai_confidence=None,
                    ai_reasoning=f"AI validation failed: {e}",
                    is_false_positive=False,
                ))
        
        return validated
    
    def _build_validation_prompt(
        self,
        text: str,
        detections: list[Detection],
        context: str,
    ) -> str:
        """Build AI validation prompt."""
        detection_summary = "\n".join([
            f"- {d.pattern_id}: {d.category} ({d.description})"
            for d in detections[:5]  # Limit to top 5
        ])
        
        return f"""Analyze this text for security issues. Pattern matching detected potential threats.

TEXT TO ANALYZE:
{text[:1000]}

PATTERN DETECTIONS:
{detection_summary}

CONTEXT:
{context or "MCP tool description or configuration"}

Determine if these are TRUE POSITIVES (real security issues) or FALSE POSITIVES (benign text that triggered patterns).

Consider:
1. Is this a legitimate tool description or malicious instruction?
2. Does the context suggest normal functionality or attack behavior?
3. Are the matched patterns in a dangerous context or benign usage?

Respond in JSON:
{{
    "is_malicious": true/false,
    "confidence": 0.0-1.0,
    "reasoning": "explanation",
    "false_positive_patterns": ["pattern_ids that are false positives"]
}}"""
    
    def is_malicious(
        self,
        text: str,
        min_confidence: float = 0.5,
        validate_with_ai: bool = True,
    ) -> bool:
        """Check if text is malicious.
        
        Args:
            text: Text to check
            min_confidence: Minimum confidence threshold
            validate_with_ai: Whether to use AI validation
            
        Returns:
            True if malicious (excluding false positives)
        """
        detections = self.detect(text, validate_with_ai=validate_with_ai)
        
        # Filter out false positives and low confidence
        real_threats = [
            d for d in detections
            if not d.is_false_positive and d.confidence >= min_confidence
        ]
        
        return len(real_threats) > 0
    
    def get_stats(self) -> dict[str, Any]:
        """Get detector statistics."""
        stats = self.pattern_detector.get_stats()
        stats["ai_enabled"] = self.ai_enabled
        stats["ai_provider"] = self.ai_analyzer.provider.value if self.ai_analyzer else None
        return stats
