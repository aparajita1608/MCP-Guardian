"""MCP Guardian Detectors.

This module provides security detection capabilities:
- PatternDetector: Original hardcoded pattern detector
- ExternalizedPatternDetector: YAML-based pattern detector
- HybridDetector: Pattern + AI validation detector
"""

from .patterns import PatternDetector, Detection, ThreatCategory
from .pattern_loader import (
    ExternalizedPatternDetector,
    PatternLoader,
    PatternDefinition,
    PatternCategory,
    Severity,
    Detection as ExternalizedDetection,
)
from .hybrid import HybridDetector, HybridDetection

__all__ = [
    # Original detector
    "PatternDetector",
    "Detection",
    "ThreatCategory",
    # Externalized detector
    "ExternalizedPatternDetector",
    "PatternLoader",
    "PatternDefinition",
    "PatternCategory",
    "Severity",
    "ExternalizedDetection",
    # Hybrid detector
    "HybridDetector",
    "HybridDetection",
]
