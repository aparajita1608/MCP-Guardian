"""Scan commands for mcp-guardian CLI."""

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..core import Finding, Severity, calculate_risk_score, get_risk_color, get_risk_level
from ..scanners.config import ConfigScanner, get_default_config_paths

app = typer.Typer(help="Scan MCP configurations, source code, or live servers")
console = Console()


@app.command("config")
def scan_config(
    path: str | None = typer.Argument(None, help="Path to config file (auto-detects if not provided)"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table, json, sarif, html"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
) -> None:
    """Scan MCP client configuration files for security issues.

    Supports Claude Desktop, Cursor, and VS Code configurations.
    If no path is provided, scans default configuration locations.
    """
    config_paths: list[Path] = []

    if path:
        config_path = Path(path)
        if not config_path.exists():
            console.print(f"[red]Error:[/red] File not found: {path}")
            raise typer.Exit(1)
        config_paths = [config_path]
    else:
        # Auto-detect config files
        config_paths = get_default_config_paths()
        if not config_paths:
            console.print("[yellow]No MCP configuration files found in default locations.[/yellow]")
            console.print("\nChecked locations:")
            for p in get_default_config_paths.__doc__ or "":
                console.print(f"  - {p}")
            raise typer.Exit(0)

    all_findings: list[Finding] = []

    for config_path in config_paths:
        console.print(f"\n[bold blue]Scanning:[/bold blue] {config_path}")
        findings = _scan_config_file(config_path)
        all_findings.extend(findings)

    _output_results(all_findings, format, output, len(config_paths))


@app.command("source")
def scan_source(
    path: str = typer.Argument(..., help="Path to source directory or file"),
    lang: str | None = typer.Option(None, "--lang", "-l", help="Language: python, typescript, javascript"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table, json, sarif, html"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    ai: bool = typer.Option(False, "--ai", help="Enable AI-powered analysis"),
    ai_provider: str = typer.Option("anthropic", "--ai-provider", help="AI provider"),
    ai_model: str | None = typer.Option(None, "--ai-model", help="AI model to use"),
) -> None:
    """Scan MCP server source code for security vulnerabilities.

    Detects command injection, secrets exposure, SSRF, and more.
    """
    # Store AI settings for potential use
    _ai_settings = {
        "enabled": ai,
        "provider": ai_provider,
        "model": ai_model,
    }

    # Store language filter for potential use
    _language_filter = lang

    source_path = Path(path)
    if not source_path.exists():
        console.print(f"[red]Error:[/red] Path not found: {path}")
        raise typer.Exit(1)

    console.print(f"\n[bold blue]Scanning source:[/bold blue] {source_path}")

    if ai:
        console.print(f"[dim]AI analysis enabled ({ai_provider})[/dim]")

    findings, files_count = _scan_source_directory(source_path, language=lang)
    _output_results(findings, format, output, files_count)


@app.command("live")
def scan_live(
    transport: str = typer.Argument(..., help="Transport type: stdio, sse, http"),
    command: str | None = typer.Option(None, "--command", "-c", help="Command to start server (for stdio)"),
    url: str | None = typer.Option(None, "--url", "-u", help="Server URL (for sse/http)"),
) -> None:
    """Scan a live MCP server by connecting to it.

    Enumerates tools, resources, and prompts, then analyzes for security issues.
    """
    # Store options for future implementation
    _live_options = {
        "transport": transport,
        "command": command,
        "url": url,
    }

    console.print("[yellow]Live server scanning coming soon![/yellow]")
    console.print("\nThis feature will:")
    console.print("  - Connect to the MCP server")
    console.print("  - Enumerate available tools, resources, and prompts")
    console.print("  - Analyze tool descriptions for poisoning")
    console.print("  - Test for prompt injection vulnerabilities")


def _scan_config_file(config_path: Path) -> list[Finding]:
    """Scan a single config file and return findings."""
    from ..core import ScanTarget

    scanner = ConfigScanner()
    target = ScanTarget(path=config_path, target_type="config")
    return scanner.scan(target)


def _scan_source_directory(source_path: Path, language: str | None = None) -> tuple[list[Finding], int]:
    """Scan source code directory and return findings and file count."""
    from ..scanners.source import SourceScanner

    scanner = SourceScanner()
    findings: list[Finding] = []
    files_count = 0

    if source_path.is_file():
        findings = scanner.scan_file(source_path)
        files_count = 1
    else:
        # Scan all relevant files
        patterns = ["**/*.py", "**/*.ts", "**/*.js"]
        for pattern in patterns:
            for file_path in source_path.glob(pattern):
                if "/.git/" in str(file_path) or "/node_modules/" in str(file_path):
                    continue
                findings.extend(scanner.scan_file(file_path))
                files_count += 1

    return findings, files_count


def _output_results(
    findings: list[Finding],
    format: str,
    output_path: str | None,
    files_scanned: int,
) -> None:
    """Output results in the specified format."""
    if format == "json":
        from ..reporters.json_reporter import generate_json_report, save_json_report

        if output_path:
            save_json_report(findings, output_path, files_scanned=files_scanned)
            console.print(f"\n[green]Report saved to:[/green] {output_path}")
        else:
            console.print(generate_json_report(findings, files_scanned=files_scanned))
    elif format == "sarif":
        from ..reporters.sarif import generate_sarif

        sarif_content = generate_sarif(findings)
        if output_path:
            Path(output_path).write_text(sarif_content)
            console.print(f"\n[green]SARIF report saved to:[/green] {output_path}")
        else:
            console.print(sarif_content)
    elif format == "html":
        from ..reporters.html import save_html_report

        if output_path:
            save_html_report(findings, output_path, files_scanned=files_scanned)
            console.print(f"\n[green]HTML report saved to:[/green] {output_path}")
        else:
            # Default output path for HTML
            default_path = Path("mcp-guardian-report.html")
            save_html_report(findings, default_path, files_scanned=files_scanned)
            console.print(f"\n[green]HTML report saved to:[/green] {default_path}")
    else:
        # Default: table format
        _display_findings(findings)

    # Always show summary
    score = calculate_risk_score(findings)
    level = get_risk_level(score)
    color = get_risk_color(score)

    console.print(f"\n[bold]Security Score:[/bold] [{color}]{score}/100 ({level})[/{color}]")

    if any(f.severity in (Severity.CRITICAL, Severity.HIGH) for f in findings):
        raise typer.Exit(1)


def _display_findings(findings: list[Finding]) -> None:
    """Display findings in a rich table."""
    if not findings:
        console.print("\n[green]✓ No security issues found![/green]")
        return

    # Group by severity
    by_severity: dict[Severity, list[Finding]] = {s: [] for s in Severity}
    for finding in findings:
        by_severity[finding.severity].append(finding)

    # Summary
    console.print(f"\n[bold]Found {len(findings)} issue(s):[/bold]")

    # Create table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Severity", style="bold", width=10)
    table.add_column("Rule", width=14)
    table.add_column("Location", width=30)
    table.add_column("Message", width=50)

    severity_colors = {
        Severity.CRITICAL: "red",
        Severity.HIGH: "orange1",
        Severity.MEDIUM: "yellow",
        Severity.LOW: "blue",
        Severity.INFO: "dim",
    }

    for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
        for finding in by_severity[severity]:
            color = severity_colors[severity]
            table.add_row(
                f"[{color}]{severity.value.upper()}[/{color}]",
                finding.rule_id,
                str(finding.location),
                finding.title,
            )

    console.print(table)

    # Show details for critical/high findings
    critical_high = by_severity[Severity.CRITICAL] + by_severity[Severity.HIGH]
    if critical_high:
        console.print("\n[bold red]Critical/High Severity Details:[/bold red]")
        for finding in critical_high:
            ai_badge = ""
            if finding.ai_confidence is not None:
                ai_badge = f" [magenta](AI: {finding.ai_confidence:.0%})[/magenta]"

            console.print(
                Panel(
                    f"[bold]{finding.title}[/bold]{ai_badge}\n\n"
                    f"{finding.message}\n\n"
                    f"[bold]Remediation:[/bold] {finding.remediation}",
                    title=f"[red]{finding.rule_id}[/red] @ {finding.location}",
                    border_style="red",
                )
            )
