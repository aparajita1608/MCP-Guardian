"""mcp-guardian CLI - AI-powered security scanner for MCP servers.

Usage:
    mcp-guardian scan config <path>
    mcp-guardian scan source <path> [--lang python|typescript|javascript]
    mcp-guardian scan live <command>
    mcp-guardian audit <path> [--output sarif,json,html]
"""

import typer
from rich.console import Console

from ..core.models import Finding
from .scan import app as scan_app

# Create main app
app = typer.Typer(
    name="mcp-guardian",
    help="AI-powered security scanner for Model Context Protocol (MCP) servers.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Add subcommands
app.add_typer(scan_app, name="scan", help="Scan MCP configurations, source code, or live servers")

console = Console()


@app.command()
def version() -> None:
    """Show version information."""
    from .. import __version__

    console.print(f"[bold blue]mcp-guardian[/bold blue] version [green]{__version__}[/green]")


@app.command()
def audit(
    path: str = typer.Argument(..., help="Path to project directory to audit"),
    output: str = typer.Option("json", "--output", "-o", help="Output formats (comma-separated: json,sarif,html)"),
    fail_on: str = typer.Option(
        "critical,high", "--fail-on", "-f", help="Severity levels that cause non-zero exit (comma-separated)"
    ),
    baseline: str | None = typer.Option(None, "--baseline", "-b", help="Path to baseline SARIF file for comparison"),
    ai_provider: str = typer.Option("anthropic", "--ai-provider", help="AI provider (anthropic, openai, ollama)"),
    ai_model: str | None = typer.Option(None, "--ai-model", help="AI model to use"),
    no_ai: bool = typer.Option(False, "--no-ai", help="Disable AI-powered analysis"),
) -> None:
    """Run a full security audit on an MCP project.

    Scans configuration files, source code, and tool manifests.
    Generates comprehensive security report.
    """
    from pathlib import Path

    from rich.panel import Panel

    from ..core import calculate_risk_score, get_risk_color, get_risk_level
    from .scan import _display_findings, _scan_config_file, _scan_source_directory

    # Store AI settings for potential future use
    _ai_settings = {
        "provider": ai_provider,
        "model": ai_model,
        "enabled": not no_ai,
    }

    project_path = Path(path)
    if not project_path.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {path}")
        raise typer.Exit(1)

    console.print(
        Panel.fit(
            f"[bold]MCP Security Audit[/bold]\n"
            f"Target: [cyan]{project_path.absolute()}[/cyan]\n"
            f"AI: [{'green' if not no_ai else 'red'}]{'Enabled' if not no_ai else 'Disabled'}[/]",
            border_style="blue",
        )
    )

    all_findings = []

    # Scan config files
    config_files = list(project_path.glob("**/mcp*.json")) + list(project_path.glob("**/*config*.json"))
    for config_file in config_files:
        if ".git" in str(config_file) or "node_modules" in str(config_file):
            continue
        console.print(f"\n[dim]Scanning config:[/dim] {config_file}")
        findings = _scan_config_file(config_file)
        all_findings.extend(findings)

    # Scan source code
    source_dirs = [project_path / "src", project_path]
    for source_dir in source_dirs:
        if source_dir.exists():
            console.print(f"\n[dim]Scanning source:[/dim] {source_dir}")
            findings, _ = _scan_source_directory(source_dir)
            all_findings.extend(findings)
            break

    # Display results
    _display_findings(all_findings)

    # Generate output in requested formats
    output_formats = [fmt.strip().lower() for fmt in output.split(",")]
    for fmt in output_formats:
        if fmt == "sarif":
            from ..reporters.sarif import generate_sarif

            sarif_path = project_path / "mcp-guardian-report.sarif"
            sarif_path.write_text(generate_sarif(all_findings))
            console.print(f"[dim]SARIF report saved to:[/dim] {sarif_path}")
        elif fmt == "html":
            from ..reporters.html import save_html_report

            html_path = project_path / "mcp-guardian-report.html"
            save_html_report(all_findings, html_path, files_scanned=len(config_files))
            console.print(f"[dim]HTML report saved to:[/dim] {html_path}")
        elif fmt == "json":
            from ..reporters.json_reporter import save_json_report

            json_path = project_path / "mcp-guardian-report.json"
            save_json_report(all_findings, json_path, files_scanned=len(config_files))
            console.print(f"[dim]JSON report saved to:[/dim] {json_path}")

    # Load baseline for comparison if provided
    baseline_findings: list[Finding] = []
    if baseline:
        baseline_path = Path(baseline)
        if baseline_path.exists():
            import json as json_module

            try:
                baseline_data = json_module.loads(baseline_path.read_text())
                # Extract finding IDs from baseline SARIF
                if "runs" in baseline_data:
                    for run in baseline_data["runs"]:
                        for result in run.get("results", []):
                            baseline_findings.append(result.get("ruleId"))
                console.print(f"[dim]Loaded {len(baseline_findings)} baseline findings[/dim]")
            except (json_module.JSONDecodeError, KeyError):
                console.print("[yellow]Warning: Could not parse baseline file[/yellow]")

    # Calculate and display risk score
    score = calculate_risk_score(all_findings)
    level = get_risk_level(score)
    color = get_risk_color(score)

    console.print(f"\n[bold]Risk Score:[/bold] [{color}]{score}/100 ({level})[/{color}]")

    # Check fail conditions
    fail_severities = [s.strip().lower() for s in fail_on.split(",")]
    should_fail = False
    for finding in all_findings:
        if finding.severity.value in fail_severities:
            should_fail = True
            break

    if should_fail:
        console.print(f"\n[red]Audit failed:[/red] Found findings at severity level(s): {fail_on}")
        raise typer.Exit(1)

    console.print("\n[green]Audit passed![/green]")


@app.command()
def interactive() -> None:
    """Launch interactive TUI mode."""
    console.print("[yellow]Interactive mode coming soon![/yellow]")
    console.print("For now, use: [cyan]mcp-guardian scan config <path>[/cyan]")


def main() -> None:
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
