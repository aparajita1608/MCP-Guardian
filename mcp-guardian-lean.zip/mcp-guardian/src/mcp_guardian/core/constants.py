"""Constants for mcp-guardian.

Centralized configuration values and limits.
"""

# File size limits (in bytes)
MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024  # 10MB
MAX_CONFIG_SIZE_BYTES = 1 * 1024 * 1024  # 1MB

# Pattern limits
MAX_PATTERN_LENGTH = 10000  # Max characters to scan per pattern match

# Supported languages for source scanning
SUPPORTED_LANGUAGES = frozenset({"python", "typescript", "javascript"})

# File extensions by language
LANGUAGE_EXTENSIONS: dict[str, list[str]] = {
    "python": [".py"],
    "typescript": [".ts", ".tsx"],
    "javascript": [".js", ".jsx", ".mjs"],
}

# Directories to skip during scanning
SKIP_DIRECTORIES = frozenset(
    {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".tox",
        "dist",
        "build",
        ".egg-info",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
    }
)

# Default AI providers and models
DEFAULT_AI_PROVIDERS: dict[str, str] = {
    "anthropic": "claude-sonnet-4-20250514",
    "openai": "gpt-4o",
    "ollama": "llama3.2",
    "groq": "llama-3.3-70b-versatile",
    "together": "meta-llama/Llama-3-70b-chat-hf",
}

# Severity weights for risk scoring
SEVERITY_WEIGHTS: dict[str, int] = {
    "critical": 25,
    "high": 15,
    "medium": 8,
    "low": 3,
    "info": 1,
}

# Category multipliers for risk scoring
CATEGORY_MULTIPLIERS: dict[str, float] = {
    "command_injection": 1.5,
    "secrets_exposure": 1.3,
    "sql_injection": 1.3,
    "ssrf": 1.2,
    "prompt_injection": 1.2,
    "tool_poisoning": 1.2,
    "deserialization": 1.1,
    "path_traversal": 1.0,
    "authentication": 1.0,
    "authorization": 1.0,
    "configuration": 0.8,
}
