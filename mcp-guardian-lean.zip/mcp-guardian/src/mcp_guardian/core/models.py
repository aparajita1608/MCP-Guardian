"""Core data models for mcp-guardian.

This module defines the Pydantic models used throughout the scanner
for representing findings, rules, configurations, and scan results.
"""

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class Severity(str, Enum):
    """Severity levels for security findings."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Category(str, Enum):
    """Categories of security vulnerabilities."""

    COMMAND_INJECTION = "command_injection"
    PROMPT_INJECTION = "prompt_injection"
    TOOL_POISONING = "tool_poisoning"
    SSRF = "ssrf"
    SECRETS_EXPOSURE = "secrets_exposure"
    PATH_TRAVERSAL = "path_traversal"
    SQL_INJECTION = "sql_injection"
    DESERIALIZATION = "deserialization"
    CONFIGURATION = "configuration"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"


class Location(BaseModel):
    """Location of a finding in source code or configuration."""

    file: Path
    line: int | None = None
    column: int | None = None
    end_line: int | None = None
    end_column: int | None = None
    snippet: str | None = None

    def __str__(self) -> str:
        if self.line:
            return f"{self.file}:{self.line}"
        return str(self.file)


class Finding(BaseModel):
    """A security finding detected by the scanner."""

    rule_id: str = Field(..., description="Unique identifier for the rule (e.g., MCP-SRC-001)")
    severity: Severity
    category: Category
    title: str = Field(..., description="Short title of the finding")
    message: str = Field(..., description="Detailed description of the vulnerability")
    location: Location
    remediation: str = Field(..., description="How to fix the vulnerability")
    ai_confidence: float | None = Field(
        None, ge=0.0, le=1.0, description="AI confidence score (0.0-1.0) if AI-detected"
    )
    ai_explanation: str | None = Field(None, description="AI-generated explanation if applicable")
    cwe_id: str | None = Field(None, description="CWE identifier (e.g., CWE-78)")
    references: list[str] = Field(default_factory=list, description="URLs to relevant documentation")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

    @property
    def is_ai_detected(self) -> bool:
        """Check if this finding was detected by AI analysis."""
        return self.ai_confidence is not None


class Rule(BaseModel):
    """Definition of a security rule."""

    id: str = Field(..., description="Unique rule identifier (e.g., MCP-SRC-001)")
    name: str = Field(..., description="Human-readable rule name")
    description: str = Field(..., description="Detailed description of what the rule detects")
    severity: Severity
    category: Category
    enabled: bool = True
    tags: list[str] = Field(default_factory=list)
    cwe_id: str | None = None
    references: list[str] = Field(default_factory=list)

    # Pattern matching (for rule-based detection)
    patterns: list[str] = Field(default_factory=list, description="Regex patterns to match")

    # AI detection settings
    ai_enabled: bool = Field(False, description="Whether to use AI for this rule")
    ai_prompt: str | None = Field(None, description="Custom AI prompt for detection")


class ScanTarget(BaseModel):
    """Target to be scanned."""

    path: Path
    target_type: str = Field(..., description="Type: 'config', 'source', 'manifest', 'live'")
    language: str | None = Field(None, description="Programming language (for source scanning)")
    metadata: dict[str, Any] = Field(default_factory=dict)


class ScanConfig(BaseModel):
    """Configuration for a scan run."""

    targets: list[ScanTarget] = Field(default_factory=list)
    rules_path: Path | None = None
    enabled_rules: list[str] | None = Field(None, description="Specific rules to enable (None = all)")
    disabled_rules: list[str] = Field(default_factory=list, description="Rules to disable")
    severity_threshold: Severity = Severity.LOW

    # AI settings
    ai_enabled: bool = True
    ai_provider: str = "anthropic"
    ai_model: str = "claude-sonnet-4-20250514"

    # Output settings
    output_formats: list[str] = Field(default_factory=lambda: ["json"])
    output_path: Path | None = None

    # Baseline comparison
    baseline_path: Path | None = None
    fail_on_new: bool = False


class ScanResult(BaseModel):
    """Result of a complete scan."""

    scan_id: str = Field(..., description="Unique identifier for this scan")
    started_at: datetime
    completed_at: datetime | None = None
    targets: list[ScanTarget]
    findings: list[Finding] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)

    # Statistics
    files_scanned: int = 0
    rules_applied: int = 0
    ai_analyses: int = 0

    # Scoring
    risk_score: int | None = Field(None, ge=0, le=100, description="Overall risk score (0-100)")

    @property
    def duration_seconds(self) -> float | None:
        """Calculate scan duration in seconds."""
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def findings_by_severity(self) -> dict[Severity, list[Finding]]:
        """Group findings by severity."""
        result: dict[Severity, list[Finding]] = {s: [] for s in Severity}
        for finding in self.findings:
            result[finding.severity].append(finding)
        return result

    @property
    def critical_count(self) -> int:
        """Count of critical findings."""
        return len([f for f in self.findings if f.severity == Severity.CRITICAL])

    @property
    def high_count(self) -> int:
        """Count of high severity findings."""
        return len([f for f in self.findings if f.severity == Severity.HIGH])


class MCPServerConfig(BaseModel):
    """Parsed MCP server configuration."""

    name: str
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    transport: str = "stdio"  # stdio, sse, http
    url: str | None = None

    # Security-relevant fields
    auth_type: str | None = None
    tls_enabled: bool | None = None
    bind_address: str | None = None


class MCPClientConfig(BaseModel):
    """Parsed MCP client configuration (Claude Desktop, Cursor, etc.)."""

    config_type: str = Field(..., description="Type: 'claude_desktop', 'cursor', 'vscode'")
    config_path: Path
    servers: list[MCPServerConfig] = Field(default_factory=list)
    raw_config: dict[str, Any] = Field(default_factory=dict)


class ToolDefinition(BaseModel):
    """MCP tool definition for manifest analysis."""

    name: str
    description: str
    input_schema: dict[str, Any] = Field(default_factory=dict)

    # Extracted from live server or manifest
    annotations: dict[str, Any] = Field(default_factory=dict)
