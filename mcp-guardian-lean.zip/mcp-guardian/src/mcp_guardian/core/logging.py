"""Structured logging for mcp-guardian.

Provides consistent logging across all modules with support for
both human-readable and JSON output formats.
"""

import logging
import sys
from typing import Any

# Try to import structlog for structured logging
try:
    import structlog

    STRUCTLOG_AVAILABLE = True
except ImportError:
    STRUCTLOG_AVAILABLE = False


class MCPGuardianLogger:
    """Structured logger for mcp-guardian."""

    SERVICE_NAME = "mcp-guardian"

    def __init__(self, name: str, json_output: bool = False):
        """Initialize logger.

        Args:
            name: Logger name (usually module name)
            json_output: Whether to output JSON format
        """
        self.name = name
        self.json_output = json_output

        if STRUCTLOG_AVAILABLE and json_output:
            self._logger = structlog.get_logger(name)
        else:
            self._logger = logging.getLogger(name)
            if not self._logger.handlers:
                handler = logging.StreamHandler(sys.stderr)
                formatter = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
                handler.setFormatter(formatter)
                self._logger.addHandler(handler)
                self._logger.setLevel(logging.INFO)

    def _format_message(self, event: str, context: dict[str, Any] | None = None) -> str:
        """Format log message with context."""
        if context:
            ctx_str = " | ".join(f"{k}={v}" for k, v in context.items())
            return f"{self.SERVICE_NAME} | Event: {event} | {ctx_str}"
        return f"{self.SERVICE_NAME} | Event: {event}"

    def info(self, event: str, **context: Any) -> None:
        """Log info level message."""
        if STRUCTLOG_AVAILABLE and self.json_output:
            self._logger.info(event, **context)
        else:
            self._logger.info(self._format_message(event, context))

    def warning(self, event: str, **context: Any) -> None:
        """Log warning level message."""
        if STRUCTLOG_AVAILABLE and self.json_output:
            self._logger.warning(event, **context)
        else:
            self._logger.warning(self._format_message(event, context))

    def error(self, event: str, **context: Any) -> None:
        """Log error level message."""
        if STRUCTLOG_AVAILABLE and self.json_output:
            self._logger.error(event, **context)
        else:
            self._logger.error(self._format_message(event, context))

    def debug(self, event: str, **context: Any) -> None:
        """Log debug level message."""
        if STRUCTLOG_AVAILABLE and self.json_output:
            self._logger.debug(event, **context)
        else:
            self._logger.debug(self._format_message(event, context))


def get_logger(name: str, json_output: bool = False) -> MCPGuardianLogger:
    """Get a logger instance.

    Args:
        name: Logger name (usually __name__)
        json_output: Whether to output JSON format

    Returns:
        Configured logger instance
    """
    return MCPGuardianLogger(name, json_output)


def configure_logging(level: str = "INFO", json_output: bool = False) -> None:
    """Configure global logging settings.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        json_output: Whether to output JSON format
    """
    log_level = getattr(logging, level.upper(), logging.INFO)

    if STRUCTLOG_AVAILABLE and json_output:
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.JSONRenderer(),
            ],
            wrapper_class=structlog.stdlib.BoundLogger,
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
            cache_logger_on_first_use=True,
        )

    logging.basicConfig(
        level=log_level,
        format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        stream=sys.stderr,
    )
