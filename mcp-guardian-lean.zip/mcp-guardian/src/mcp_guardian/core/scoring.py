"""Risk scoring algorithm for mcp-guardian.

Calculates an overall risk score (0-100) based on findings,
with configurable weights per severity and category.
"""

from ..core.models import Category, Finding, Severity

# Default severity weights (points deducted per finding)
SEVERITY_WEIGHTS: dict[Severity, int] = {
    Severity.CRITICAL: 25,
    Severity.HIGH: 15,
    Severity.MEDIUM: 8,
    Severity.LOW: 3,
    Severity.INFO: 1,
}

# Category multipliers (some categories are more severe)
CATEGORY_MULTIPLIERS: dict[Category, float] = {
    Category.COMMAND_INJECTION: 1.5,
    Category.SECRETS_EXPOSURE: 1.3,
    Category.SQL_INJECTION: 1.3,
    Category.SSRF: 1.2,
    Category.PROMPT_INJECTION: 1.2,
    Category.TOOL_POISONING: 1.2,
    Category.DESERIALIZATION: 1.1,
    Category.PATH_TRAVERSAL: 1.0,
    Category.AUTHENTICATION: 1.0,
    Category.AUTHORIZATION: 1.0,
    Category.CONFIGURATION: 0.8,
}


def calculate_risk_score(
    findings: list[Finding],
    severity_weights: dict[Severity, int] | None = None,
    category_multipliers: dict[Category, float] | None = None,
) -> int:
    """Calculate overall risk score from findings.

    Args:
        findings: List of security findings
        severity_weights: Custom severity weights (optional)
        category_multipliers: Custom category multipliers (optional)

    Returns:
        Risk score from 0 (secure) to 100 (critical risk)
    """
    if not findings:
        return 100  # Perfect score if no findings

    weights = severity_weights or SEVERITY_WEIGHTS
    multipliers = category_multipliers or CATEGORY_MULTIPLIERS

    total_deduction = 0.0

    for finding in findings:
        base_weight = weights.get(finding.severity, 5)
        multiplier = multipliers.get(finding.category, 1.0)

        # AI-detected findings with low confidence get reduced weight
        if finding.ai_confidence is not None and finding.ai_confidence < 0.7:
            multiplier *= finding.ai_confidence

        total_deduction += base_weight * multiplier

    # Score starts at 100, deductions reduce it
    score = max(0, 100 - int(total_deduction))
    return score


def get_risk_level(score: int) -> str:
    """Get human-readable risk level from score.

    Args:
        score: Risk score (0-100)

    Returns:
        Risk level string
    """
    if score >= 90:
        return "EXCELLENT"
    elif score >= 70:
        return "GOOD"
    elif score >= 50:
        return "MODERATE"
    elif score >= 30:
        return "HIGH RISK"
    else:
        return "CRITICAL"


def get_risk_color(score: int) -> str:
    """Get Rich color for risk score display.

    Args:
        score: Risk score (0-100)

    Returns:
        Rich color string
    """
    if score >= 90:
        return "green"
    elif score >= 70:
        return "blue"
    elif score >= 50:
        return "yellow"
    elif score >= 30:
        return "orange1"
    else:
        return "red"
