"""SARIF reporter for mcp-guardian.

Generates SARIF (Static Analysis Results Interchange Format) output
for integration with GitHub Security, VS Code, and other tools.
"""

import json
from datetime import UTC, datetime
from typing import Any

from ..core.models import Finding, Severity

SARIF_VERSION = "2.1.0"
SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"


def severity_to_sarif_level(severity: Severity) -> str:
    """Convert severity to SARIF level."""
    mapping = {
        Severity.CRITICAL: "error",
        Severity.HIGH: "error",
        Severity.MEDIUM: "warning",
        Severity.LOW: "note",
        Severity.INFO: "note",
    }
    return mapping.get(severity, "warning")


def generate_sarif(findings: list[Finding], tool_version: str = "0.1.0") -> str:
    """Generate SARIF JSON output from findings.

    Args:
        findings: List of security findings
        tool_version: Version of mcp-guardian

    Returns:
        SARIF JSON string
    """
    # Collect unique rules
    rules_map: dict[str, dict[str, Any]] = {}
    for finding in findings:
        if finding.rule_id not in rules_map:
            rules_map[finding.rule_id] = {
                "id": finding.rule_id,
                "name": finding.title,
                "shortDescription": {"text": finding.title},
                "fullDescription": {"text": finding.message},
                "helpUri": f"https://mcp-guardian.dev/rules/{finding.rule_id.lower()}",
                "help": {
                    "text": finding.remediation,
                    "markdown": f"**Remediation:** {finding.remediation}",
                },
                "defaultConfiguration": {
                    "level": severity_to_sarif_level(finding.severity),
                },
                "properties": {
                    "security-severity": _get_security_severity(finding.severity),
                    "tags": ["security", finding.category.value],
                },
            }
            if finding.cwe_id:
                rules_map[finding.rule_id]["properties"]["cwe"] = finding.cwe_id

    # Build results
    results: list[dict[str, Any]] = []
    for finding in findings:
        # Build location structure
        physical_location: dict[str, Any] = {
            "artifactLocation": {
                "uri": str(finding.location.file),
                "uriBaseId": "%SRCROOT%",
            },
        }

        # Add region if line number available
        if finding.location.line:
            region: dict[str, Any] = {"startLine": finding.location.line}
            if finding.location.column:
                region["startColumn"] = finding.location.column
            if finding.location.end_line:
                region["endLine"] = finding.location.end_line
            if finding.location.snippet:
                region["snippet"] = {"text": finding.location.snippet}
            physical_location["region"] = region
        elif finding.location.snippet:
            physical_location["region"] = {"snippet": {"text": finding.location.snippet}}

        result: dict[str, Any] = {
            "ruleId": finding.rule_id,
            "level": severity_to_sarif_level(finding.severity),
            "message": {"text": finding.message},
            "locations": [{"physicalLocation": physical_location}],
        }

        # Add AI confidence if available
        if finding.ai_confidence is not None:
            result["properties"] = {
                "ai_detected": True,
                "ai_confidence": finding.ai_confidence,
            }
            if finding.ai_explanation:
                result["properties"]["ai_explanation"] = finding.ai_explanation

        results.append(result)

    # Build SARIF document
    sarif = {
        "$schema": SARIF_SCHEMA,
        "version": SARIF_VERSION,
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "mcp-guardian",
                        "version": tool_version,
                        "informationUri": "https://github.com/yourusername/mcp-guardian",
                        "rules": list(rules_map.values()),
                    }
                },
                "results": results,
                "invocations": [
                    {
                        "executionSuccessful": True,
                        "endTimeUtc": datetime.now(UTC).isoformat(),
                    }
                ],
            }
        ],
    }

    return json.dumps(sarif, indent=2)


def _get_security_severity(severity: Severity) -> str:
    """Get numeric security severity for SARIF.

    GitHub uses this for security severity display.
    Scale: 0.0 (info) to 10.0 (critical)
    """
    mapping = {
        Severity.CRITICAL: "9.0",
        Severity.HIGH: "7.0",
        Severity.MEDIUM: "5.0",
        Severity.LOW: "3.0",
        Severity.INFO: "1.0",
    }
    return mapping.get(severity, "5.0")
