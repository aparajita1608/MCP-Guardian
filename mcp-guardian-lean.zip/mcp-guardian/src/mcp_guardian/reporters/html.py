"""HTML reporter for mcp-guardian.

Generates beautiful HTML security reports with:
- Executive summary
- Risk score visualization
- Findings grouped by severity
- Detailed remediation guidance
"""

from datetime import datetime
from pathlib import Path

from jinja2 import Template

from ..core.models import Finding, Severity
from ..core.scoring import calculate_risk_score, get_risk_level

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCP Security Report - {{ title }}</title>
    <style>
        :root {
            --critical: #dc2626;
            --high: #ea580c;
            --medium: #ca8a04;
            --low: #2563eb;
            --info: #6b7280;
            --success: #16a34a;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        header {
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            padding: 2rem;
            margin-bottom: 2rem;
            border-radius: 12px;
        }
        
        header h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        header .subtitle {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .summary-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid var(--border);
        }
        
        .summary-card h3 {
            font-size: 0.875rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }
        
        .summary-card .value {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .score-card {
            text-align: center;
        }
        
        .score-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
        }
        
        .score-critical { background: linear-gradient(135deg, var(--critical), #991b1b); }
        .score-high { background: linear-gradient(135deg, var(--high), #c2410c); }
        .score-medium { background: linear-gradient(135deg, var(--medium), #a16207); }
        .score-good { background: linear-gradient(135deg, var(--success), #15803d); }
        
        .severity-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .severity-critical { background: #fef2f2; color: var(--critical); }
        .severity-high { background: #fff7ed; color: var(--high); }
        .severity-medium { background: #fefce8; color: var(--medium); }
        .severity-low { background: #eff6ff; color: var(--low); }
        .severity-info { background: #f9fafb; color: var(--info); }
        
        .findings-section {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid var(--border);
        }
        
        .findings-section h2 {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .finding-card {
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            transition: box-shadow 0.2s;
        }
        
        .finding-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .finding-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.75rem;
        }
        
        .finding-title {
            font-weight: 600;
            font-size: 1rem;
        }
        
        .finding-rule {
            font-family: monospace;
            font-size: 0.875rem;
            color: var(--text-muted);
        }
        
        .finding-location {
            font-family: monospace;
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
        }
        
        .finding-message {
            color: var(--text);
            margin-bottom: 0.75rem;
        }
        
        .finding-remediation {
            background: #f0fdf4;
            border-left: 3px solid var(--success);
            padding: 0.75rem;
            border-radius: 0 4px 4px 0;
            font-size: 0.875rem;
        }
        
        .finding-remediation strong {
            color: var(--success);
        }
        
        .code-snippet {
            background: #1e293b;
            color: #e2e8f0;
            padding: 0.75rem;
            border-radius: 4px;
            font-family: 'Fira Code', 'Consolas', monospace;
            font-size: 0.875rem;
            overflow-x: auto;
            margin-bottom: 0.75rem;
        }
        
        .ai-badge {
            background: linear-gradient(135deg, #8b5cf6, #6366f1);
            color: white;
            padding: 0.125rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            margin-left: 0.5rem;
        }
        
        .ai-confidence {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        footer {
            text-align: center;
            padding: 2rem;
            color: var(--text-muted);
            font-size: 0.875rem;
        }
        
        .no-findings {
            text-align: center;
            padding: 3rem;
            color: var(--success);
        }
        
        .no-findings svg {
            width: 64px;
            height: 64px;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .summary-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .finding-header {
                flex-direction: column;
                gap: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🛡️ MCP Security Report</h1>
            <p class="subtitle">Generated by mcp-guardian on {{ generated_at }}</p>
        </header>
        
        <div class="summary-grid">
            <div class="summary-card score-card">
                <h3>Security Score</h3>
                <div class="score-circle {{ score_class }}">{{ score }}</div>
                <div class="value">{{ risk_level }}</div>
            </div>
            
            <div class="summary-card">
                <h3>Total Findings</h3>
                <div class="value">{{ total_findings }}</div>
            </div>
            
            <div class="summary-card">
                <h3>Critical</h3>
                <div class="value" style="color: var(--critical)">{{ critical_count }}</div>
            </div>
            
            <div class="summary-card">
                <h3>High</h3>
                <div class="value" style="color: var(--high)">{{ high_count }}</div>
            </div>
            
            <div class="summary-card">
                <h3>Medium</h3>
                <div class="value" style="color: var(--medium)">{{ medium_count }}</div>
            </div>
            
            <div class="summary-card">
                <h3>Files Scanned</h3>
                <div class="value">{{ files_scanned }}</div>
            </div>
        </div>
        
        {% if findings %}
        <div class="findings-section">
            <h2>🔍 Security Findings</h2>
            
            {% for finding in findings %}
            <div class="finding-card">
                <div class="finding-header">
                    <div>
                        <span class="severity-badge severity-{{ finding.severity.value }}">
                            {{ finding.severity.value }}
                        </span>
                        <span class="finding-rule">{{ finding.rule_id }}</span>
                        {% if finding.ai_confidence %}
                        <span class="ai-badge">AI</span>
                        <span class="ai-confidence">{{ (finding.ai_confidence * 100)|int }}% confidence</span>
                        {% endif %}
                    </div>
                </div>
                
                <div class="finding-title">{{ finding.title }}</div>
                <div class="finding-location">📍 {{ finding.location }}</div>
                
                {% if finding.location.snippet %}
                <div class="code-snippet">{{ finding.location.snippet }}</div>
                {% endif %}
                
                <div class="finding-message">{{ finding.message }}</div>
                
                <div class="finding-remediation">
                    <strong>✅ Remediation:</strong> {{ finding.remediation }}
                </div>
            </div>
            {% endfor %}
        </div>
        {% else %}
        <div class="findings-section">
            <div class="no-findings">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h2>No Security Issues Found!</h2>
                <p>Great job! Your MCP configuration and code passed all security checks.</p>
            </div>
        </div>
        {% endif %}
        
        <footer>
            <p>Generated by <strong>mcp-guardian</strong> v{{ version }}</p>
            <p>AI-powered security scanner for Model Context Protocol servers</p>
        </footer>
    </div>
</body>
</html>
"""


def generate_html_report(
    findings: list[Finding],
    title: str = "Security Scan",
    files_scanned: int = 0,
    version: str = "0.1.0",
) -> str:
    """Generate an HTML security report.

    Args:
        findings: List of security findings
        title: Report title
        files_scanned: Number of files scanned
        version: mcp-guardian version

    Returns:
        HTML report string
    """
    # Calculate metrics
    score = calculate_risk_score(findings)
    risk_level = get_risk_level(score)

    # Determine score class for styling
    if score >= 70:
        score_class = "score-good"
    elif score >= 50:
        score_class = "score-medium"
    elif score >= 30:
        score_class = "score-high"
    else:
        score_class = "score-critical"

    # Count by severity
    severity_counts = dict.fromkeys(Severity, 0)
    for finding in findings:
        severity_counts[finding.severity] += 1

    # Sort findings by severity
    severity_order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
    sorted_findings = sorted(findings, key=lambda f: severity_order.index(f.severity))

    # Render template
    template = Template(HTML_TEMPLATE)
    html: str = template.render(
        title=title,
        generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        score=score,
        score_class=score_class,
        risk_level=risk_level,
        total_findings=len(findings),
        critical_count=severity_counts[Severity.CRITICAL],
        high_count=severity_counts[Severity.HIGH],
        medium_count=severity_counts[Severity.MEDIUM],
        files_scanned=files_scanned,
        findings=sorted_findings,
        version=version,
    )

    return html


def save_html_report(
    findings: list[Finding],
    output_path: Path | str,
    title: str = "Security Scan",
    files_scanned: int = 0,
    version: str = "0.1.0",
) -> Path:
    """Generate and save an HTML security report.

    Args:
        findings: List of security findings
        output_path: Path to save the report
        title: Report title
        files_scanned: Number of files scanned
        version: mcp-guardian version

    Returns:
        Path to the saved report
    """
    output_path = Path(output_path)
    html = generate_html_report(findings, title, files_scanned, version)
    output_path.write_text(html)
    return output_path
