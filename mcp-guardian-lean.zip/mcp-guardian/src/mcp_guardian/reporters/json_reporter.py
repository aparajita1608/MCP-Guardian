"""JSON reporter for mcp-guardian."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from ..core.models import Finding, Severity
from ..core.scoring import calculate_risk_score, get_risk_level


def generate_json_report(
    findings: list[Finding],
    title: str = "Security Scan",
    files_scanned: int = 0,
    include_metadata: bool = True,
) -> str:
    """Generate a JSON security report.

    Args:
        findings: List of security findings
        title: Report title
        files_scanned: Number of files scanned
        include_metadata: Whether to include scan metadata

    Returns:
        JSON report string
    """
    # Calculate metrics
    score = calculate_risk_score(findings)
    risk_level = get_risk_level(score)

    # Count by severity
    severity_counts = {s.value: 0 for s in Severity}
    for finding in findings:
        severity_counts[finding.severity.value] += 1

    report: dict[str, Any] = {}

    if include_metadata:
        report["metadata"] = {
            "title": title,
            "generated_at": datetime.now().isoformat(),
            "tool": "mcp-guardian",
            "version": "0.1.0",
        }

        report["summary"] = {
            "score": score,
            "risk_level": risk_level,
            "total_findings": len(findings),
            "files_scanned": files_scanned,
            "by_severity": severity_counts,
        }

    report["findings"] = [f.model_dump(mode="json") for f in findings]

    return json.dumps(report, indent=2, default=str)


def save_json_report(
    findings: list[Finding],
    output_path: Path | str,
    title: str = "Security Scan",
    files_scanned: int = 0,
) -> Path:
    """Generate and save a JSON security report.

    Args:
        findings: List of security findings
        output_path: Path to save the report
        title: Report title
        files_scanned: Number of files scanned

    Returns:
        Path to the saved report
    """
    output_path = Path(output_path)
    json_content = generate_json_report(findings, title, files_scanned)
    output_path.write_text(json_content)
    return output_path
