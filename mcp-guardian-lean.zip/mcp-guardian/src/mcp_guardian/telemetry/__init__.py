"""Telemetry infrastructure for MCP Guardian.

Collects and reports:
- Detection events
- False positive reports
- Pattern performance metrics
- A/B test results
"""

import json
import os
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from ..core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class DetectionEvent:
    """A detection event for telemetry."""
    event_id: str
    timestamp: str
    pattern_id: str | None
    category: str
    severity: str
    confidence: float
    text_hash: str  # Hash of text, not the text itself (privacy)
    text_length: int
    ai_validated: bool
    ai_confidence: float | None
    is_false_positive: bool | None  # None = unknown, True/False = user reported
    session_id: str | None
    metadata: dict = field(default_factory=dict)


@dataclass
class FalsePositiveReport:
    """User-reported false positive."""
    report_id: str
    timestamp: str
    detection_event_id: str
    pattern_id: str
    category: str
    reason: str  # User-provided reason
    text_sample: str | None  # Optional, user can choose to share
    reporter_id: str | None  # Anonymous by default


@dataclass
class PatternMetrics:
    """Aggregated metrics for a pattern."""
    pattern_id: str
    total_detections: int
    confirmed_true_positives: int
    confirmed_false_positives: int
    unknown: int
    precision: float  # TP / (TP + FP)
    last_updated: str


class TelemetryCollector:
    """Collects telemetry data locally."""
    
    def __init__(
        self,
        data_dir: Path | str | None = None,
        session_id: str | None = None,
        enabled: bool = True,
    ):
        """Initialize telemetry collector.
        
        Args:
            data_dir: Directory to store telemetry data
            session_id: Session identifier
            enabled: Whether telemetry is enabled
        """
        self.enabled = enabled
        self.session_id = session_id or str(uuid.uuid4())[:8]
        
        if data_dir is None:
            data_dir = Path.home() / ".mcp-guardian" / "telemetry"
        
        self.data_dir = Path(data_dir)
        self.events_file = self.data_dir / "events.jsonl"
        self.reports_file = self.data_dir / "fp_reports.jsonl"
        self.metrics_file = self.data_dir / "pattern_metrics.json"
        
        if self.enabled:
            self.data_dir.mkdir(parents=True, exist_ok=True)
    
    def record_detection(
        self,
        pattern_id: str | None,
        category: str,
        severity: str,
        confidence: float,
        text: str,
        ai_validated: bool = False,
        ai_confidence: float | None = None,
        metadata: dict | None = None,
    ) -> str:
        """Record a detection event.
        
        Args:
            pattern_id: Pattern that triggered detection
            category: Threat category
            severity: Severity level
            confidence: Detection confidence
            text: Text that was analyzed (will be hashed)
            ai_validated: Whether AI validated the detection
            ai_confidence: AI confidence score
            metadata: Additional metadata
            
        Returns:
            Event ID
        """
        if not self.enabled:
            return ""
        
        event = DetectionEvent(
            event_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow().isoformat(),
            pattern_id=pattern_id,
            category=category,
            severity=severity,
            confidence=confidence,
            text_hash=self._hash_text(text),
            text_length=len(text),
            ai_validated=ai_validated,
            ai_confidence=ai_confidence,
            is_false_positive=None,
            session_id=self.session_id,
            metadata=metadata or {},
        )
        
        self._append_event(event)
        return event.event_id
    
    def report_false_positive(
        self,
        detection_event_id: str,
        pattern_id: str,
        category: str,
        reason: str,
        text_sample: str | None = None,
        reporter_id: str | None = None,
    ) -> str:
        """Report a false positive.
        
        Args:
            detection_event_id: ID of the detection event
            pattern_id: Pattern that caused the FP
            category: Threat category
            reason: User-provided reason
            text_sample: Optional text sample (user consent required)
            reporter_id: Optional reporter identifier
            
        Returns:
            Report ID
        """
        if not self.enabled:
            return ""
        
        report = FalsePositiveReport(
            report_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow().isoformat(),
            detection_event_id=detection_event_id,
            pattern_id=pattern_id,
            category=category,
            reason=reason,
            text_sample=text_sample,
            reporter_id=reporter_id,
        )
        
        self._append_report(report)
        self._update_event_fp_status(detection_event_id, True)
        
        logger.info(f"False positive reported: {pattern_id} - {reason}")
        return report.report_id
    
    def confirm_true_positive(self, detection_event_id: str):
        """Confirm a detection as a true positive."""
        if not self.enabled:
            return
        
        self._update_event_fp_status(detection_event_id, False)
    
    def get_pattern_metrics(self) -> dict[str, PatternMetrics]:
        """Calculate metrics for all patterns.
        
        Returns:
            Dictionary of pattern_id -> PatternMetrics
        """
        if not self.enabled or not self.events_file.exists():
            return {}
        
        # Aggregate events by pattern
        pattern_stats: dict[str, dict] = {}
        
        with open(self.events_file) as f:
            for line in f:
                event = json.loads(line)
                pattern_id = event.get("pattern_id")
                if not pattern_id:
                    continue
                
                if pattern_id not in pattern_stats:
                    pattern_stats[pattern_id] = {
                        "total": 0,
                        "tp": 0,
                        "fp": 0,
                        "unknown": 0,
                    }
                
                stats = pattern_stats[pattern_id]
                stats["total"] += 1
                
                is_fp = event.get("is_false_positive")
                if is_fp is True:
                    stats["fp"] += 1
                elif is_fp is False:
                    stats["tp"] += 1
                else:
                    stats["unknown"] += 1
        
        # Calculate metrics
        metrics = {}
        for pattern_id, stats in pattern_stats.items():
            tp = stats["tp"]
            fp = stats["fp"]
            precision = tp / (tp + fp) if (tp + fp) > 0 else 1.0
            
            metrics[pattern_id] = PatternMetrics(
                pattern_id=pattern_id,
                total_detections=stats["total"],
                confirmed_true_positives=tp,
                confirmed_false_positives=fp,
                unknown=stats["unknown"],
                precision=precision,
                last_updated=datetime.utcnow().isoformat(),
            )
        
        # Save metrics
        self._save_metrics(metrics)
        
        return metrics
    
    def get_fp_rate_by_category(self) -> dict[str, float]:
        """Get false positive rate by category.
        
        Returns:
            Dictionary of category -> FP rate
        """
        if not self.enabled or not self.events_file.exists():
            return {}
        
        category_stats: dict[str, dict] = {}
        
        with open(self.events_file) as f:
            for line in f:
                event = json.loads(line)
                category = event.get("category")
                if not category:
                    continue
                
                if category not in category_stats:
                    category_stats[category] = {"total": 0, "fp": 0}
                
                category_stats[category]["total"] += 1
                if event.get("is_false_positive") is True:
                    category_stats[category]["fp"] += 1
        
        return {
            cat: stats["fp"] / stats["total"] if stats["total"] > 0 else 0
            for cat, stats in category_stats.items()
        }
    
    def export_for_analysis(self, output_file: Path | str) -> int:
        """Export telemetry data for analysis.
        
        Args:
            output_file: Output file path
            
        Returns:
            Number of events exported
        """
        if not self.enabled or not self.events_file.exists():
            return 0
        
        events = []
        with open(self.events_file) as f:
            for line in f:
                events.append(json.loads(line))
        
        with open(output_file, 'w') as f:
            json.dump({
                "exported_at": datetime.utcnow().isoformat(),
                "total_events": len(events),
                "events": events,
            }, f, indent=2)
        
        return len(events)
    
    def _hash_text(self, text: str) -> str:
        """Hash text for privacy."""
        import hashlib
        return hashlib.sha256(text.encode()).hexdigest()[:16]
    
    def _append_event(self, event: DetectionEvent):
        """Append event to events file."""
        with open(self.events_file, 'a') as f:
            f.write(json.dumps(asdict(event)) + "\n")
    
    def _append_report(self, report: FalsePositiveReport):
        """Append report to reports file."""
        with open(self.reports_file, 'a') as f:
            f.write(json.dumps(asdict(report)) + "\n")
    
    def _update_event_fp_status(self, event_id: str, is_fp: bool):
        """Update an event's false positive status."""
        if not self.events_file.exists():
            return
        
        # Read all events
        events = []
        with open(self.events_file) as f:
            for line in f:
                events.append(json.loads(line))
        
        # Update the matching event
        for event in events:
            if event.get("event_id") == event_id:
                event["is_false_positive"] = is_fp
                break
        
        # Write back
        with open(self.events_file, 'w') as f:
            for event in events:
                f.write(json.dumps(event) + "\n")
    
    def _save_metrics(self, metrics: dict[str, PatternMetrics]):
        """Save metrics to file."""
        with open(self.metrics_file, 'w') as f:
            json.dump({
                pattern_id: asdict(m)
                for pattern_id, m in metrics.items()
            }, f, indent=2)


class TelemetryReporter:
    """Reports telemetry to external service (optional)."""
    
    def __init__(
        self,
        endpoint: str | None = None,
        api_key: str | None = None,
        batch_size: int = 100,
        enabled: bool = False,
    ):
        """Initialize telemetry reporter.
        
        Args:
            endpoint: Telemetry endpoint URL
            api_key: API key for authentication
            batch_size: Number of events to batch before sending
            enabled: Whether remote reporting is enabled
        """
        self.endpoint = endpoint or os.environ.get("MCP_GUARDIAN_TELEMETRY_ENDPOINT")
        self.api_key = api_key or os.environ.get("MCP_GUARDIAN_TELEMETRY_KEY")
        self.batch_size = batch_size
        self.enabled = enabled and self.endpoint is not None
        
        self._batch: list[dict] = []
    
    def report(self, event: dict):
        """Add event to batch and send if batch is full."""
        if not self.enabled:
            return
        
        self._batch.append(event)
        
        if len(self._batch) >= self.batch_size:
            self.flush()
    
    def flush(self):
        """Send batched events to endpoint."""
        if not self.enabled or not self._batch:
            return
        
        try:
            import urllib.request
            
            data = json.dumps({
                "events": self._batch,
                "timestamp": datetime.utcnow().isoformat(),
            }).encode()
            
            req = urllib.request.Request(
                self.endpoint,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}" if self.api_key else "",
                },
            )
            
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    logger.debug(f"Sent {len(self._batch)} telemetry events")
                    self._batch.clear()
                else:
                    logger.warning(f"Telemetry send failed: {resp.status}")
                    
        except Exception as e:
            logger.error(f"Telemetry send error: {e}")
