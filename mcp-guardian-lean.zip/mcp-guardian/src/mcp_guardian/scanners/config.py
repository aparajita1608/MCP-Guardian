"""Configuration file scanner for MCP client configurations.

Scans Claude Desktop, Cursor, and VS Code MCP configurations
for security issues like insecure transports, missing auth,
and dangerous startup commands.
"""

import json
import os
import re
from pathlib import Path
from typing import Any

from ..core.constants import MAX_CONFIG_SIZE_BYTES
from ..core.logging import get_logger
from ..core.models import (
    Category,
    Finding,
    Location,
    MCPClientConfig,
    MCPServerConfig,
    Rule,
    ScanTarget,
    Severity,
)
from .base import BaseScanner

logger = get_logger(__name__)


class ConfigScanner(BaseScanner):
    """Scanner for MCP client configuration files."""

    @property
    def scanner_type(self) -> str:
        return "config"

    def get_default_rules(self) -> list[Rule]:
        """Return default configuration security rules."""
        return [
            Rule(
                id="MCP-CFG-001",
                name="Network Exposure",
                description="Server bound to 0.0.0.0 exposes it to the network",
                severity=Severity.HIGH,
                category=Category.CONFIGURATION,
                cwe_id="CWE-668",
                patterns=[r"0\.0\.0\.0", r"bind.*0\.0\.0\.0"],
            ),
            Rule(
                id="MCP-CFG-002",
                name="Missing TLS",
                description="HTTP transport without TLS exposes data in transit",
                severity=Severity.HIGH,
                category=Category.CONFIGURATION,
                cwe_id="CWE-319",
                patterns=[r"http://(?!localhost|127\.0\.0\.1)"],
            ),
            Rule(
                id="MCP-CFG-003",
                name="No Authentication",
                description="Server configured without authentication",
                severity=Severity.MEDIUM,
                category=Category.AUTHENTICATION,
                cwe_id="CWE-306",
            ),
            Rule(
                id="MCP-CFG-004",
                name="Dangerous Startup Command",
                description="Startup command contains shell injection risk",
                severity=Severity.CRITICAL,
                category=Category.COMMAND_INJECTION,
                cwe_id="CWE-78",
                patterns=[
                    # Fixed: Use non-greedy quantifiers to prevent ReDoS
                    r"\$\{[^}]*\}",  # Variable expansion
                    r"\$\([^)]*\)",  # Command substitution
                    r"`[^`]*`",  # Backtick command substitution
                    r";\s*\w+",  # Command chaining
                    r"\|\s*\w+",  # Pipe to another command
                    r"&&\s*\w+",  # AND chaining
                    r"\|\|\s*\w+",  # OR chaining
                ],
            ),
            Rule(
                id="MCP-CFG-005",
                name="Unpinned Version",
                description="Using @latest or unpinned version is a supply chain risk",
                severity=Severity.MEDIUM,
                category=Category.CONFIGURATION,
                cwe_id="CWE-1104",
                patterns=[r"@latest", r"@\*", r"@>=", r"@>"],
            ),
            Rule(
                id="MCP-CFG-006",
                name="Secrets in Environment",
                description="Potential secrets exposed in environment variables",
                severity=Severity.HIGH,
                category=Category.SECRETS_EXPOSURE,
                cwe_id="CWE-798",
                patterns=[
                    r"(?i)(api[_-]?key|apikey)\s*[:=]",
                    r"(?i)(secret|password|token|credential)\s*[:=]",
                    r"sk-[a-zA-Z0-9]{20,}",  # OpenAI-style keys
                    r"ghp_[a-zA-Z0-9]{36}",  # GitHub tokens
                    r"AKIA[0-9A-Z]{16}",  # AWS access keys
                ],
            ),
            Rule(
                id="MCP-CFG-007",
                name="Privileged Command",
                description="Server runs with elevated privileges (sudo/admin)",
                severity=Severity.HIGH,
                category=Category.AUTHORIZATION,
                cwe_id="CWE-250",
                patterns=[r"\bsudo\b", r"\bdoas\b", r"--privileged"],
            ),
            # OAuth 2.1 / PKCE Compliance Rules (June 2025 MCP Spec Revision)
            Rule(
                id="MCP-CFG-008",
                name="OAuth 2.1 Non-Compliance",
                description="MCP server not configured for OAuth 2.1 (June 2025 spec requirement)",
                severity=Severity.HIGH,
                category=Category.AUTHENTICATION,
                cwe_id="CWE-287",
            ),
            Rule(
                id="MCP-CFG-009",
                name="Missing PKCE",
                description="OAuth configuration missing PKCE (Proof Key for Code Exchange) requirement",
                severity=Severity.HIGH,
                category=Category.AUTHENTICATION,
                cwe_id="CWE-287",
            ),
            Rule(
                id="MCP-CFG-010",
                name="Insecure Redirect URI",
                description="OAuth redirect URI uses wildcards or insecure patterns",
                severity=Severity.CRITICAL,
                category=Category.AUTHENTICATION,
                cwe_id="CWE-601",
                patterns=[r"\*", r"http://(?!localhost|127\.0\.0\.1)"],
            ),
            Rule(
                id="MCP-CFG-011",
                name="Confused Deputy Risk",
                description="OAuth configuration missing audience validation (confused deputy attack)",
                severity=Severity.HIGH,
                category=Category.AUTHORIZATION,
                cwe_id="CWE-441",
            ),
        ]

    def scan(self, target: ScanTarget) -> list[Finding]:
        """Scan an MCP configuration file.

        Args:
            target: Scan target containing path to config file

        Returns:
            List of security findings
        """
        findings: list[Finding] = []
        config_path = target.path

        if not config_path.exists():
            return findings

        # Detect config type and parse
        config = self._parse_config(config_path)
        if not config:
            return findings

        # Run all enabled rules
        for rule in self._enabled_rules:
            rule_findings = self._check_rule(rule, config, config_path)
            findings.extend(rule_findings)

        return findings

    def _parse_config(self, config_path: Path) -> MCPClientConfig | None:
        """Parse an MCP client configuration file.

        Args:
            config_path: Path to the configuration file

        Returns:
            Parsed configuration or None if parsing fails
        """
        # Check file size
        try:
            file_size = config_path.stat().st_size
            if file_size > MAX_CONFIG_SIZE_BYTES:
                logger.warning(
                    "config_skipped_too_large",
                    file=str(config_path),
                    size_bytes=file_size,
                    max_bytes=MAX_CONFIG_SIZE_BYTES,
                )
                return None
        except OSError as e:
            logger.error("config_stat_failed", file=str(config_path), error=str(e))
            return None

        try:
            with open(config_path) as f:
                raw_config = json.load(f)
            logger.debug("config_parsed", file=str(config_path))
        except json.JSONDecodeError as e:
            logger.warning("config_invalid_json", file=str(config_path), error=str(e))
            return None
        except OSError as e:
            logger.error("config_read_failed", file=str(config_path), error=str(e))
            return None

        # Detect config type
        config_type = self._detect_config_type(config_path, raw_config)

        # Parse servers based on config type
        servers = self._parse_servers(raw_config, config_type)

        return MCPClientConfig(
            config_type=config_type,
            config_path=config_path,
            servers=servers,
            raw_config=raw_config,
        )

    def _detect_config_type(self, config_path: Path, raw_config: dict[str, Any]) -> str:
        """Detect the type of MCP client configuration.

        Args:
            config_path: Path to the config file
            raw_config: Parsed JSON config

        Returns:
            Config type string
        """
        path_str = str(config_path).lower()

        if "claude" in path_str:
            return "claude_desktop"
        elif "cursor" in path_str:
            return "cursor"
        elif ".vscode" in path_str or "settings.json" in path_str:
            return "vscode"
        elif "mcpServers" in raw_config:
            return "claude_desktop"  # Claude Desktop format
        elif "mcp" in raw_config and "servers" in raw_config.get("mcp", {}):
            return "cursor"  # Cursor format

        return "unknown"

    def _parse_servers(self, raw_config: dict[str, Any], config_type: str) -> list[MCPServerConfig]:
        """Parse server configurations from raw config.

        Args:
            raw_config: Parsed JSON config
            config_type: Type of config file

        Returns:
            List of parsed server configurations
        """
        servers: list[MCPServerConfig] = []

        # Claude Desktop format: { "mcpServers": { "name": { ... } } }
        if config_type == "claude_desktop" and "mcpServers" in raw_config:
            for name, server_config in raw_config["mcpServers"].items():
                servers.append(self._parse_server_entry(name, server_config))

        # Cursor format: { "mcp": { "servers": { "name": { ... } } } }
        elif config_type == "cursor":
            mcp_config = raw_config.get("mcp", {})
            for name, server_config in mcp_config.get("servers", {}).items():
                servers.append(self._parse_server_entry(name, server_config))

        # VS Code format: { "mcp.servers": { "name": { ... } } }
        elif config_type == "vscode":
            for key, value in raw_config.items():
                if key.startswith("mcp.") and isinstance(value, dict):
                    for name, server_config in value.items():
                        servers.append(self._parse_server_entry(name, server_config))

        return servers

    def _parse_server_entry(self, name: str, config: dict[str, Any]) -> MCPServerConfig:
        """Parse a single server configuration entry.

        Args:
            name: Server name
            config: Server configuration dict

        Returns:
            Parsed server configuration
        """
        return MCPServerConfig(
            name=name,
            command=config.get("command"),
            args=config.get("args", []),
            env=config.get("env", {}),
            transport=config.get("transport", "stdio"),
            url=config.get("url"),
            auth_type=config.get("auth", {}).get("type") if isinstance(config.get("auth"), dict) else None,
            tls_enabled=config.get("tls", {}).get("enabled") if isinstance(config.get("tls"), dict) else None,
            bind_address=config.get("host") or config.get("bind"),
        )

    # Registry pattern for rule handlers
    _RULE_HANDLERS: dict[str, str] = {
        "MCP-CFG-001": "_check_network_exposure",
        "MCP-CFG-002": "_check_missing_tls",
        "MCP-CFG-003": "_check_no_auth",
        "MCP-CFG-004": "_check_dangerous_command",
        "MCP-CFG-005": "_check_unpinned_version",
        "MCP-CFG-006": "_check_secrets_in_env",
        "MCP-CFG-007": "_check_privileged_command",
        "MCP-CFG-008": "_check_oauth_compliance",
        "MCP-CFG-009": "_check_pkce_requirement",
        "MCP-CFG-010": "_check_redirect_uri",
        "MCP-CFG-011": "_check_confused_deputy",
    }

    def _check_rule(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check a single rule against the configuration.

        Args:
            rule: Rule to check
            config: Parsed configuration
            config_path: Path to config file

        Returns:
            List of findings for this rule
        """
        handler_name = self._RULE_HANDLERS.get(rule.id)
        if handler_name:
            handler = getattr(self, handler_name, None)
            if handler and callable(handler):
                result = handler(rule, config, config_path)
                return result if isinstance(result, list) else []
            logger.warning("rule_handler_not_found", rule_id=rule.id, handler=handler_name)
        return []

    def _check_network_exposure(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for servers bound to 0.0.0.0."""
        findings: list[Finding] = []

        for server in config.servers:
            if server.bind_address == "0.0.0.0":
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' exposed to network",
                        message=f"Server '{server.name}' is bound to 0.0.0.0, exposing it to all network interfaces. "
                        "This allows remote connections which may not be intended.",
                        location=Location(file=config_path, snippet='"host": "0.0.0.0"'),
                        remediation="Bind to 127.0.0.1 (localhost) unless remote access is explicitly required. "
                        "If remote access is needed, ensure proper authentication and TLS are configured.",
                        cwe_id=rule.cwe_id,
                    )
                )

        return findings

    def _check_missing_tls(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for HTTP transport without TLS."""
        findings: list[Finding] = []

        for server in config.servers:
            if server.url and server.url.startswith("http://"):
                # Allow localhost without TLS
                if "localhost" in server.url or "127.0.0.1" in server.url:
                    continue

                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' uses unencrypted HTTP",
                        message=f"Server '{server.name}' connects via HTTP without TLS. "
                        "Data transmitted to/from this server can be intercepted.",
                        location=Location(file=config_path, snippet=f'"url": "{server.url}"'),
                        remediation="Use HTTPS instead of HTTP. Configure TLS certificates on the server.",
                        cwe_id=rule.cwe_id,
                    )
                )

            # Check explicit TLS disabled
            if server.tls_enabled is False and server.transport in ("sse", "http"):
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' has TLS explicitly disabled",
                        message=f"Server '{server.name}' has TLS explicitly disabled in configuration.",
                        location=Location(file=config_path, snippet='"tls": { "enabled": false }'),
                        remediation="Enable TLS for production deployments.",
                        cwe_id=rule.cwe_id,
                    )
                )

        return findings

    def _check_no_auth(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for servers without authentication."""
        findings: list[Finding] = []

        for server in config.servers:
            # Only check HTTP-based transports
            if server.transport not in ("sse", "http"):
                continue

            if not server.auth_type:
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' has no authentication",
                        message=f"Server '{server.name}' uses HTTP transport without authentication configured. "
                        "Anyone who can reach the server can use it.",
                        location=Location(file=config_path),
                        remediation="Configure authentication using OAuth 2.1, API keys, or bearer tokens.",
                        cwe_id=rule.cwe_id,
                    )
                )

        return findings

    def _check_dangerous_command(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for shell injection risks in startup commands."""
        findings: list[Finding] = []

        for server in config.servers:
            # Check command
            if server.command:
                for pattern in rule.patterns:
                    if re.search(pattern, server.command):
                        findings.append(
                            Finding(
                                rule_id=rule.id,
                                severity=rule.severity,
                                category=rule.category,
                                title=f"Server '{server.name}' has dangerous startup command",
                                message=f"Server '{server.name}' command contains shell metacharacters "
                                f"that could allow command injection: {server.command}",
                                location=Location(file=config_path, snippet=f'"command": "{server.command}"'),
                                remediation="Avoid shell metacharacters in commands. Use explicit argument arrays "
                                "instead of shell expansion. Validate any dynamic values.",
                                cwe_id=rule.cwe_id,
                            )
                        )
                        break

            # Check args
            for arg in server.args:
                for pattern in rule.patterns:
                    if re.search(pattern, str(arg)):
                        findings.append(
                            Finding(
                                rule_id=rule.id,
                                severity=rule.severity,
                                category=rule.category,
                                title=f"Server '{server.name}' has dangerous argument",
                                message=f"Server '{server.name}' argument contains shell metacharacters: {arg}",
                                location=Location(file=config_path, snippet=f'"args": [..., "{arg}", ...]'),
                                remediation="Avoid shell metacharacters in arguments. Validate any dynamic values.",
                                cwe_id=rule.cwe_id,
                            )
                        )
                        break

        return findings

    def _check_unpinned_version(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for unpinned package versions."""
        findings: list[Finding] = []

        for server in config.servers:
            # Check command for npx/npm with @latest
            cmd_str = f"{server.command or ''} {' '.join(server.args)}"
            for pattern in rule.patterns:
                match = re.search(pattern, cmd_str)
                if match:
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            category=rule.category,
                            title=f"Server '{server.name}' uses unpinned version",
                            message=f"Server '{server.name}' uses an unpinned package version ({match.group()}). "
                            "This is a supply chain risk as the package could be updated with malicious code.",
                            location=Location(file=config_path, snippet=cmd_str.strip()),
                            remediation="Pin to a specific version (e.g., @1.2.3) instead of @latest or version ranges.",
                            cwe_id=rule.cwe_id,
                        )
                    )
                    break

        return findings

    def _check_secrets_in_env(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for secrets in environment variables."""
        findings: list[Finding] = []

        for server in config.servers:
            for key, value in server.env.items():
                # Check key names
                for pattern in rule.patterns[:2]:  # First two patterns are for key names
                    if re.search(pattern, key, re.IGNORECASE):
                        # Only flag if value looks like a real secret (not a reference)
                        if not value.startswith("$") and not value.startswith("%"):
                            findings.append(
                                Finding(
                                    rule_id=rule.id,
                                    severity=rule.severity,
                                    category=rule.category,
                                    title=f"Server '{server.name}' has hardcoded secret",
                                    message=f"Server '{server.name}' has a potential secret in environment variable '{key}'. "
                                    "Hardcoded secrets in configuration files can be exposed.",
                                    location=Location(file=config_path, snippet=f'"{key}": "***"'),
                                    remediation="Use environment variable references ($VAR) or a secrets manager "
                                    "instead of hardcoding secrets in configuration files.",
                                    cwe_id=rule.cwe_id,
                                )
                            )
                            break

                # Check value patterns (API keys, tokens)
                for pattern in rule.patterns[2:]:
                    if re.search(pattern, value):
                        findings.append(
                            Finding(
                                rule_id=rule.id,
                                severity=rule.severity,
                                category=rule.category,
                                title=f"Server '{server.name}' has exposed API key",
                                message=f"Server '{server.name}' has what appears to be an API key or token "
                                f"in environment variable '{key}'.",
                                location=Location(file=config_path, snippet=f'"{key}": "***"'),
                                remediation="Remove the secret from the configuration file. Use environment "
                                "variable references or a secrets manager.",
                                cwe_id=rule.cwe_id,
                            )
                        )
                        break

        return findings

    def _check_privileged_command(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for commands running with elevated privileges."""
        findings: list[Finding] = []

        for server in config.servers:
            cmd_str = f"{server.command or ''} {' '.join(server.args)}"
            for pattern in rule.patterns:
                if re.search(pattern, cmd_str):
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            category=rule.category,
                            title=f"Server '{server.name}' runs with elevated privileges",
                            message=f"Server '{server.name}' command uses sudo or elevated privileges. "
                            "MCP servers should run with minimal required permissions.",
                            location=Location(file=config_path, snippet=cmd_str.strip()),
                            remediation="Remove sudo/elevated privileges. Configure the server to run "
                            "with the minimum required permissions.",
                            cwe_id=rule.cwe_id,
                        )
                    )
                    break

        return findings

    def _check_oauth_compliance(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for OAuth 2.1 compliance (June 2025 MCP spec requirement).
        
        Per the June 2025 MCP specification revision, MCP servers must act solely
        as OAuth Resource Servers with OAuth 2.1 compliance.
        """
        findings: list[Finding] = []

        for server in config.servers:
            # Only check HTTP-based transports that use OAuth
            if server.transport not in ("sse", "http"):
                continue

            auth_config = config.raw_config.get("mcpServers", {}).get(server.name, {}).get("auth", {})
            
            if not auth_config:
                continue  # No auth configured - handled by MCP-CFG-003
            
            auth_type = auth_config.get("type", "").lower()
            
            # Check if using OAuth
            if auth_type in ("oauth", "oauth2", "oauth2.0"):
                # OAuth 2.0 is deprecated - must use OAuth 2.1
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' uses legacy OAuth 2.0",
                        message=f"Server '{server.name}' is configured with OAuth 2.0. "
                        "Per the June 2025 MCP specification, OAuth 2.1 is required. "
                        "OAuth 2.1 includes mandatory PKCE and stricter redirect URI validation.",
                        location=Location(file=config_path, snippet=f'"auth": {{ "type": "{auth_type}" }}'),
                        remediation="Upgrade to OAuth 2.1 configuration. Ensure PKCE is enabled "
                        "and redirect URIs use exact matching (no wildcards).",
                        cwe_id=rule.cwe_id,
                        references=["https://oauth.net/2.1/", "https://modelcontextprotocol.io/docs/security"],
                    )
                )

        return findings

    def _check_pkce_requirement(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for PKCE (Proof Key for Code Exchange) requirement.
        
        PKCE is mandatory in OAuth 2.1 and required by the June 2025 MCP spec.
        """
        findings: list[Finding] = []

        for server in config.servers:
            if server.transport not in ("sse", "http"):
                continue

            auth_config = config.raw_config.get("mcpServers", {}).get(server.name, {}).get("auth", {})
            
            if not auth_config:
                continue
            
            auth_type = auth_config.get("type", "").lower()
            
            if "oauth" in auth_type:
                pkce_config = auth_config.get("pkce", {})
                pkce_enabled = pkce_config.get("enabled", False) if isinstance(pkce_config, dict) else pkce_config
                
                if not pkce_enabled:
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            category=rule.category,
                            title=f"Server '{server.name}' missing PKCE requirement",
                            message=f"Server '{server.name}' OAuth configuration does not enforce PKCE. "
                            "PKCE (Proof Key for Code Exchange) is mandatory in OAuth 2.1 and "
                            "prevents authorization code interception attacks.",
                            location=Location(file=config_path, snippet='"pkce": { "enabled": false }'),
                            remediation="Enable PKCE in OAuth configuration: "
                            '"pkce": { "enabled": true, "method": "S256" }. '
                            "Use S256 (SHA-256) method, not plain.",
                            cwe_id=rule.cwe_id,
                        )
                    )
                else:
                    # Check PKCE method - S256 is required, plain is insecure
                    pkce_method = pkce_config.get("method", "").upper() if isinstance(pkce_config, dict) else ""
                    if pkce_method == "PLAIN":
                        findings.append(
                            Finding(
                                rule_id=rule.id,
                                severity=Severity.MEDIUM,
                                category=rule.category,
                                title=f"Server '{server.name}' uses weak PKCE method",
                                message=f"Server '{server.name}' uses 'plain' PKCE method which provides "
                                "minimal security. S256 (SHA-256) is required for proper protection.",
                                location=Location(file=config_path, snippet='"method": "plain"'),
                                remediation='Change PKCE method to S256: "method": "S256"',
                                cwe_id=rule.cwe_id,
                            )
                        )

        return findings

    def _check_redirect_uri(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for insecure OAuth redirect URI patterns.
        
        OAuth 2.1 requires exact redirect URI matching - no wildcards allowed.
        """
        findings: list[Finding] = []

        for server in config.servers:
            if server.transport not in ("sse", "http"):
                continue

            auth_config = config.raw_config.get("mcpServers", {}).get(server.name, {}).get("auth", {})
            
            if not auth_config or "oauth" not in auth_config.get("type", "").lower():
                continue
            
            redirect_uris = auth_config.get("redirectUris", auth_config.get("redirect_uris", []))
            if isinstance(redirect_uris, str):
                redirect_uris = [redirect_uris]
            
            for uri in redirect_uris:
                # Check for wildcards
                if "*" in uri:
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            category=rule.category,
                            title=f"Server '{server.name}' has wildcard redirect URI",
                            message=f"Server '{server.name}' OAuth redirect URI contains wildcard: '{uri}'. "
                            "OAuth 2.1 requires exact redirect URI matching. Wildcards enable "
                            "open redirect attacks and token theft.",
                            location=Location(file=config_path, snippet=f'"redirectUris": ["{uri}"]'),
                            remediation="Use exact redirect URIs without wildcards. "
                            "Example: 'https://app.example.com/oauth/callback'",
                            cwe_id=rule.cwe_id,
                        )
                    )
                
                # Check for HTTP (non-localhost)
                if uri.startswith("http://") and "localhost" not in uri and "127.0.0.1" not in uri:
                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=Severity.HIGH,
                            category=rule.category,
                            title=f"Server '{server.name}' has insecure redirect URI",
                            message=f"Server '{server.name}' OAuth redirect URI uses HTTP: '{uri}'. "
                            "Non-localhost redirect URIs must use HTTPS to prevent token interception.",
                            location=Location(file=config_path, snippet=f'"redirectUris": ["{uri}"]'),
                            remediation="Use HTTPS for all non-localhost redirect URIs.",
                            cwe_id="CWE-319",
                        )
                    )

        return findings

    def _check_confused_deputy(self, rule: Rule, config: MCPClientConfig, config_path: Path) -> list[Finding]:
        """Check for confused deputy attack vulnerabilities.
        
        MCP servers must validate token audience to prevent one server from
        using a user's token to access another server.
        """
        findings: list[Finding] = []

        for server in config.servers:
            if server.transport not in ("sse", "http"):
                continue

            auth_config = config.raw_config.get("mcpServers", {}).get(server.name, {}).get("auth", {})
            
            if not auth_config or "oauth" not in auth_config.get("type", "").lower():
                continue
            
            # Check for audience validation
            audience = auth_config.get("audience", auth_config.get("aud"))
            validate_audience = auth_config.get("validateAudience", auth_config.get("validate_audience", True))
            
            if not audience:
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=rule.severity,
                        category=rule.category,
                        title=f"Server '{server.name}' missing OAuth audience",
                        message=f"Server '{server.name}' OAuth configuration does not specify an audience. "
                        "Without audience validation, tokens issued for one MCP server could be "
                        "replayed to access another server (confused deputy attack).",
                        location=Location(file=config_path),
                        remediation='Add audience claim to OAuth config: "audience": "https://your-server.com". '
                        "Ensure the authorization server includes this audience in issued tokens.",
                        cwe_id=rule.cwe_id,
                    )
                )
            
            if validate_audience is False:
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=Severity.CRITICAL,
                        category=rule.category,
                        title=f"Server '{server.name}' has audience validation disabled",
                        message=f"Server '{server.name}' has explicitly disabled OAuth audience validation. "
                        "This allows tokens from any MCP server to be used, enabling confused deputy attacks.",
                        location=Location(file=config_path, snippet='"validateAudience": false'),
                        remediation="Enable audience validation: remove 'validateAudience: false' or set to true.",
                        cwe_id=rule.cwe_id,
                    )
                )
            
            # Check for token binding (advanced protection)
            token_binding = auth_config.get("tokenBinding", auth_config.get("token_binding"))
            scope_validation = auth_config.get("validateScope", auth_config.get("validate_scope", True))
            
            if not token_binding and scope_validation is False:
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        severity=Severity.MEDIUM,
                        category=rule.category,
                        title=f"Server '{server.name}' has weak token validation",
                        message=f"Server '{server.name}' lacks token binding and has scope validation disabled. "
                        "Consider enabling additional token validation for defense in depth.",
                        location=Location(file=config_path),
                        remediation="Enable scope validation and consider implementing token binding "
                        "for additional protection against token replay attacks.",
                        cwe_id=rule.cwe_id,
                    )
                )

        return findings


def get_default_config_paths() -> list[Path]:
    """Get default paths for MCP client configurations.

    Returns:
        List of paths to check for MCP configurations
    """
    paths: list[Path] = []
    home = Path.home()

    # Claude Desktop
    if os.name == "nt":  # Windows
        paths.append(home / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json")
    else:  # macOS/Linux
        paths.append(home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json")
        paths.append(home / ".config" / "claude" / "claude_desktop_config.json")

    # Cursor
    paths.append(home / ".cursor" / "mcp.json")
    paths.append(home / ".cursorrc")

    # VS Code
    paths.append(home / ".vscode" / "settings.json")
    if os.name == "nt":
        paths.append(home / "AppData" / "Roaming" / "Code" / "User" / "settings.json")
    else:
        paths.append(home / "Library" / "Application Support" / "Code" / "User" / "settings.json")
        paths.append(home / ".config" / "Code" / "User" / "settings.json")

    return [p for p in paths if p.exists()]
