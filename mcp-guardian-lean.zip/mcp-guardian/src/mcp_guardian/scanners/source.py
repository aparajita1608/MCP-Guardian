"""Source code scanner for MCP server implementations.

Scans Python, TypeScript, and JavaScript source code for security
vulnerabilities like command injection, secrets exposure, and SSRF.
"""

import re
from pathlib import Path

from ..core.constants import MAX_FILE_SIZE_BYTES
from ..core.logging import get_logger
from ..core.models import (
    Category,
    Finding,
    Location,
    Rule,
    ScanTarget,
    Severity,
)
from .base import BaseScanner

logger = get_logger(__name__)


class SourceScanner(BaseScanner):
    """Scanner for MCP server source code."""

    @property
    def scanner_type(self) -> str:
        return "source"

    def get_default_rules(self) -> list[Rule]:
        """Return default source code security rules."""
        return [
            Rule(
                id="MCP-SRC-001",
                name="Command Injection",
                description="Unsanitized input passed to shell execution functions",
                severity=Severity.CRITICAL,
                category=Category.COMMAND_INJECTION,
                cwe_id="CWE-78",
                patterns=[
                    # Python patterns
                    r"subprocess\.(run|call|Popen|check_output|check_call)\s*\([^)]*shell\s*=\s*True",
                    r"os\.system\s*\(",
                    r"os\.popen\s*\(",
                    r"commands\.(getoutput|getstatusoutput)\s*\(",
                    # JavaScript/TypeScript patterns
                    r"child_process\.(exec|execSync|spawn|spawnSync)\s*\(",
                    r"exec\s*\(\s*[`'\"].*\$\{",  # Template literal with variable
                    r"execSync\s*\(\s*[`'\"].*\$\{",
                ],
            ),
            Rule(
                id="MCP-SRC-002",
                name="Path Traversal",
                description="User input used in file path without validation",
                severity=Severity.HIGH,
                category=Category.PATH_TRAVERSAL,
                cwe_id="CWE-22",
                patterns=[
                    r"open\s*\([^)]*\+",  # String concatenation in open()
                    r"Path\s*\([^)]*\+",  # String concatenation in Path()
                    r"readFile\s*\([^)]*\+",
                    r"writeFile\s*\([^)]*\+",
                    r"fs\.(readFile|writeFile|readdir|stat)\s*\([^)]*\+",
                ],
            ),
            Rule(
                id="MCP-SRC-003",
                name="SQL Injection",
                description="User input concatenated into SQL queries",
                severity=Severity.CRITICAL,
                category=Category.SQL_INJECTION,
                cwe_id="CWE-89",
                patterns=[
                    r"execute\s*\(\s*[f'\"].*\{",  # f-string in execute
                    r"execute\s*\([^)]*\%",  # % formatting in execute
                    r"execute\s*\([^)]*\+",  # Concatenation in execute
                    r"cursor\.execute\s*\(\s*[f'\"]",
                    r"\.query\s*\(\s*[`'\"].*\$\{",  # JS template literal
                ],
            ),
            Rule(
                id="MCP-SRC-004",
                name="Hardcoded Secrets",
                description="Potential secrets hardcoded in source code",
                severity=Severity.HIGH,
                category=Category.SECRETS_EXPOSURE,
                cwe_id="CWE-798",
                patterns=[
                    r"(?i)(api[_-]?key|apikey)\s*=\s*['\"][^'\"]{10,}['\"]",
                    r"(?i)(secret|password|token|credential)\s*=\s*['\"][^'\"]{8,}['\"]",
                    r"sk-[a-zA-Z0-9]{20,}",  # OpenAI keys
                    r"sk-ant-[a-zA-Z0-9-_]{32,}",  # Anthropic keys
                    r"ghp_[a-zA-Z0-9]{36}",  # GitHub tokens
                    r"AKIA[0-9A-Z]{16}",  # AWS access keys
                    r"xox[baprs]-[a-zA-Z0-9-]{10,}",  # Slack tokens
                ],
            ),
            Rule(
                id="MCP-SRC-005",
                name="Unsafe Deserialization",
                description="Unsafe deserialization of untrusted data",
                severity=Severity.CRITICAL,
                category=Category.DESERIALIZATION,
                cwe_id="CWE-502",
                patterns=[
                    r"pickle\.loads?\s*\(",
                    r"yaml\.load\s*\([^)]*\)",  # yaml.load without Loader
                    r"yaml\.unsafe_load\s*\(",
                    r"marshal\.loads?\s*\(",
                    r"eval\s*\(",
                    r"exec\s*\(",
                ],
            ),
            Rule(
                id="MCP-SRC-006",
                name="SSRF Risk",
                description="User-controlled URLs in HTTP requests",
                severity=Severity.HIGH,
                category=Category.SSRF,
                cwe_id="CWE-918",
                patterns=[
                    r"requests\.(get|post|put|delete|patch)\s*\([^)]*\+",
                    r"httpx\.(get|post|put|delete|patch)\s*\([^)]*\+",
                    r"urllib\.request\.urlopen\s*\(",
                    r"fetch\s*\([^)]*\+",
                    r"axios\.(get|post|put|delete|patch)\s*\([^)]*\+",
                ],
            ),
            Rule(
                id="MCP-SRC-007",
                name="Debug Mode Enabled",
                description="Debug mode or verbose logging enabled in production code",
                severity=Severity.MEDIUM,
                category=Category.CONFIGURATION,
                cwe_id="CWE-489",
                patterns=[
                    r"debug\s*=\s*True",
                    r"DEBUG\s*=\s*True",
                    r"\.setLevel\s*\(\s*logging\.DEBUG\s*\)",
                ],
            ),
        ]

    def scan(self, target: ScanTarget) -> list[Finding]:
        """Scan source code for security vulnerabilities.

        Args:
            target: Scan target containing path to source file/directory

        Returns:
            List of security findings
        """
        findings: list[Finding] = []
        source_path = target.path

        if not source_path.exists():
            return findings

        if source_path.is_file():
            findings = self._scan_file(source_path)
        else:
            # Scan directory
            for pattern in ["**/*.py", "**/*.ts", "**/*.js"]:
                for file_path in source_path.glob(pattern):
                    if self._should_skip(file_path):
                        continue
                    findings.extend(self._scan_file(file_path))

        return findings

    def _should_skip(self, file_path: Path) -> bool:
        """Check if file should be skipped."""
        skip_patterns = [
            "/.git/",
            "/node_modules/",
            "/__pycache__/",
            "/.venv/",
            "/venv/",
            "/.tox/",
            "/dist/",
            "/build/",
            "/.egg-info/",
        ]
        path_str = str(file_path)
        return any(pattern in path_str for pattern in skip_patterns)

    def _scan_file(self, file_path: Path) -> list[Finding]:
        """Scan a single source file.

        Args:
            file_path: Path to the source file

        Returns:
            List of findings
        """
        findings: list[Finding] = []

        # Check file size to prevent memory exhaustion
        try:
            file_size = file_path.stat().st_size
            if file_size > MAX_FILE_SIZE_BYTES:
                logger.warning(
                    "file_skipped_too_large",
                    file=str(file_path),
                    size_bytes=file_size,
                    max_bytes=MAX_FILE_SIZE_BYTES,
                )
                return findings
        except OSError as e:
            logger.error("file_stat_failed", file=str(file_path), error=str(e))
            return findings

        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            logger.debug("file_scan_started", file=str(file_path), size_bytes=file_size)
        except OSError as e:
            logger.error("file_read_failed", file=str(file_path), error=str(e))
            return findings

        lines = content.split("\n")

        for rule in self._enabled_rules:
            for pattern in rule.patterns:
                for match in re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE):
                    # Find line number
                    line_num = content[: match.start()].count("\n") + 1
                    line_content = lines[line_num - 1] if line_num <= len(lines) else ""

                    # Skip if in comment
                    if self._is_in_comment(line_content, file_path.suffix):
                        continue

                    findings.append(
                        Finding(
                            rule_id=rule.id,
                            severity=rule.severity,
                            category=rule.category,
                            title=rule.name,
                            message=rule.description,
                            location=Location(
                                file=file_path,
                                line=line_num,
                                snippet=line_content.strip()[:100],
                            ),
                            remediation=self._get_remediation(rule.id),
                            cwe_id=rule.cwe_id,
                        )
                    )

        return findings

    def _is_in_comment(self, line: str, suffix: str) -> bool:
        """Check if the match is inside a comment."""
        line = line.strip()
        if suffix == ".py":
            return line.startswith("#")
        elif suffix in (".ts", ".js"):
            return line.startswith("//") or line.startswith("/*") or line.startswith("*")
        return False

    def _get_remediation(self, rule_id: str) -> str:
        """Get remediation advice for a rule."""
        remediations = {
            "MCP-SRC-001": (
                "Use subprocess with shell=False and pass arguments as a list. "
                "Example: subprocess.run(['git', 'log', '--oneline'], check=True)"
            ),
            "MCP-SRC-002": (
                "Validate and sanitize file paths. Use pathlib to resolve paths and check "
                "they don't escape the intended directory. Example: path.resolve().relative_to(base_dir)"
            ),
            "MCP-SRC-003": (
                "Use parameterized queries instead of string concatenation. "
                "Example: cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))"
            ),
            "MCP-SRC-004": (
                "Remove hardcoded secrets. Use environment variables or a secrets manager. "
                "Example: api_key = os.environ.get('API_KEY')"
            ),
            "MCP-SRC-005": (
                "Avoid deserializing untrusted data. For YAML, use yaml.safe_load(). "
                "Never use pickle, eval, or exec on untrusted input."
            ),
            "MCP-SRC-006": (
                "Validate and sanitize URLs before making requests. Use an allowlist of "
                "permitted domains. Block internal IP ranges (10.x, 172.16-31.x, 192.168.x, 127.x)."
            ),
            "MCP-SRC-007": (
                "Disable debug mode in production. Use environment variables to control "
                "debug settings: debug = os.environ.get('DEBUG', 'false').lower() == 'true'"
            ),
        }
        return remediations.get(rule_id, "Review and fix the identified security issue.")
