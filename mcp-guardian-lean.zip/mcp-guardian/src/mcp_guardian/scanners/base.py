"""Base scanner interface for mcp-guardian.

All scanners inherit from this abstract base class to ensure
consistent interface and behavior.
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path

from ..core.logging import get_logger
from ..core.models import Finding, Rule, ScanTarget

logger = get_logger(__name__)


class BaseScanner(ABC):
    """Abstract base class for all security scanners."""

    def __init__(
        self,
        rules: list[Rule] | None = None,
        file_reader: Callable[[Path], str] | None = None,
    ):
        """Initialize scanner with optional rules and dependencies.

        Args:
            rules: List of rules to apply (None = use defaults)
            file_reader: Custom file reader function for dependency injection
        """
        self.rules = rules or self.get_default_rules()
        self._enabled_rules = [r for r in self.rules if r.enabled]
        self._file_reader = file_reader or self._default_file_reader
        logger.debug(
            "scanner_initialized",
            scanner_type=self.scanner_type,
            rules_count=len(self.rules),
            enabled_count=len(self._enabled_rules),
        )

    @staticmethod
    def _default_file_reader(path: Path) -> str:
        """Default file reader implementation."""
        return path.read_text(encoding="utf-8", errors="ignore")

    @property
    @abstractmethod
    def scanner_type(self) -> str:
        """Return the type of scanner (e.g., 'config', 'source', 'manifest')."""
        ...

    @abstractmethod
    def get_default_rules(self) -> list[Rule]:
        """Return the default rules for this scanner."""
        ...

    @abstractmethod
    def scan(self, target: ScanTarget) -> list[Finding]:
        """Scan a target and return findings.

        Args:
            target: The target to scan

        Returns:
            List of security findings
        """
        ...

    def scan_file(self, file_path: Path) -> list[Finding]:
        """Convenience method to scan a single file.

        Args:
            file_path: Path to the file to scan

        Returns:
            List of security findings
        """
        target = ScanTarget(
            path=file_path,
            target_type=self.scanner_type,
        )
        return self.scan(target)

    def is_rule_enabled(self, rule_id: str) -> bool:
        """Check if a rule is enabled.

        Args:
            rule_id: The rule ID to check

        Returns:
            True if the rule is enabled
        """
        return any(r.id == rule_id and r.enabled for r in self.rules)

    def get_rule(self, rule_id: str) -> Rule | None:
        """Get a rule by ID.

        Args:
            rule_id: The rule ID to find

        Returns:
            The rule if found, None otherwise
        """
        for rule in self.rules:
            if rule.id == rule_id:
                return rule
        return None
