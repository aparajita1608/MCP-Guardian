# MCP Guardian Benchmarks

This folder contains all benchmark data, test cases, and results.

## Structure

```
benchmark/
├── owasp_mcp_top10.json      # OWASP MCP Top 10 test cases
├── mcpsec_benchmark.json     # MCPSEC benchmark test cases
├── cves/                     # CVE-based test cases
│   └── known_mcp/
│       └── expanded_cves.json
├── malicious/                # Real attack samples
│   ├── msb_tool_poisoning.json
│   └── cve_payloads.json
├── benign/                   # Benign samples (FP testing)
│   └── github_mcp_servers.json
├── cross-tool/               # Cross-tool attack scenarios
├── mutations/                # Mutation-based test cases
├── tool_shadowing/           # Tool shadowing test cases
├── competitor_results/       # Competitor comparison data
├── external_results/         # Results from external benchmarks
└── *.json                    # Result files
```

## Running Benchmarks

```bash
# Run externalized pattern benchmark
uv run python scripts/benchmark_externalized.py

# Run corpus-based benchmark (real attack samples)
uv run python scripts/benchmark_corpus.py

# Run hybrid detector benchmark
uv run python scripts/benchmark_hybrid.py

# Run against external benchmarks (MSB, MCPSecBench)
uv run python scripts/run_benchmark_tests.py
```

## Results

| Benchmark | Detection Rate |
|-----------|---------------|
| OWASP MCP Top 10 | 100% (24/24) |
| MCPSEC | 97.1% (34/35) |
| CVE Database | 100% (15/15) |
| Real Corpus | 87.5% (35/40) |

**Real-world metrics:**
- Precision: 100%
- Recall: 89.74%
- F1 Score: 94.59%

## External Benchmarks

The `../external_benchmarks/` folder contains cloned third-party repos:
- **MSB** - MCP Security Bench (ICLR 2026)
- **MCPSecBench** - 17 attack types
- **mcp-test-harness** - Security injection tests

These are reference implementations, not our test data.
